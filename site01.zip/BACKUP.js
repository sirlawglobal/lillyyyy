const hompepageUrl2 = 'http://dgn128.pro';

const homepageUrl = 'http://dgn128.pro';
const openModal = () => {
    const modal = document.getElementById("myModal")
    if(modal){
        modal.style.display = 'block'
        }
}


function closeModal(){
    const modal = document.getElementById("myModal")
    if(modal){
        modal.style.display = 'none';
    }
}

function toggleZoom() {
    const image = document.querySelector('.receipt-image');
    image.classList.toggle('zoom-out');
}


// function showOptions(indexNumber) {
//     // Close any open dropdowns first
//     var dropdowns = document.querySelectorAll('.options-dropdown');
//     dropdowns.forEach(function(dropdown) {
//         if (dropdown.id !== indexNumber) {
//             dropdown.style.display = 'none'; // Hide other dropdowns
//         }
//     });
    
//     var optionCard = document.getElementById(indexNumber);
//         console.log("optionCard",optionCard)
//     // Check if element exists
//     if (optionCard) {
//         // Toggle the display of the dropdown
//         if (optionCard.style.display === 'none' || optionCard.style.display === '') {
//             optionCard.style.display = 'flex'; // Show the dropdown
//         } else {
//             optionCard.style.display = 'none'; // Hide the dropdown
//         }
//     } else {
//         console.error(`Element with id ${indexNumber} not found`);
//     }
// }


function showOptions(indexNumber) {
    // Close any open dropdowns first
    var dropdowns = document.querySelectorAll('.options-dropdown');
    dropdowns.forEach(function(dropdown) {
        // Ensure both are strings for comparison
        if (dropdown.id !== `dropdown-${indexNumber}`) {
            dropdown.style.display = 'none'; // Hide other dropdowns
        }
    });
    
    var optionCard = document.getElementById(`dropdown-${indexNumber}`);
    console.log("optionCard", optionCard);

    // Check if element exists
    if (optionCard) {
        // Toggle the display of the dropdown
        if (optionCard.style.display === 'none' || optionCard.style.display === '') {
            optionCard.style.display = 'block'; // Show the dropdown (use block if not flex-based layout)
        } else {
            optionCard.style.display = 'none'; // Hide the dropdown
        }
    } else {
        console.error(`Element with id dropdown-${indexNumber} not found`);
    }
}


//Function to close dropdowns when clicking outside
function closeDropdowns(event) {
    const dropdowns = document.querySelectorAll('.options-dropdown');
    const buttons = document.querySelectorAll('button'); // Change selector if buttons have specific classes

    // Check if the clicked target is outside any dropdown or button
    let isClickInsideDropdown = false;
    dropdowns.forEach(dropdown => {
        if (dropdown.contains(event.target)) {
            isClickInsideDropdown = true;
        }
    });

    let isClickInsideButton = false;
    buttons.forEach(button => {
        if (button.contains(event.target)) {
            isClickInsideButton = true;
        }
    });

    if (!isClickInsideDropdown && !isClickInsideButton) {
        dropdowns.forEach(dropdown => {
            dropdown.style.display = 'none'; // Hide all dropdowns
        });
    }
}
// Event listener for clicks outside the dropdowns
document.addEventListener('click', closeDropdowns);


function formatDate(dateString) {
    const date = new Date(dateString); // Create a Date object from the date string
    const day = String(date.getDate()).padStart(2, '0'); // Get the day and pad with zero if needed
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Get the month (0-indexed) and pad
    const year = date.getFullYear(); // Get the full year
    return `${day}/${month}/${year}`; // Format as d/m/y
}

function formatCurrency(amount) {
    // Convert the amount to a number
    const num = parseFloat(amount);
    
    // Format the number with commas and two decimal places
    const formattedAmount = num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    
    // Return the formatted string
    return `${formattedAmount}`;
}
function formatCurrency2(amount) {
    // Convert the amount to a number
    const num = parseFloat(amount);
    
    // Format the number with commas and two decimal places
    const formattedAmount = num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    
    // Return the formatted string
    return `₦${formattedAmount}`;
}

let activePopup = null; // Track the currently active popup

function showMiniTable(event, items) {
    // Prevent default action and stop event propagation
    event.stopPropagation();

    // Close any currently active popup
    if (activePopup) {
        activePopup.remove();
        activePopup = null;
    }

    // Create a pop-up form element
    const popup = document.createElement('div');
    popup.className = 'popup-form zoom-out'; // Add the zoom-out class for animation
    popup.style.position = 'absolute';
    popup.style.backgroundColor = 'white';
    popup.style.border = '1px solid #ccc';
    popup.style.padding = '10px';
    popup.style.zIndex = '1000';

    // Create the mini table HTML
    let miniTableHTML = `
        <table style="border-collapse: collapse; width: 100%;">
            <thead>
                <tr>
                    <th style="border: 1px solid #ccc; padding: 4px;">Item</th>
                    <th style="border: 1px solid #ccc; padding: 4px;">Quantity</th>
                </tr>
            </thead>
            <tbody>
    `;

    // Populate the table rows with items
    items.forEach(item => {
        miniTableHTML += `
            <tr>
                <td style="border: 1px solid #ccc; padding: 4px;">${item.item}</td>
                <td style="border: 1px solid #ccc; padding: 4px;">${item.quantity}</td>
            </tr>
        `;
    });
    
    miniTableHTML += `
            </tbody>
        </table>
        <button onclick="hideMiniTable()" style="background-color:red;padding:0px 25px; border-color:transparent; margin-left:26px; margin-top:10px; color:white;">Close</button> <!-- Button to close the popup -->
    `;

    popup.innerHTML = miniTableHTML;

    // Position the popup based on the clicked element
    const rect = event.target.getBoundingClientRect();
    popup.style.top = `${rect.bottom + window.scrollY}px`; // Position below the clicked cell
    popup.style.left = `${rect.left}px`; // Align with the left of the clicked cell

    // Append the popup to the body
    document.body.appendChild(popup);

    // Set the active popup
    activePopup = popup;

    // Optionally, add an event listener to close the popup when clicking outside
    document.addEventListener('click', closeOnOutsideClick);

    function closeOnOutsideClick(e) {
        if (!popup.contains(e.target)) {
            hideMiniTable();
        }
    }
}

function hideMiniTable() {
    if (activePopup) {
        activePopup.remove(); // Remove the current popup
        activePopup = null;
        document.removeEventListener('click', closeOnOutsideClick); // Remove the event listener
    }
}


// Function to populate items and quantities
function populateItems(items) {
    var inputContainer = document.getElementById('input-container');
    
    if (inputContainer) {
        // Clear any existing content
        inputContainer.innerHTML = "";

        // Create a table to display items and quantities
        var table = "<table class='input-table'><tr><th>Item</th><th>Quantity</th></tr>";

        // Loop through each item to create table rows
        items.forEach(item => {
            table += `<tr><td>${item.item}</td><td>${item.quantity}</td></tr>`;
        });

        table += "</table>";
        inputContainer.innerHTML = table; // Set the HTML of the input container to the table
    }
}


document.addEventListener('DOMContentLoaded', function() {
    var totalBeneficiary = document.getElementById("totalBeneficiary");
    var totalRegUsers = document.getElementById("totalRegUsers");

    var totalDonor = document.getElementById("totalDonor");
    var totalRice = document.getElementById("totalRice");
    var totalBeans = document.getElementById("totalBeans");
    var totalMedication = document.getElementById("totalMedication");
    var totalClothing = document.getElementById("totalClothing");
    var totalFunds = document.getElementById("totalFunds");

    var itemData = null;
    var outGoingData = null;

    function getDashboardData() {
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            var response = JSON.parse(xhttp.responseText); // Parsing the JSON response
            
            
            // Check if the status is success before accessing the data
            if (response.status === "success") {
                // Isolate each part of the response data
                var genderData = (response.data && response.data.genderData) || {};
                var donorData = (response.data && response.data.total_donors) || 0;
                itemData = (response.data && response.data.itemsInStock) || [];
                outGoingData = (response.data && response.data.disbursementData) || [];
                var AllUsers = (response.data && response.data.total_users) || 0;

                var programData = (response.data && response.data.programData) || [];
                var cashData = programData.find(item => item.item === 'cash');
                var totalCash = cashData.total_quantity
                totalFunds.innerHTML = formatCurrency2(totalCash);
                // console.log("itemData", itemData);
                console.log("outGoingData", outGoingData);
                // console.log("outGoingData2", outGoingData2);
                
                // Accessing the counts of males and females based on their status
                var maleClaimedCount = (genderData.male && genderData.male.Claimed) || 0;
                var femaleClaimedCount = (genderData.female && genderData.female.Claimed) || 0;
                var beneficiaryCount = (maleClaimedCount + femaleClaimedCount) || 0;

                // Initialize quantities for items
                var riceQuantity = 0;
                var beansQuantity = 0;
                var medicationQuantity = 0;
                var clothingQuantity = 0;

                // Loop through itemData to get quantities
                itemData.forEach(item => {
                    var trimmedItem = item.item.trim().toLowerCase();  // Trim and convert to lowercase
                    if (trimmedItem === "rice") {
                        riceQuantity = item.stock_quantity;
                    } else if (trimmedItem === "bean" || trimmedItem === "beans") {
                        beansQuantity = item.stock_quantity;
                    } else if (trimmedItem === "medication") {
                        medicationQuantity = item.stock_quantity;
                    } else if (trimmedItem === "cloths" || trimmedItem === "clothing" || trimmedItem === "clothes") {
                        clothingQuantity = item.stock_quantity;
                    }
                });




                // Update the HTML elements with the counts for gender and status
                if (totalBeneficiary) {
                    totalBeneficiary.innerHTML = beneficiaryCount;
                }
                if (totalRegUsers) {
                    totalRegUsers.innerHTML = AllUsers;
                }

                // Update the HTML elements with the counts for items
                if (totalDonor) {
                    totalDonor.innerHTML = donorData;
                }
                if (totalRice) {
                    totalRice.innerHTML = riceQuantity;
                }
                if (totalBeans) {
                    totalBeans.innerHTML = beansQuantity;
                }
                if (totalMedication) {
                    totalMedication.innerHTML = medicationQuantity;
                }
                if (totalClothing) {
                    totalClothing.innerHTML = clothingQuantity;
                }

                // Log some data if needed for testing
                // console.log("Total Donors:", donorData);
                // console.log("Item Data:", itemData);
                 // Check if the canvas exists before plotting the chart
plotMaterialDomain([riceQuantity, beansQuantity, medicationQuantity, clothingQuantity]);

                //  console.log("riceQuantity1", riceQuantity)
                //  console.log("beansQuantity1", beansQuantity)
                //  console.log("medicationQuantity1", medicationQuantity)
                //  console.log("clothingQuantity1", clothingQuantity)

    const stockChartElement = document.getElementById('stockChart');
    const materialElement = document.getElementById('materialChart');
    if (stockChartElement) {
        plotStockChart(itemData);
    } else {
        console.log("Canvas element with id 'stockChart' not found. Skipping chart plot.");
    }

         // plotStockChart(itemData);
                // checkQuantities(itemData)
            } else {
                console.error("Error in response status:", response.status);
            }
        };

        xhttp.onerror = function() {
            // Handle error display if request fails
            console.error('Request failed.');

            if (totalBeneficiary) totalBeneficiary.innerHTML = "Error";
            if (totalRegUsers) totalRegUsers.innerHTML = "Error";
            if (totalDonor) totalDonor.innerHTML = "Error";
            if (totalRice) totalRice.innerHTML = "Error";
            if (totalBeans) totalBeans.innerHTML = "Error";
            if (totalMedication) totalMedication.innerHTML = "Error";
            if (totalClothing) totalClothing.innerHTML = "Error";
        };

        xhttp.open("GET", '../backend/request.php?function=get-dashboardData', true);
        xhttp.send();
    }

    // Call the function to execute
    getDashboardData();

// Dashboard chart function
function plotStockChart(itemData) {
    // Remove the item with name "cash" from itemData
    const filteredItemData = itemData.filter(item => item.item.trim().toLowerCase() !== "cash");

    // Initialize an array for months and quantities for each item
    const monthNames = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
        "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"
    ];

    const quantitiesByItem = {}; // Object to hold quantities for each item by month

    // Initialize the quantities for each item
    filteredItemData.forEach(item => {
        const date = new Date(item.date);
        const monthIndex = date.getMonth();
        const itemName = item.item.trim().toLowerCase(); // Normalize item name

        // Initialize the item's quantities array if it doesn't exist
        if (!quantitiesByItem[itemName]) {
            quantitiesByItem[itemName] = Array(12).fill(0); // Create an array of 12 months initialized to 0
        }

        // Update the stock quantity for the respective month
        quantitiesByItem[itemName][monthIndex] += item.stock_quantity; // Accumulate stock for the month
    });

    // Define colors for each item
    const itemColors = {
        "medication": "#097B48",
        "rice": "#FFBE00",
        "beans": "#296015",
        "cloth": "#E98018" // Corrected the key for clothing
    };

    // Prepare the datasets for the chart
    const datasets = Object.entries(quantitiesByItem).map(([itemName, quantities]) => ({
        label: itemName.charAt(0).toUpperCase() + itemName.slice(1), // Capitalize first letter
        data: quantities,
        backgroundColor: itemColors[itemName] || 'rgba(75, 192, 192, 0.5)', // Use specified color or default
        borderColor: itemColors[itemName] ? itemColors[itemName].replace(/0.5$/, '1') : 'rgba(75, 192, 192, 1)', // Change transparency for border
        borderWidth: 1
    }));

    // Create the chart
    const ctx = document.getElementById('stockChart').getContext('2d');

   
    const stockChart = new Chart(ctx, {
        type: 'bar', // Change to 'bar' for a bar chart
        data: {
            labels: monthNames, // X-axis (months)
            datasets: datasets // Use the prepared datasets
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true // Hide the default legend
                }
            },
            scales: {
                y: {
                    beginAtZero: true, // Start y-axis from 0
                    title: {
                        display: true,
                        text: 'No of Items in Stock'
                    }
                },
                x: {
                    title: {
                        display: false,
                        text: 'Months'
                    }
                }
            }
        }
    });

    // Create the custom legend
    // createLegend(datasets);
}

    function plotMaterialDomain(itemQuantities) {

    console.log("Item Quantities:", itemQuantities);

    const canvas = document.getElementById('materialChart');
    
    if (!canvas) {
        console.error("Canvas element with ID 'materialChart' not found.");
        return; // Exit if canvas is not found
    }

    const ctx = canvas.getContext('2d');
    const labels = ['Rice', 'Beans', 'Medication', 'Clothing'];
    
    new Chart(ctx, {
        type: 'bar', // Use 'bar' for a vertical bar chart
        data: {
            labels: labels,
            datasets: [{
                label: 'Item Quantities',
                data: itemQuantities,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)', // Rice
                    'rgba(54, 162, 235, 0.6)', // Beans
                    'rgba(255, 206, 86, 0.6)', // Medication
                    'rgba(75, 192, 192, 0.6)'  // Clothing
                ],
                borderColor: 'rgba(255, 255, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Items' // Label for the x-axis
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Quantity' // Label for the y-axis
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Stock Quantities of Items'
                }
            }
        }
    });
}




});

// below are the report chart

// Predefined colors for each state in Nigeria
const stateColors = {
    'abia': '#FF5733',
    'adamawa': '#33FF57',
    'akwa ibom': '#3357FF',
    'anambra': '#FF33A8',
    'bauchi': '#33FFC1',
    'bayelsa': '#FFB833',
    'benue': '#D033FF',
    'borno': '#FF3333',
    'cross river': '#FF8633',
    'delta': '#33FF86',
    'ebonyi': '#3386FF',
    'edo': '#8633FF',
    'ekiti': '#FF33C1',
    'enugu': '#FF3386',
    'gombe': '#C1FF33',
    'imo': '#33D0FF',
    'jigawa': '#FF33F1',
    'kaduna': '#F1FF33',
    'kano': '#33F1FF',
    'kogi': '#FF5733',
    'kwara': '#33FF33',
    'lagos': '#5733FF',
    'nasarawa': '#FFB833',
    'niger': '#D033FF',
    'ogun': '#FF3333',
    'ondo': '#FF8633',
    'osun': '#33FF86',
    'oyo': '#3386FF',
    'plateau': '#8633FF',
    'rivers': '#FF33C1',
    'sokoto': '#FF3386',
    'taraba': '#C1FF33',
    'yobe': '#33D0FF',
    'zamfara': '#FF33F1'
};

function plotStateChart(states, totalCounts) {
    const ctx = document.getElementById('stateChart').getContext('2d');

    // Destroy existing chart instance if it exists
    if (stateChartInstance) {
        stateChartInstance.destroy();
    }

    // Prepare colors for each state
    const colors = states.map(state => {
        const normalizedState = state.toLowerCase(); // Normalize to lowercase
        if (!stateColors[normalizedState]) {
            console.warn(`No color found for state: ${normalizedState}`); // Log warning for missing colors
        }
        return stateColors[normalizedState] || '#000000'; // Fallback to black
    });

    // Create a new chart instance
    stateChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: states,
            datasets: [{
                label: 'Number of Users by State',
                data: totalCounts,
                backgroundColor: colors,
                borderColor: colors.map(color => color.replace('0.6', '1')), // Set border color
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Users' // Set your desired label here
                    }
                }
            },
            plugins: {
                legend: {
                    display: false // Remove the legend
                }
            }
        }
    });
}

function plotAgeRangeChart(ageRanges, ageCounts) {
    // Register the datalabels plugin if required
    Chart.register(ChartDataLabels);

    // Prepare data for the pie chart
    const data = {
        labels: ageRanges, // Use only age ranges for labels
        datasets: [{
            data: ageCounts,
            backgroundColor: [
                '#E32424', // Color for age range 1
                '#5CA904', // Color for age range 2
                ' #E98018', // Color for age range 3
                '#9747FF', // Color for age range 4
                '#FFBE00'  // Color for age range 5
            ],



            hoverBackgroundColor: [
                '#FF6384',
                '#36A2EB',
                '#FFCE56',
                '#4BC0C0',
                '#9966FF'
            ]
        }]
    };

    // Get the context of the canvas element where the chart will be rendered
    const ctx = document.getElementById('claimedItemsPieChart').getContext('2d');

    // Check if a chart instance already exists and destroy it if it does
    if (ageRangeChartInstance) {
        ageRangeChartInstance.destroy();
    }

    // Create a new pie chart
    ageRangeChartInstance = new Chart(ctx, {
        type: 'pie',
        data: data,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false,
                    position: 'top',
                },
                title: {
                    display: false,
                    text: 'Claimed Items by Age Range'
                },
                // Enable the datalabels plugin
                datalabels: {
                    formatter: (value, context) => {
                        const ageRange = context.chart.data.labels[context.dataIndex];
                        return `${value}\n${ageRange}`; // Show age range and count
                    },
                    color: '#fff', // Set the color of the labels
                    anchor: 'center',
                    align: 'right',
                    offset: (context) => {
                        // Check the current label and return the corresponding offset
                        switch (context.chart.data.labels[context.dataIndex]) {
                            case '20 and under years':
                                return -39;
                                 
        
                               
                            case '81-above':
                                return -29;
                                
                            default:
                                return 0; 
                               
                        }
                    }
                
                }
            }
        },
    });
}

function plotMaritalStatusChart(statuses, counts) {
    const ctx = document.getElementById('maritalStatusChart').getContext('2d');

    // Destroy the existing chart instance if it exists
    if (maritalStatusChartInstance) {
        maritalStatusChartInstance.destroy();
    }

    // Create a new chart instance
    maritalStatusChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: statuses,
            datasets: [{
                label: 'Marital Status vs Users',
                data: counts,
                backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56'],
                borderColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56'],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Marital Status'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Users'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(tooltipItem) {
                            return `Users: ${counts[tooltipItem.dataIndex]}`;
                        }
                    }
                }
            }
        }
    });
}

function plotGenderChart(genders, genderCounts) {
    // Register the datalabels plugin if required
    Chart.register(ChartDataLabels);

    // Prepare data for the doughnut chart
    const data = {
        labels: genders, // Use genders for labels
        datasets: [{
            data: genderCounts,
            backgroundColor: [
                '#E98018', // Color for Female
                '#5CA904', // Color for Male
            ],
           


            hoverBackgroundColor: [
                '#FF6384',
                '#36A2EB'
            ]
        }]
    };

    // Get the context of the canvas element where the chart will be rendered
    const ctx = document.getElementById('claimedItemsDoughnutChart').getContext('2d');

    // Check if a chart instance already exists and destroy it if it does
    if (genderChartInstance) {
        genderChartInstance.destroy();
    }

    // Create a new doughnut chart
    genderChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false,
                    position: 'top',
                },
                title: {
                    display: false,
                    text: 'Claimed Items by Gender'
                },
                // Enable the datalabels plugin
                datalabels: {
                    formatter: (value, context) => {
                        const gender = context.chart.data.labels[context.dataIndex];
                        return `${gender}: ${value}`; // Show gender and count
                    },
                    color: '#fff', // Set the color of the labels
                    anchor: 'center',
                    align: 'center',
                    offset: 0, // Adjust this value to position the labels as needed
                }
            }
        },
    });
}


function plotCashSoFar(labels, quantities) {
    const ctx = document.getElementById('cashsofarChart').getContext('2d'); // Ensure you have a canvas with this ID

    // Combine the quantities for "Unknown" and "Ehi"
    const totalEhi = quantities[0]; // Assuming "Ehi" is the first item
    const totalUnknown = quantities[1]; // Assuming "Unknown" is the second item
    const combinedLabel = "Total cash so Far";
    const combinedQuantity = totalEhi + totalUnknown;

    // Update labels and quantities for the pie chart
    const updatedLabels = [combinedLabel, "External Investors"];
    const updatedQuantities = [combinedQuantity, totalUnknown];

    if (cashsofarChart) {
        cashsofarChart.destroy(); // Destroy the existing chart
    }

    cashsofarChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: updatedLabels,
            datasets: [{
                label: 'Cash Donations',
                data: updatedQuantities,
                backgroundColor: ['#FFBE00', '#E98018'], // Example colors
                borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'],
                borderWidth: 1

            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false, // Show the legend if desired
                    position: 'top',
                },
                title: {
                    display: false,
                    text: 'Cash Donations Overview'
                },
                datalabels: {
                    anchor: 'end', // Position of the labels
                    align: 'end', // Alignment of the labels
                    formatter: (value, context) => {
                        const label = context.chart.data.labels[context.dataIndex]; // Get the label for the data index
                        return `${label}\n${value}`; // Display label and value
                    },
                    color: 'white', // Label text color
                    anchor: 'center',
                    align: 'center',
                    offset: 0,
                }
            }
        },
        plugins: [ChartDataLabels] // Include the data labels plugin
    });
}

function openMaterialAnalytics() {
    fetchMaterialData(); // Fetch all data initially
}
// Call this function with parameters to fetch data based on date range
function applyDateFilter() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;

    if (!startDate || !endDate) {
        alert('Please select both start and end dates.');
        return;
    }

    fetchMaterialData(startDate, endDate); // Fetch data based on the selected date range
}

let myPieChart; // For pie chart
let myBarChart; // For bar chart
let myComboChart; // For bar chart
let cashsofarChart; // For bar chart


//
function plotItemsSofar(labels, data) {
    console.log("Data inside plotItemsSofar:", data); // Debugging log

    const ctx = document.getElementById('myPieChart').getContext('2d');
    if (myPieChart) myPieChart.destroy();

    myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: ['#5CA904', '#E32424', '#FFBE00', '#E98018'],
                borderColor: 'rgba(255, 255, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                title: { display: false, text: 'Material Domain Quantities' },
                datalabels: {
                    formatter: function(value, context) {
                        return context.chart.data.labels[context.dataIndex] + '\n' + value; 
                    },
                    color: '#fff',
                }
            }
        },
        plugins: [ChartDataLabels]
    });
}

//combo in material domain
function plotMaterialInStock(labels, quantities, disbursementData) {
    const canvas = document.getElementById('materialChart');

    if (!canvas) {
        console.error("Canvas element with ID 'materialChart' not found.");
        return; // Exit if canvas is not found    
    }

    const ctx = canvas.getContext('2d');

    // Define preset colors for each item
    const colorMapping = {
        'beans': '#E98018',    // Orange
        'cash': 'rgba(54, 162, 235, 0.6)',     // Blue
        'clothes': '#E32424',  // Red
        'medication': '#9747FF', // Purple
        'rice': '#5CA904'     // Green
    };

    // Map colors to the labels based on the preset colorMapping
    const backgroundColors = labels.map(item => colorMapping[item.toLowerCase()] || 'rgba(201, 203, 207, 0.6)'); // Fallback color if item not found

    // Extract data for the line chart from disbursementData
    const disbursementQuantities = disbursementData.map(item => parseInt(item.total_quantity)); // Quantities for the line chart

    // Check if there's an existing chart and destroy it
    if (myComboChart) {
        myComboChart.destroy(); // Destroy the existing chart if present
    }

    // Create a combo chart with bar and line datasets
    myComboChart = new Chart(ctx, {
        type: 'bar', // Set the base chart type as 'bar'
        data: {
            labels: labels,  // Use item names for the horizontal axis
            datasets: [
                {
                    label: null,  // Set label to null to hide it from the legend
                    data: quantities,    // Data for the bar chart
                    backgroundColor: backgroundColors, // Apply the preset colors
                    borderColor: backgroundColors.map(color => color.replace('0.6', '1')), // Darker border
                    borderWidth: 1,
                    barPercentage: 1.5, // Increase the width of each bar
                    categoryPercentage: 0.6, // Adjust space between bars
                    type: 'bar', // Specify this dataset as a bar chart
                },
                {
                    label: 'Disbursement', // Legend label for the line chart
                    data: disbursementQuantities, // Data for the line chart
                    backgroundColor: 'rgba(54, 162, 235, 0.2)', // Light blue fill
                    borderColor: 'rgba(54, 162, 235, 1)', // Solid blue line border (indicator for disbursement)
                    borderWidth: 2,
                    type: 'line', // Specify this dataset as a line chart
                    fill: true,   // Enable area fill below the line
                    yAxisID: 'y1'  // Use a separate Y-axis (for disbursement)
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    position: 'left',  // Y-axis for the bar chart
                    title: {
                        display: true,
                        text: 'Stock Quantities'
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right', // Position the disbursement Y-axis on the right
                    title: {
                        display: true,
                        text: 'Disbursement Quantities'
                    },
                    display: false, // Ensure the disbursement scale is hidden
                },
                x: {
                    title: {
                        display: true,
                        text: 'Items'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false, // Display the legend
                },
                title: {
                    display: false,
                    text: 'Items in Stock vs Disbursed Quantities'
                },
                tooltip: {
                    callbacks: {
                        title: (tooltipItems) => {
                            // Display item name as the title
                            return labels[tooltipItems[0].dataIndex];
                        },
                        label: (tooltipItem) => {
                            // For the bar chart, display stock quantity
                            if (tooltipItem.dataset.type === 'bar') {
                                const stockQuantity = quantities[tooltipItem.dataIndex];
                                return `${labels[tooltipItem.dataIndex]}: Stock Quantity: ${stockQuantity}`;
                            } else {
                                // For the line chart, display disbursed quantity
                                const disbursedQuantity = disbursementQuantities[tooltipItem.dataIndex];
                                return `${labels[tooltipItem.dataIndex]}: Disbursed Quantity: ${disbursedQuantity}`;
                            }
                        }
                    }
                }
            }
        }
    });
}

 //beneficiary report( for main screen)
function loopBeneficiaryReport(data){
    var container = document.getElementById('beneciary-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){

        data.sort((a, b) => b.id - a.id);

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>   
                <td class="ehi-td2">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td2">${counter}</td>
                <td class="ehi-td2">${data[i]?.first_name ?? ''}</td>
                <td class="ehi-td2">${data[i]?.last_name ?? ''}</td>
                <td class="ehi-td2">${data[i]?.user_pin ?? ''}</td>
                <td class="ehi-td2">${data[i]?.gender ?? ''}</td>
                <td class="ehi-td2">${data[i]?.age ?? ''}</td>

            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}
var  beneficiaryData ;
function getBeneficiaryReport(){

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        beneficiaryData = response.data.beneficiaries;
// console.log("beneficiaryData:", beneficiaryData)
        loopBeneficiaryReport(beneficiaryData)
    }

    xhttp.open("GET", '../backend/request.php?function=get-BeneficiaryAnalytics', true);
    xhttp.send();
}
 getBeneficiaryReport();


 function submitBeneficiaryDate(){
    const fromDate = document.getElementById('from-date').value;
    const toDate = document.getElementById('to-date').value;

    if (fromDate !== '' && toDate !== '') {
        const newFromDate = new Date(fromDate).toISOString().split('T')[0];
        const newToDate = new Date(toDate).toISOString().split('T')[0];

        var xhttp = new XMLHttpRequest();
        
        xhttp.onload = function () {
            var response = JSON.parse(xhttp.response);
            materialData =  response.data.beneficiaries;
                
            
            let filterPaymentReport = materialData.filter(item => {
                const itemDate = new Date(item.date).toISOString().split('T')[0];
              
                return itemDate >= newFromDate && itemDate <= newToDate;
            });
            

            loopBeneficiaryReport(filterPaymentReport)
        }

        xhttp.open('GET', '../backend/request.php?function=get-BeneficiaryAnalytics');
        xhttp.send();
    } else {
        swal('Sorry', 'Please add dates', 'error');
    }
  

  
}

 function downloadBeneficaryReport() {
    const element = document.querySelector('.ehi-table-container-beneficiary'); 

    if (!element) {
        console.error("Element not found!");
        return;
    }

    var { jsPDF } = window.jspdf;  // Get the jsPDF class from the library

    html2canvas(element).then(function(canvas) {
        var imgData = canvas.toDataURL('image/png');
        var doc = new jsPDF();

        // Add the image to the PDF, adjust size and position
        doc.addImage(imgData, 'PNG', 10, 10, 190, canvas.height * 190 / canvas.width);  // Adjust width and height

        doc.save('beneficiary_report.pdf');  // Save as 'beneficiary_report.pdf'
    }).catch(function(error) {
        console.error("Error generating PDF:", error);
    });
}


function beneficiaryAnalytics2(newData) {
    var modals = document.querySelector('.modals');
    const data = newData || 0;

    // Get the current month and year
    const now = new Date();
    const currentMonth = now.getMonth() + 1; // Months are 0-indexed
    const currentYear = now.getFullYear();

    // Create the year options for the next 100 years
    let yearOptions = '';
    for (let i = 0; i < 100; i++) {
        const year = currentYear + i;
        yearOptions += `<option value="${year}">${year}</option>`;
    }

    var modalContent = `
    <style>
        #claimedItemsPieChart {
            max-width: 100%; /* Ensure it doesn't overflow the parent container */
            height: auto;    /* Maintain aspect ratio */
        }
        .analytics-card-container {
            border: 1px solid #097B48;
            padding: 10px;
            border-radius: 25px;
            height: 300px;
            display: flex;
            justify-content: space-around;
            flex-direction: column;
            box-shadow: 4px 4px 4px 0px #00000040;

        }

        .add-text-header {
            background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 50px !important;
            height: 35px;
            color: white;
        }

        .userdata-modal-content {
            background-color: #fefefe;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh;
            max-width: 100vw; 
            overflow-y: scroll;
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            <div id="everything-view">
                <div class="add-text-header no-print">
                    <button class="sign-out-button" onclick="downloadView()">Download</button>
                    <h3>(Beneficiaries) Total No Supported Per Period</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <div class="analytics-container">
                    <!-- age cards... -->
                    <div class="whole-card">
                        <h3 class="card-text">Age</h3>
                        <div class="analytics-card-container" style="margin-bottom:20px">
                            <div class="analytics-button" style="margin-bottom:10px;position:absolute; top:40px; right:10px">
                                <label for="monthSelect">Month:</label>
                                <select id="monthSelect">
                                    <option value="1">January</option>
                                    <option value="2">February</option>
                                    <option value="3">March</option>
                                    <option value="4">April</option>
                                    <option value="5">May</option>
                                    <option value="6">June</option>
                                    <option value="7">July</option>
                                    <option value="8">August</option>
                                    <option value="9">September</option>
                                    <option value="10">October</option>
                                    <option value="11">November</option>
                                    <option value="12">December</option>
                                </select>
                                
                                <label for="yearSelect">Year:</label>
                                <select id="yearSelect">
                                    ${yearOptions}
                                </select>
                            </div>
                            <div class="analytics-image">
                                <canvas id="claimedItemsPieChart" width="800" height="700"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- gender cards... -->
                    <div class="whole-card">
                        <h3 class="card-text">Gender</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt=""></div>
                            <div class="analytics-image">
                                <canvas id="claimedItemsDoughnutChart" width="290" height="290"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- marital status cards... -->
                    <div class="whole-card">
                        <h3 class="card-text">Marital Status</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt=""></div>
                            <div class="analytics-image">
                                <canvas id="maritalStatusChart" width="290" height="290"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- location cards... -->
                    <div class="whole-card2">
                        <h3 class="card-text">Location</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt=""></div>
                            <div class="analytics-image">
                                <canvas id="stateChart" width="290" height="290"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();

        // Set the month and year to the current month and year
        document.getElementById('monthSelect').value = currentMonth;
        document.getElementById('yearSelect').value = currentYear;

        // Add change event listeners for the dropdowns
        document.getElementById('monthSelect').addEventListener('change', function() {
            getBeneficiaryDomain();
            // getBeneficiaryDomain2();
        });

        document.getElementById('yearSelect').addEventListener('change', function() {
            getBeneficiaryDomain();
            // getBeneficiaryDomain2();
        });

        // Load data for the current month and year
        getBeneficiaryDomain();
        // getBeneficiaryDomain2();
    }
}


// function submitMaterialDate(){
//     const fromDate = document.getElementById('from-date').value;
//     const toDate = document.getElementById('to-date').value;

//     if (fromDate !== '' && toDate !== '') {
//         const newFromDate = new Date(fromDate).toISOString().split('T')[0];
//         const newToDate = new Date(toDate).toISOString().split('T')[0];

//         var xhttp = new XMLHttpRequest();
        
//         xhttp.onload = function () {
//             var response = JSON.parse(xhttp.response);
//             materialData =  response.data.beneficiaries;
                
            
//             let filterPaymentReport = materialData.filter(item => {
//                 const itemDate = new Date(item.date).toISOString().split('T')[0];
              
//                 return itemDate >= newFromDate && itemDate <= newToDate;
//             });
            

//             loopBeneficiaryReport(filterPaymentReport)
//         }

//         xhttp.open('GET', '../backend/request.php?function=get-materialDomain');
//         xhttp.send();
//     } else {
//         swal('Sorry', 'Please add dates', 'error');
//     }
  

  
// }

// for chart
function getBeneficiaryDomain() {
    const month = document.getElementById('monthSelect').value;
    const year = document.getElementById('yearSelect').value;

    if (!month || !year) {
        alert("Please select both a month and a year.");
        return;
    }

    const xhttp = new XMLHttpRequest();

    xhttp.onload = function() {
        let response;
        try {
            response = JSON.parse(xhttp.responseText);
        } catch (error) {
            console.error("Failed to parse response:", error);
            alert("An error occurred while processing the data. Please try again.");
            return;
        }

        // Log the entire response to check its structure
        console.log("API Response:", response);

        if (response?.status === "success") {
            // Access claimed items
            const claimedItemsByAgeRange = response.data.claimedItemsByAgeRange;
            const claimedItemsByGender = response.data.claimedItemsByGender;
            const claimedItemsByMaritalStatus = response.data.claimedItemsByMaritalStatus;
            const userLocations = response.data.userLocations; // Access user locations

            // Destroy existing charts before creating new ones
            if (ageRangeChartInstance) ageRangeChartInstance.destroy();
            if (genderChartInstance) genderChartInstance.destroy();
            if (maritalStatusChartInstance) maritalStatusChartInstance.destroy();

            // Destroy the state chart instance if it exists
            if (stateChartInstance) {
                stateChartInstance.destroy(); // Destroy the previous state chart instance
            }

            // Prepare data for Age Range chart
            const ageRanges = Object.keys(claimedItemsByAgeRange);
            const ageCounts = ageRanges.map(range => claimedItemsByAgeRange[range]?.length || 0);

            console.log("ageRanges", ageRanges)
            plotAgeRangeChart(ageRanges, ageCounts);

            // Prepare data for Gender chart
            const genders = Object.keys(claimedItemsByGender);
            const genderCounts = genders.map(gender => claimedItemsByGender[gender]?.length || 0);
            plotGenderChart(genders, genderCounts);

            // Prepare data for Marital Status chart
            const maritalStatuses = Object.keys(claimedItemsByMaritalStatus);
            const maritalStatusCounts = maritalStatuses.map(status => claimedItemsByMaritalStatus[status]?.length || 0);
            plotMaritalStatusChart(maritalStatuses, maritalStatusCounts);

            // Access user locations and prepare data for State chart
            const stateCounts = {};

            userLocations.forEach(location => {
                const state = location.state;
                if (!stateCounts[state]) {
                    stateCounts[state] = 0;
                }
                stateCounts[state]++;
            });

            // Prepare data for the state bar chart
            const states = Object.keys(stateCounts);
            const totalCounts = states.map(state => stateCounts[state]);

            console.log("States:", states);
            console.log("Total Counts:", totalCounts);

            // Create the bar chart for States
            plotStateChart(states, totalCounts);

        } else {
            console.error("Error in response status:", response.status);
            alert("Failed to fetch claimed items. Please try again.");
        }
    };

    xhttp.onerror = function() {
        console.error('Request failed.');
        alert("An error occurred while fetching claimed items. Please try again.");
    };

    const url = `../backend/request.php?function=get-BeneficiaryDomain&month=${month}&year=${year}`;
    xhttp.open("GET", url, true);
    xhttp.send();
}


//material report main screen
 function loopMaterialReport(data){
    var container = document.getElementById('material-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){

        data.sort((a, b) => b.id - a.id);

        for(var i=0; i < data.length; i++){
        counter++;

        tr += `
            <tr>   
                <td class="ehi-td2">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td2">${counter}</td>
                <td class="ehi-td2">${data[i]?.donor ?? ''}</td>
                <td class="ehi-td2">${data[i]?.item?? ''}</td>
                <td class="ehi-td2">${data[i]?.quantity ?? ''}</td>
                <td class="ehi-td2">${data[i]?.amount ?? ''}</td>

            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

var  materialData;
function getMaterialReport(){

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
       materialData = response.data.material_data;
console.log("materialData:", materialData)
loopMaterialReport(materialData)
    }

    xhttp.open("GET", '../backend/request.php?function=get-MaterialAnalytics', true);
    xhttp.send();
}
getMaterialReport();

function submitMaterialDate(){

    const fromDate = document.getElementById('from-date').value;
    const toDate = document.getElementById('to-date').value;

    if (fromDate !== '' && toDate !== '') {
        const newFromDate = new Date(fromDate).toISOString().split('T')[0];
        const newToDate = new Date(toDate).toISOString().split('T')[0];

        var xhttp = new XMLHttpRequest();
        
        xhttp.onload = function() {
            let response;
            try {
                response = JSON.parse(xhttp.responseText);
            } catch (error) {
                console.error("Failed to parse response:", error);
                alert("An error occurred while processing the data. Please try again.");
                return;
            }
    
            if (response.status === "success") {
                const materialData = response.data.materialDomain;
                const itemsInStock = response.data.itemsInStock;
                const disbursementData = response.data.disbursementData;
                const donorData = response.data.donorData;
                console.log("disbursementData", disbursementData)
    
    
                // Declare variables for each item
                let rice = materialData.Rice || [];
                let beans = materialData.Beans || [];
                let clothes = materialData.Clothes || [];
                let medication = materialData.Medication || [];
    
                console.log("Medication data:", medication);
    
                // Calculate total quantities for each item, with validation to avoid NaN
                const totalRice = rice.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
                const totalBeans = beans.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
                const totalClothes = clothes.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
                const totalMedication = medication.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
    
                console.log("Total quantities:", { totalRice, totalBeans, totalClothes, totalMedication });
    
                // Access Ehi and Unknown data directly from donorData
                const ehiData = donorData.Ehi || [];
                const unknownData = donorData.Unknown || [];
    
                // Calculate total amounts for Ehi and Unknown
                const totalEhi = ehiData.reduce((acc, item) => acc + parseFloat(item.total_amount), 0);
                const totalUnknown = unknownData.reduce((acc, item) => acc + parseFloat(item.total_amount), 0);
    
                // Prepare labels and quantities for the cashsofar pie chart
                const cashsofarLabels = ["Ehi + Unknown", "Unknown"];
                const cashsofarQuantities = [totalEhi + totalUnknown, totalUnknown];
    
                // Destroy existing charts if they exist
                if (myPieChart) myPieChart.destroy();
                if (myBarChart) myBarChart.destroy();
                if (myComboChart) myComboChart.destroy();
                if (cashsofarChart) cashsofarChart.destroy();
    
                // Data for the main pie chart (excluding cash)
                const labels = ["Rice", "Beans", "Clothes", "Medi"];
                const quantities = [totalRice, totalBeans, totalClothes, totalMedication];
                console.log("Quantities before plotItemsSofar:", quantities);
    
                // Plot the main pie chart
                plotItemsSofar(labels, quantities);
    
                // Plot the cashsofar pie chart
                plotCashSoFar(cashsofarLabels, cashsofarQuantities);
    
                // Prepare data for the bar chart from itemsInStock
                const filteredItemsInStock = itemsInStock.filter(item => item.item.toLowerCase() !== 'cash');
                const stockLabels = filteredItemsInStock.map(item => item.item);
                const stockQuantities = filteredItemsInStock.map(item => item.stock_quantity);
                console.log("stockLabels",stockLabels)
                console.log("stockQuantities",stockQuantities)
                console.log("disbursementData",disbursementData)
    
    
                // Plot the bar chart
                plotMaterialInStock(stockLabels, stockQuantities, disbursementData);
    
                // Uncomment if plotDisbursementData is used for line chart plotting
                // plotDisbursementData(disbursementData);
    
            } else {
                console.error("Error in response:", response.message);
                alert("Failed to fetch material data. Please try again.");
            }
        };
    

        xhttp.open('GET', '../backend/request.php?function=get-materialDomain');
        xhttp.send();
    } else {
        swal('Sorry', 'Please add dates', 'error');
    }
  

  
}

function downloadMaterialReport() {
    const element = document.querySelector('.ehi-table-container-materialreport'); 

    if (!element) {
        console.error("Element not found!");
        return;
    }

    var { jsPDF } = window.jspdf;  // Get the jsPDF class from the library

    html2canvas(element).then(function(canvas) {
        var imgData = canvas.toDataURL('image/png');
        var doc = new jsPDF();

        // Add the image to the PDF, adjust size and position
        doc.addImage(imgData, 'PNG', 10, 10, 190, canvas.height * 190 / canvas.width);  // Adjust width and height

        doc.save('material_report.pdf');  // Save as 'beneficiary_report.pdf'
    }).catch(function(error) {
        console.error("Error generating PDF:", error);
    });
}

//material modal(for charts)
function materialsAnalytics(newData) {
    var modals = document.querySelector('.modals');
    const data = newData || 0;

    // Get the current month and year
    const now = new Date();
    const currentMonth = now.getMonth() + 1; // Months are 0-indexed
    const currentYear = now.getFullYear();

    // Create the year options for the next 100 years
    let yearOptions = '';
    for (let i = 0; i < 100; i++) {
        const year = currentYear + i;
        yearOptions += `<option value="${year}">${year}</option>`;
    }

    var modalContent = `
    <style>
        #claimedItemsPieChart {
            max-width: 100%; /* Ensure it doesn't overflow the parent container */
            height: auto;    /* Maintain aspect ratio */
        }
        .analytics-card-container {
            border: 1px solid #097B48;
            padding: 10px;
            border-radius: 25px;
            height: 270px;
            display: flex;
            justify-content: space-around;
            flex-direction: column;
            box-shadow: 4px 4px 4px 0px #00000040;

        }

        .add-text-header {
            background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 50px !important;
            height: 35px;
            color: white;
        }

        .userdata-modal-content {
            background-color: #fefefe;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh;
            max-width: 100vw; 
            overflow-y: scroll;
        }


        .analytics-container {
    display: grid;
    grid-template-columns: unset !important;
    padding: 15px;
    column-gap: 20px;
}

canvas{
width:350px;
}

#startDate, #endDate{
background: #097B48;
width: 60px;
height: 23px;
gap: 0px;
border-radius: 5px 0px 0px 0px;
opacity: 0px;
color:white;
border-color:transparent;
outline:none;
padding:20px 0:
padding-left:5px;;
}

  input[type="date"]::-webkit-datetime-edit {
      color: #097B48;
  }

  }
    </style>
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            <div id="everything-view">
                <div class="add-text-header no-print">
                    <button class="sign-out-button" onclick="downloadView()">Download</button>
                    <h3>Materials Domains</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <div class="analytics-container">

                    <!-- Items Received cards... -->
                    <div class="whole-card">
                        <h3 class="card-text">Items Received so Far </h3>
                        <div class="analytics-card-container" style="margin-bottom:20px">

                            <div class="analytics-button" style="margin-bottom:10px;position:absolute; top:40px; right:10px">
                               
                                 <!-- filerter date... -->
                    

                     <div class="report-date-container">
                <div class="date-container">
                    <div class="smaller-date">
                        <label for="" class="date-label">From</label>
                        <input type="date" id="from-date" class="report-date">
                    </div>
                    <div class="smaller-date">
                        <label for="" class="date-label">To</label>
                        <input type="date" id="to-date" class="report-date">
                    </div>
                    <div class="date-button-container">
                        <button class="date-button" onclick="submitMaterialDate()">Filter</button>

                    </div>
                </div>
                
            </div>
                    
                    <!-- Trigger applyDateFilter on click -->

 <!--  end filerter date... -->

 <!--  item receive so far... -->
                              
                            </div>
                            <div class="analytics-image">
                                <canvas id="myPieChart" width="700" height="700"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- cash so far... -->
                    <div class="whole-card">
                        <h3 class="card-text">Cash Received so far</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt=""></div>
                            <div class="analytics-image">
                                <canvas id="cashsofarChart" width="290" height="290"></canvas>
                            </div>
                        </div>
                    </div>



                    <!-- program data vs disbur.. -->
                    <div class="whole-card2">
                        <h3 class="card-text">Items in stock & items disbursed</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt=""></div>
                            <div class="analytics-image">
                                <canvas id="materialChart" width="900" height="350"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();

        
        // fetchMaterialDomain();
        openMaterialAnalytics()
        document.addEventListener("DOMContentLoaded", function () {
           
            getDashboardData(); // Call the function when the DOM is fully loaded
        });

    }
}

////material modal(for charts) handler
function fetchMaterialData(startDate = '', endDate = '') {
    const url = startDate && endDate
        ? `../backend/request.php?function=get-materialDomain&startDate=${startDate}&endDate=${endDate}`
        : '../backend/request.php?function=get-materialDomain';

    const xhttp = new XMLHttpRequest();

    xhttp.onload = function() {
        let response;
        try {
            response = JSON.parse(xhttp.responseText);
        } catch (error) {
            console.error("Failed to parse response:", error);
            alert("An error occurred while processing the data. Please try again.");
            return;
        }

        if (response.status === "success") {
            const materialData = response.data.materialDomain;
            const itemsInStock = response.data.itemsInStock;
            const disbursementData = response.data.disbursementData;
            const donorData = response.data.donorData;
            console.log("disbursementData", disbursementData)


            // Declare variables for each item
            let rice = materialData.Rice || [];
            let beans = materialData.Beans || [];
            let clothes = materialData.Clothes || [];
            let medication = materialData.Medication || [];

            console.log("Medication data:", medication);

            // Calculate total quantities for each item, with validation to avoid NaN
            const totalRice = rice.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
            const totalBeans = beans.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
            const totalClothes = clothes.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);
            const totalMedication = medication.reduce((acc, item) => acc + (parseInt(item.quantity, 10) || 0), 0);

            console.log("Total quantities:", { totalRice, totalBeans, totalClothes, totalMedication });

            // Access Ehi and Unknown data directly from donorData
            const ehiData = donorData.Ehi || [];
            const unknownData = donorData.Unknown || [];

            // Calculate total amounts for Ehi and Unknown
            const totalEhi = ehiData.reduce((acc, item) => acc + parseFloat(item.total_amount), 0);
            const totalUnknown = unknownData.reduce((acc, item) => acc + parseFloat(item.total_amount), 0);

            // Prepare labels and quantities for the cashsofar pie chart
            const cashsofarLabels = ["Ehi + Unknown", "Unknown"];
            const cashsofarQuantities = [totalEhi + totalUnknown, totalUnknown];

            // Destroy existing charts if they exist
            if (myPieChart) myPieChart.destroy();
            if (myBarChart) myBarChart.destroy();
            if (myComboChart) myComboChart.destroy();
            if (cashsofarChart) cashsofarChart.destroy();

            // Data for the main pie chart (excluding cash)
            const labels = ["Rice", "Beans", "Clothes", "Medi"];
            const quantities = [totalRice, totalBeans, totalClothes, totalMedication];
            console.log("Quantities before plotItemsSofar:", quantities);

            // Plot the main pie chart
            plotItemsSofar(labels, quantities);

            // Plot the cashsofar pie chart
            plotCashSoFar(cashsofarLabels, cashsofarQuantities);

            // Prepare data for the bar chart from itemsInStock
            const filteredItemsInStock = itemsInStock.filter(item => item.item.toLowerCase() !== 'cash');
            const stockLabels = filteredItemsInStock.map(item => item.item);
            const stockQuantities = filteredItemsInStock.map(item => item.stock_quantity);
            console.log("stockLabels",stockLabels)
            console.log("stockQuantities",stockQuantities)
            console.log("disbursementData",disbursementData)


            // Plot the bar chart
            plotMaterialInStock(stockLabels, stockQuantities, disbursementData);

            // Uncomment if plotDisbursementData is used for line chart plotting
            // plotDisbursementData(disbursementData);

        } else {
            console.error("Error in response:", response.message);
            alert("Failed to fetch material data. Please try again.");
        }
    };

    xhttp.onerror = function() {
        console.error('Request failed.');
        alert("An error occurred while fetching material data. Please try again.");
    };

    xhttp.open("GET", url, true);
    xhttp.send();
}

let ageRangeChartInstance = null;
let genderChartInstance = null;
let maritalStatusChartInstance = null;
let stateChartInstance = null;




// segregation
// get-Segregation

var segregationData = []

function getSegregationData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        segregationData = response.data;
        console.log("disburseData",segregationData)
        // loopDisburseData(segregationData);
        loopSegregationData(segregationData);
    }


    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }

    xhttp.open("GET", '../backend/request.php?function=get-Segregation', true);

    xhttp.send();
}


function loopSegregationData(data) {
    var container = document.getElementById('segTbody');
    if (!container) {
        console.warn("segTbody container not found. Skipping data rendering.");
        return; 
    }

    container.innerHTML = ''; // Clear previous data
    var tr = "";
    var counter = 1001;

    if (data && data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var items = data[i].items; // Get the items array

            // Check if items exists and is an array
            if (!Array.isArray(items)) {
                console.warn(`Items for index ${i} is not an array or is undefined.`);
                items = []; // Set to an empty array if not valid
            }

            // Only use the first item for display
            var firstItem = items.length > 0 ? items[0] : { item: "No items", quantity: "0" }; 

            tr += `
                <tr class="ehi-tbody-tr">
                    <td class="ehi-td">${formatDate(data[i].date)}</td>
                    <td class="ehi-td">${counter}</td>
                    <td class="ehi-td">${data[i].user_pin}</td>
                    <td class="ehi-td">${data[i].gender}</td>
                    <td class="ehi-td">${firstItem.item}</td>
                    <td class="ehi-td flex-center">
                        <button onclick="showOptions(${i})" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
                            <img src="../assets/images/three-options.png" alt="" class="three-options">
                        </button>
                    </td>
                </tr>
            `;
            counter++;
        }

        container.innerHTML = tr; // Set the generated HTML to the container
    } else {
        container.innerHTML = "No data yet!";
    }
}

getSegregationData()

function filterSegregationData() {
    var gender = document.getElementById('genderFilter').value;
    var item = document.getElementById('itemFilter').value;

    // Start with the full segregation data
    let filteredData = segregationData;

    // Filter by gender if selected
    if (gender === 'Male' || gender === 'Female') {
        filteredData = filteredData.filter(f => f.gender === gender);
    }

    // Filter by item if selected
    if (item) {
        filteredData = filteredData.filter(f => 
            f.items.some(i => i.item.toLowerCase() === item.toLowerCase())
        );
    }

    // Check if filtered data has items
    if (filteredData.length > 0) {
        console.log("Filtered Data", filteredData);
        loopSegregationData(filteredData);
    } else {
        console.warn("No items found for the selected filters.");
        // Optionally, you can display a message in the UI
        document.getElementById('segTbody').innerHTML = "No data found.";
    }
}


var programData =null;
var chosen_file2 =null;
function onFileSelect2(event){
    chosen_file2 = event.target.files[0];
    var url = URL.createObjectURL(chosen_file2);
    var imageContent = `<img src="${url}" class="preview-image" style="width: 250px; height: 40px;" />`;
    var previewContainer = document.getElementById('preview');
    var motherPreviewContainer = document.getElementById('mother_preview');
    var btnSelect = document.getElementById('sltBtn');
    previewContainer.innerHTML = imageContent;
    previewContainer.style.display="block";
    motherPreviewContainer.style =`flex-direction:column;justify-content: flex-start;`
    btnSelect.innerHTML="Change Attachment?Click again";
}



function addProgramData() {
    var modals = document.querySelector('.modals');
    var modalContent = `
        <style>
            input, select {
                padding: 12px 17px;
                border-radius: 8px;
                border: 1px solid var(--Foundation-Primary-P400, #097B48);
                background: var(--Foundation-White-W300, #F6F6F6);
            }

            .modal-container {
                display: block;
                position: fixed;
                z-index: 12000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
            }

            .modal-content {
                background-color: #fefefe;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                border: 1px solid #888;
                width: 80%;
                max-height: 100vh;
                max-width: 750px;
                overflow-y: auto;
                border-radius: 8px;
            }

            .close {
                color: white;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }

            .add-text-header {
                background: #097B48;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
                margin-bottom: 4px;
                height: 35px;
                color: white;
                border-radius: 8px 8px 0 0;
            }

            .add-text-header h3 {
                margin: 0;
                font-family: Archivo;
                font-size: 24px;
                font-weight: 600;
            }

            .form_element {
                display: flex;
                flex-direction: column;
                margin-bottom: 1.5rem;
                width: 100%;
            }

            form {
                padding: 20px;
                font-family: Inter;
            }

            .three-forms {
                display: flex;
                justify-content: space-between;
                gap: 10px;
            }

            .save-button {
                display: flex;
                width: 118px;
                height: 37px;
                padding: 10px;
                justify-content: center;
                align-items: center;
                gap: 10px;
                border-radius: 10px;
                background: #097B48;
                color: #FFF;
                font-family: Archivo;
                font-size: 18px;
                font-weight: 600;
                border: 0;
                margin: 20px auto 0;
                cursor: pointer;
            }

            input[type="number"]::-webkit-outer-spin-button,
            input[type="number"]::-webkit-inner-spin-button {
                -webkit-appearance: none;
                margin: 0;
            }

            input[type="number"] {
                -moz-appearance: textfield;
            }
        </style>
        <div id="myModal" class="modal-container">
            <div class="modal-content">
                <div class="add-text-header">
                    <h3>Add Programme Data</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <form id="form">
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="beneficiary">Pin<em style="font-size:10px;color:red">(*Without the pin, nothing can be added)</em></label>
                            <input type="number" id="pin" required onchange="fetchPin()"  oninput="checkPinFilled()" placeholder="Enter Your Pin To Fetch User's Name"/>
                        </div>

                        <div class="form_element">
                            <label for="beneficiary">Name of beneficiary</label>
                            <input type="text" id="receiver" required  />
                        </div>
                    </div>

                    <div class="three-forms">
                        <div class="form_element">
                            <label for="Safety">Safety Net</label>
                            <select id="Safety" onchange="toggleDateFields('Safety', 'enrolled-date-safety', 'exited-date-safety')">
                                <option value=""></option>
                                <option value="enrolled">Enrolled</option>
                                <option value="exited">Exited</option>
                            </select>
                        </div>
                        <div class="form_element" id="enrolled-date-safety" style="display:none;">
                            <label for="enrolled-date">Date enrolled</label>
                            <input type="date" id="enrolled-date-safety-input" required  style="justify-content:unset !important;"/>
                        </div>
                        <div class="form_element" id="exited-date-safety" style="display:none;">
                            <label for="exited-date">Date exited</label>
                            <input type="date" id="exited-date-safety-input" required />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="Upliftment">Upliftment project</label>
                            <select id="Upliftment" onchange="toggleDateFields('Upliftment', 'enrolled-date-upliftment', 'exited-date-upliftment')">
                                <option value=""></option>
                                <option value="enrolled">Enrolled</option>
                                <option value="exited">Exited</option>
                            </select>
                        </div>
                        <div class="form_element" id="enrolled-date-upliftment" style="display:none;">
                            <label for="upliftment-enrolled-date">Date enrolled</label>
                            <input type="date" id="upliftment-enrolled-date-input" required />
                        </div>
                        <div class="form_element" id="exited-date-upliftment" style="display:none;">
                            <label for="upliftment-exited-date">Date exited</label>
                            <input type="date" id="upliftment-exited-date-input" required />
                        </div>
                        <div></div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="micro_credit">Referral to micro credit</label>
                            <select id="micro_credit">
                                <option value=""></option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="form_element">
                            <label for="Institution">Institution Referred To</label>
                            <input type="text" id="Institution" required />
                        </div>
                    </div>
                    <button type="button" id="save-btn" class="save-button" onclick="saveProgramData()">Save</button>
                </form>
            </div>
        </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}

// Function to show or hide date fields based on the selected status
function toggleDateFields(programId, enrolledDateId, exitedDateId) {
    var programSelect = document.getElementById(programId);
    var enrolledDate = document.getElementById(enrolledDateId);
    var exitedDate = document.getElementById(exitedDateId);

    if (programSelect.value === 'enrolled') {
        enrolledDate.style.display = 'flex';
        exitedDate.style.display = 'none';
    } else if (programSelect.value === 'exited') {
        enrolledDate.style.display = 'none';
        exitedDate.style.display = 'flex';
    } else {
        enrolledDate.style.display = 'none';
        exitedDate.style.display = 'none';
    }
}


function saveProgramData(){
    
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var modals = document.querySelector('.modals');
    var form = document.getElementById('form');
    
    const beneficiary = document.getElementById('receiver').value.trim();
    const pin = document.getElementById('pin').value.trim();
    const safety = document.getElementById('Safety').value.trim();
    const enrolledDate = document.getElementById('enrolled-date-safety-input').value.trim();
    const exitedDate = document.getElementById('exited-date-safety-input').value.trim();
    const upliftment = document.getElementById('Upliftment').value.trim();
    const upliftmentEnrolledDate = document.getElementById('upliftment-enrolled-date-input').value.trim();
    const upliftmentExitedDate = document.getElementById('upliftment-exited-date-input').value.trim();
    const microCredit = document.getElementById('micro_credit').value.trim();
    const institution = document.getElementById('Institution').value.trim();

    // Validate required fields
    // if (!beneficiary || !safety || !microCredit || !institution) {
    //     savebtn.disabled = false;
    //     savebtn.innerHTML = "Save";
    //     swal('Error', 'All fields are required. Please fill in all fields before saving.', 'error');
    //     return;
    // }

    if (!pin) {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Error', 'Pin field is  required. Please fill in  before saving.', 'error');
        return;
    }
    var formData = new FormData();
    formData.append('beneficiary', beneficiary);
    formData.append('pin', pin);
    formData.append('safety', safety);
    formData.append('enrolledDate', enrolledDate);
    formData.append('exitedDate', exitedDate);
    formData.append('upliftment', upliftment);
    formData.append('upliftmentEnrolledDate', upliftmentEnrolledDate);
    formData.append('upliftmentExitedDate', upliftmentExitedDate);
    formData.append('microCredit', microCredit);
    formData.append('institution', institution);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);

        // Reset the form and close the modal
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        
        swal('Success', "Record saved!", 'success');
        window.location.reload(); // Reload the page after saving
        getProgramData(); // Refresh data after saving
    }

    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=save-ProgramData', true);
   
    console.log("formData", formData);
    xhttp.send(formData);
}


function updateProgramData(programDataId){
    
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var modals = document.querySelector('.modals');
    var form = document.getElementById('form');
    
    const beneficiary = document.getElementById('receiver').value.trim();
    const pin = document.getElementById('pin').value.trim();
    const safety = document.getElementById('Safety').value.trim();
    const enrolledDate = document.getElementById('enrolled-date-safety-input').value.trim();
    const exitedDate = document.getElementById('exited-date-safety-input').value.trim();
    const upliftment = document.getElementById('Upliftment').value.trim();
    const upliftmentEnrolledDate = document.getElementById('upliftment-enrolled-date-input').value.trim();
    const upliftmentExitedDate = document.getElementById('upliftment-exited-date-input').value.trim();
    const microCredit = document.getElementById('micro_credit').value.trim();
    const institution = document.getElementById('Institution').value.trim();
    // const institution = document.getElementById('Institution').value.trim();

    // Validate required fields
    if (!pin) {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Error', 'All fields are required. Please fill in all fields before saving.', 'error');
        return;
    }

    var formData = new FormData();
    formData.append('beneficiary', beneficiary);
    formData.append('pin', pin);
    formData.append('safety', safety);
    formData.append('enrolledDate', enrolledDate);
    formData.append('exitedDate', exitedDate);
    formData.append('upliftment', upliftment);
    formData.append('upliftmentEnrolledDate', upliftmentEnrolledDate);
    formData.append('upliftmentExitedDate', upliftmentExitedDate);
    formData.append('microCredit', microCredit);
    formData.append('institution', institution);
    formData.append('programDataId', programDataId);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);

        // Reset the form and close the modal
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        
        swal('Success', "Record saved!", 'success');
        window.location.reload(); // Reload the page after saving
        getProgramData(); // Refresh data after saving
    }

    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=update-ProgramData', true);
   
    console.log("formData", formData);
    xhttp.send(formData);
}


function getProgramData(){

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        programData = response.programData;
        loopProgramData(programData);
    }

    xhttp.open("GET", '../backend/request.php?function=get-ProgramData', true);
    xhttp.send();
}

function capitalizeFirstLetter(word) {
    return word.charAt(0).toUpperCase() + word.slice(1);
}

function loopProgramData(data) {
    var container = document.getElementById('ProgramTbody');
    if (!container) {
        console.warn("Program container not found. Skipping data rendering.");
        return; // Exit the function if the container is not found
    }

    var tr = "";
    var counter = 1000;
    
    if (data && data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            counter++;
            const safetyStatus = data[i].safety;
            const upliftmentStatus = data[i].upliftment;

            tr += `
                <tr class="ehi-tbody-tr">
                    <td class="ehi-td" style="width:80px;text-align: center;">${formatDate(data[i].created_at)}</td>
                    <td class="ehi-td" style="width:50px;text-align: center;">${counter}</td>
                    <td class="ehi-td" style="width:220px;text-align: center;">${data[i].beneficiary}</td>
                    <td class="ehi-td" style="width:100px;text-align: center; color: ${safetyStatus === 'enrolled' ? 'green' : 'inherit'}; font-size: ${safetyStatus === 'enrolled' ? '1em' : 'inherit'}; font-weight: ${safetyStatus === 'enrolled' ? 'bold' : 'normal'};">${capitalizeFirstLetter(safetyStatus)}</td>
                    <td class="ehi-td" style="width:180px;text-align: center; color: ${upliftmentStatus === 'enrolled' ? 'green' : 'inherit'}; font-size: ${upliftmentStatus === 'enrolled' ? '1em' : 'inherit'}; font-weight: ${upliftmentStatus === 'enrolled' ? 'bold' : 'normal'};">${capitalizeFirstLetter(upliftmentStatus)}</td>
                    <td class="ehi-td" style="width:130px;text-align: center;">${data[i].institution}</td>
                    <td class="ehi-td flex-center" style="width:50px;text-align: center;">
                        <div style="position:relative;">
                            <!-- Button to show the dropdown -->
                            <button onclick="showOptions(${i})" class="three" style="cursor: pointer; background-color: transparent; border: none; outline: none;">
                                <img src="../assets/images/three-options.png" alt="" class="three-options">
                            </button>

                            <!-- Dropdown with dynamic ID based on 'i' -->
                            <div id="dropdown-${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
                                <button onclick="editProgramData(${data[i].id})" class="openModalBtnEdit option-button">
                                    <img src="/assets/images/edit.png"/> Edit
                                </button>   
                                <button onclick="viewProgramData(${data[i].id})" class="openModalBtnView option-button">
                                    <img src="/assets/images/view.png"/> View
                                </button>   
                                <button onclick="deleteProgramData(${data[i].id})" class="option-button">
                                    <img src="/assets/images/Delete.svg"/> Delete
                                </button>   
                            </div>
                        </div>
                    </td>
                </tr>
            `;
        }
        container.innerHTML = tr;
    } else {
        container.innerHTML = "No data yet!";
    }
}



getProgramData();

function editProgramData(programDataId) {
    var data = programData.find((programDatum) => {
        console.log("programDatum.id", programDatum.id)
        return programDatum.id == programDataId;
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
        <style>
            input, select {
                padding: 12px 17px;
                border-radius: 8px;
                border: 1px solid var(--Foundation-Primary-P400, #097B48);
                background: var(--Foundation-White-W300, #F6F6F6);
            }

            .modal-container {
                display: block;
                position: fixed;
                z-index: 12000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
            }

            .modal-content {
                background-color: #fefefe;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                border: 1px solid #888;
                width: 80%;
                max-height: 100vh;
                max-width: 750px;
                overflow-y: auto;
                border-radius: 8px;
            }

            .close {
                color: white;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }

            .add-text-header {
                background: #097B48;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
                margin-bottom: 4px;
                height: 35px;
                color: white;
                border-radius: 8px 8px 0 0;
            }

            .add-text-header h3 {
                margin: 0;
                font-family: Archivo;
                font-size: 24px;
                font-weight: 600;
            }

            .form_element {
                display: flex;
                flex-direction: column;
                margin-bottom: 1.5rem;
                width: 100%;
            }

            form {
                padding: 20px;
                font-family: Inter;
            }

            .three-forms {
                display: flex;
                justify-content: space-between;
                gap: 10px;
            }

            .save-button {
                display: flex;
                width: 118px;
                height: 37px;
                padding: 10px;
                justify-content: center;
                align-items: center;
                gap: 10px;
                border-radius: 10px;
                background: #097B48;
                color: #FFF;
                font-family: Archivo;
                font-size: 18px;
                font-weight: 600;
                border: 0;
                margin: 20px auto 0;
                cursor: pointer;
            }

            input[type="number"]::-webkit-outer-spin-button,
            input[type="number"]::-webkit-inner-spin-button {
                -webkit-appearance: none;
                margin: 0;
            }

            input[type="number"] {
                -moz-appearance: textfield;
            }
        </style>
        <div id="myModal" class="modal-container">
            <div class="modal-content">
                <div class="add-text-header">
                    <h3>Edit Programme Data</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <form id="form">
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="beneficiary">Pin</label>
                            <input type="number" id="pin" required onchange="fetchPin()" placeholder="Enter Your Pin" value="${data.user_pin}"/>
                        </div>

                        <div class="form_element">
                            <label for="beneficiary">Name of beneficiary</label>
                            <input type="text" id="receiver" required value="${data.beneficiary}" />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="Safety">Safety Net</label>
                            <select id="Safety" onchange="toggleDateFields('Safety', 'enrolled-date-safety', 'exited-date-safety')">
                                <option value=""></option>
                                <option value="enrolled" ${data.safety === 'enrolled' ? 'selected' : ''}>Enrolled</option>
                                <option value="exited" ${data.safety === 'exited' ? 'selected' : ''}>Exited</option>
                            </select>
                        </div>
                        <div class="form_element" id="enrolled-date-safety" style="display: ${data.safety === 'enrolled' ? 'flex' : 'none'};">
                            <label for="enrolled-date-safety-input">Date enrolled</label>
                            <input type="date" id="enrolled-date-safety-input" value="${data.enrolledDate || ''}" required />
                        </div>
                        <div class="form_element" id="exited-date-safety" style="display: ${data.safety === 'exited' ? 'flex' : 'none'};">
                            <label for="exited-date-safety-input">Date exited</label>
                            <input type="date" id="exited-date-safety-input" value="${data.exitedDate || ''}" required />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="Upliftment">Upliftment project</label>
                            <select id="Upliftment" onchange="toggleDateFields('Upliftment', 'enrolled-date-upliftment', 'exited-date-upliftment')">
                                <option value=""></option>
                                <option value="enrolled" ${data.upliftment === 'enrolled' ? 'selected' : ''}>Enrolled</option>
                                <option value="exited" ${data.upliftment === 'exited' ? 'selected' : ''}>Exited</option>
                            </select>
                        </div>
                        <div class="form_element" id="enrolled-date-upliftment" style="display: ${data.upliftment === 'enrolled' ? 'flex' : 'none'};">
                            <label for="upliftment-enrolled-date-input">Date enrolled</label>
                            <input type="date" id="upliftment-enrolled-date-input" value="${data.upliftmentEnrolledDate || ''}" required />
                        </div>
                        <div class="form_element" id="exited-date-upliftment" style="display: ${data.upliftment === 'exited' ? 'flex' : 'none'};">
                            <label for="upliftment-exited-date-input">Date exited</label>
                            <input type="date" id="upliftment-exited-date-input" value="${data.upliftmentExitedDate || ''}" required />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="micro_credit">Referral to micro credit</label>
                            <select id="micro_credit">
                                <option value=""></option>
                                <option value="Yes" ${data.microCredit === 'Yes' ? 'selected' : ''}>Yes</option>
                                <option value="No" ${data.microCredit === 'No' ? 'selected' : ''}>No</option>
                            </select>
                        </div>
                        <div class="form_element">
                            <label for="Institution">Institution Referred To</label>
                            <input type="text" id="Institution" required value="${data.institution || ''}" />
                        </div>
                    </div>
                    <button type="button" id="save-btn" class="save-button" onclick="updateProgramData(${data.id})">Update</button>
                </form>
            </div>
        </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}


function viewProgramData(programDataId) {
    var data = programData.find((programDatum) => {
        console.log("programDatum.id", programDatum.id);
        return programDatum.id == programDataId;
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
        <style>
            input, select {
                padding: 12px 17px;
                border-radius: 8px;
                border: 1px solid var(--Foundation-Primary-P400, #097B48);
                background: var(--Foundation-White-W300, #F6F6F6);
            }

            .modal-container {
                display: block;
                position: fixed;
                z-index: 12000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
            }

            .modal-content {
                background-color: #fefefe;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                border: 1px solid #888;
                width: 80%;
                max-height: 100vh;
                max-width: 750px;
                overflow-y: auto;
                border-radius: 8px;
            }

            .close {
                color: white;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }

            .add-text-header {
                background: #097B48;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
                margin-bottom: 4px;
                height: 35px;
                color: white;
                border-radius: 8px 8px 0 0;
            }

            .add-text-header h3 {
                margin: 0;
                font-family: Archivo;
                font-size: 24px;
                font-weight: 600;
            }

            .form_element {
                display: flex;
                flex-direction: column;
                margin-bottom: 1.5rem;
                width: 100%;
            }

            form {
                padding: 20px;
                font-family: Inter;
            }

            .three-forms {
                display: flex;
                justify-content: space-between;
                gap: 10px;
            }

            .save-button {
                display: flex;
                width: 118px;
                height: 37px;
                padding: 10px;
                justify-content: center;
                align-items: center;
                gap: 10px;
                border-radius: 10px;
                background: #097B48;
                color: #FFF;
                font-family: Archivo;
                font-size: 18px;
                font-weight: 600;
                border: 0;
                margin: 20px auto 0;
                cursor: pointer;
            }

            input[type="number"]::-webkit-outer-spin-button,
            input[type="number"]::-webkit-inner-spin-button {
                -webkit-appearance: none;
                margin: 0;
            }

            input[type="number"] {
                -moz-appearance: textfield;
            }
        </style>
        <div id="myModal" class="modal-container">
            <div class="modal-content">
                <div class="add-text-header">
                    <h3>View Programme Data</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <form id="form">
                    <div class="three-forms">

                        <div class="form_element">
                            <label for="beneficiary">Name of Beneficiary</label>
                            <input type="text" id="beneficiary" value="${data.beneficiary}" readonly />
                        </div>
                    </div>

                    <div class="three-forms">

                        <div class="form_element">
                            <label for="Safety">Safety Net</label>
                            <select id="Safety" disabled>
                                <option value="${data.beneficiary}">${data.beneficiary}</option>
                            </select>
                        </div>

                        <div class="form_element">
                            <label for="enrolled-date-safety">Date Enrolled</label>
                            <input type="date" id="enrolled-date-safety" value="${data.enrolledDate || 'Still active'}" readonly />
                        </div>

                        <div class="form_element">
                            <label for="exited-date-safety">Date Exited</label>
                            <input type="date" id="exited-date-safety" value="${data.exitedDate || 'Still active'}" readonly />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="Upliftment">Upliftment Project</label>
                            <select id="Upliftment" disabled>
                                <option value=""></option>
                                <option value="enrolled" ${data.upliftment === 'enrolled' ? 'selected' : ''}>Enrolled</option>
                                <option value="exited" ${data.upliftment === 'exited' ? 'selected' : ''}>Exited</option>
                            </select>
                        </div>
                        <div class="form_element">
                            <label for="upliftment-enrolled-date">Date Enrolled</label>
                            <input type="date" id="upliftment-enrolled-date" value="${data.upliftmentEnrolledDate || 'Still active'}" readonly />
                        </div>
                        <div class="form_element">
                            <label for="upliftment-exited-date">Date Exited</label>
                            <input type="date" id="upliftment-exited-date" value="${data.upliftmentExitedDate || 'Still active'}" readonly />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label for="micro_credit">Referral to Micro Credit</label>
                            <select id="micro_credit" disabled>
                                <option value=""></option>
                                <option value="Yes" ${data.microCredit === 'Yes' ? 'selected' : ''}>Yes</option>
                                <option value="No" ${data.microCredit === 'No' ? 'selected' : ''}>No</option>
                            </select>
                        </div>
                        <div class="form_element">
                            <label for="Institution">Institution Referred To</label>
                            <input type="text" id="Institution" value="${data.institution || ''}" readonly />
                        </div>
                    </div>
                    <button type="button" class="save-button" onclick="closeModal()">Close</button>
                </form>
            </div>
        </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}



function deleteProgramData(programDataId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('programDataId', programDataId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getProgramData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
        
            xhttp.open("POST", '../backend/request.php?function=delete-ProgramData', true);
            console.log("formData", formData)
            xhttp.send(formData);
        }
      });
}


//disbursement
var disburseData = null;
let inputCount = 0;

function addInputs() {
    inputCount++;  // Increment the counter for unique IDs

    // Create a div to contain the new input fields and remove button
    const container = document.createElement('div');
    container.classList.add('input-container');

    // Create a select element (dropdown) for the item
    const select = document.createElement('select');
    select.name = 'item[]';  // Change to 'item[]' to match the save function
    select.id = `input1_${inputCount}`;  // Assign a unique ID

    // Create the options for the select element
    const options = [' ','Cash', 'Medication', 'Rice', 'Beans', 'Clothes'];
    options.forEach(optionText => {
        const option = document.createElement('option');
        option.value = optionText;  // Set the value of the option
        option.text = optionText;   // Set the display text of the option
        select.appendChild(option); // Add option to select element
    });

    // Create the second input element for quantity
    const input2 = document.createElement('input');
    input2.type = 'text';
    input2.name = 'quantity[]';  // Change to 'quantity[]' to match the save function
    input2.id = `input2_${inputCount}`;  // Assign a unique ID
    input2.placeholder = 'Enter Quantity received';
    input2.style.marginLeft = "5px";

    // Create a remove button
    const deleteText = document.createElement('span');
    deleteText.innerText = 'Delete'; // Set the text content
    deleteText.style.color = "red";  // Set text color to red
    deleteText.style.cursor = "pointer"; // Make it look like a clickable item
    deleteText.style.marginLeft = "7px"; // Add some margin for spacing
    deleteText.style.fontWeight = "400"; 
    deleteText.style.fontSize = "12px"; 

    // Add event listener for the click event
    deleteText.onclick = function() {
        container.remove();  // Remove the entire input block when clicked
        checkQuantities(); // Recheck quantities after removal
        checkInputs();     // Recheck inputs after removal
    };

    // Attach event listeners to the dropdown and input fields for real-time validation
    select.addEventListener('change', () => {
        checkInputs();     // Validate input completion for enabling the Add button
        checkQuantities(); // Run additional quantity-specific checks
    });
    
    input2.addEventListener('input', () => {
        checkInputs();     // Validate input completion for enabling the Add button
        checkQuantities(); // Run additional quantity-specific checks
    });

    // Append the dropdown and other elements to the container
    container.appendChild(select);
    container.appendChild(input2);
    container.appendChild(deleteText);

    // Append the container to the input-container div
    document.getElementById('input-container').appendChild(container);

    // Re-check the inputs to disable or enable the button
    checkInputs();
    checkQuantities(); // Ensure initial quantity checks are performed
}


function checkQuantities() {
    var savebtn = document.getElementById('save-btn');
    const itemInputs = document.querySelectorAll('select[name="item[]"]'); // Now targeting <select>
    const quantityInputs = document.querySelectorAll('input[name="quantity[]"]');

    let isValid = true; // Track overall validity

    itemInputs.forEach((itemInput, index) => {
        const itemName = itemInput.value.trim().toLowerCase(); // Get selected option value
        const quantityInput = quantityInputs[index];
        const enteredQuantity = quantityInput.value.trim();

        // Only proceed if both itemName and enteredQuantity have values
        if (itemName && enteredQuantity) {
            // Find the item in the itemsInStock array
            const itemData = itemsInStock.find(item => item.item.trim().toLowerCase() === itemName);

            if (itemData) {
                const availableQuantity = parseInt(itemData.stock_quantity, 10);
                const enteredQty = parseInt(enteredQuantity, 10);

                // Check quantities
                if (enteredQty > availableQuantity) {
                    console.warn(`Quantity for ${itemName} exceeds available amount!`);
                    quantityInput.setCustomValidity(`${itemName} quantity cannot exceed ${availableQuantity}.`);
                    quantityInput.reportValidity(); 
                    savebtn.innerHTML = 'Exceeded';
                    savebtn.disabled = true;
                    savebtn.style.backgroundColor = "#77DD77";
                    isValid = false; // Mark as invalid
                } else {
                    quantityInput.setCustomValidity(''); 
                    savebtn.innerHTML = 'Save';
                    savebtn.disabled = false;
                    savebtn.style.backgroundColor = "green";
                }
            } else {
                quantityInput.setCustomValidity('Item not found.');
                quantityInput.reportValidity(); 
                isValid = false; // Mark as invalid
            }
        } else {
            quantityInput.setCustomValidity(''); // Clear validity if either input is empty
        }
    });

    // Ensure button reflects the overall validity
    // savebtn.disabled = !isValid; 
}

function checkInputs() {
    const itemInputs = document.querySelectorAll('select[name="item[]"]'); // Now targeting <select>
    const quantityInputs = document.querySelectorAll('input[name="quantity[]"]');
    const addButton = document.getElementById('add-btn');

    let allFilled = true;

    // Check if both item and quantity fields are filled for all sets
    itemInputs.forEach((itemInput, index) => {
        const quantityInput = quantityInputs[index];
        if (!itemInput.value.trim() || !quantityInput.value.trim()) {
            allFilled = false;
        }
    });

    // Enable or disable "Add Items" button based on field status
    if (allFilled) {
        addButton.disabled = false; // Enable the button if all fields are filled
        addButton.innerHTML = "Add Item"; // Set the button text
        addButton.style.backgroundColor = "#097B48"; // Original color
    } else {
        addButton.disabled = true; // Disable the button if any field is empty
        addButton.innerHTML = "Disabled"; // Set disabled text
        addButton.style.backgroundColor = "#77DD77"; // Change color to indicate it's disabled
    }
}


// Call this function on input change events
document.querySelectorAll('input[name="item[]"], input[name="quantity[]"]').forEach(input => {
    input.addEventListener('input', checkInputs);
});


var itemsInStock = []; // Declare itemsInStock globally

function fetchItemsInStock(callback) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState === 4) {
            if (this.status === 200) {
                const response = JSON.parse(this.responseText);
                itemsInStock = (response.data && response.data.itemsInStock) || [];
                callback(itemsInStock); // Pass the data to the callback
            } else {
                console.error('Error fetching available quantity:', this.statusText);
            }
        }
    };
    
    xhttp.open("GET", '../backend/request.php?function=get-dashboardData', true);
    xhttp.send();
}


// Call fetchItemsInStock to load itemsInStock data and then check quantities
fetchItemsInStock(checkQuantities);



function checkPinFilled() {
    const pinInput = document.getElementById('pin').value.trim();
    const addButton = document.getElementById('add-btn');
    const receiverInput = document.getElementById('receiver');
    const receiverInputValue = receiverInput.value.trim();

    // Enable the button only if both the pin and receiver input are filled
    if (pinInput) {
        addButton.disabled = false; // Enable the button
        addButton.style.backgroundColor = "#097B48"; // Reset to the original color
        addButton.innerHTML = "Add Items"; // Set a meaningful text for the button
    } else {
        addButton.disabled = true; // Disable the button
        addButton.style.backgroundColor = "#77DD77"; // Change color to indicate it's disabled
        addButton.innerHTML = "Disabled"; // Set the disabled text
        // Clear the receiver name if pin is empty
        if (!pinInput) {
            receiverInput.value = ''; // Clear the receiver name when pin is empty
        }
    }
}


function fetchPin() {
    const receiverPin = document.getElementById('pin').value.trim();

    // Check if the receiver's pin is not empty
    if (receiverPin) {
        // Create an XMLHttpRequest object
        var xhr = new XMLHttpRequest();
        xhr.open("GET", '../backend/request.php?function=get-all-userdata', true);
       
        xhr.setRequestHeader('Content-Type', 'application/json');

        // Define a callback function
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the response
                var response = JSON.parse(xhr.responseText);
                console.log("response", response);

                // Ensure userdata is available
                if (response.userdata && Array.isArray(response.userdata)) {
                    var userData = response.userdata;

                    // Find the user by pin
                    const user = userData.find(user => user.user_pin === receiverPin);
                    const Image = user.image;
                    // console.log("userImage:", user.image);
                    if (user) {
                        // Populate the receiver (name) input field with the found user's full name
                        document.getElementById('receiver').value = `${user.first_name} ${user.last_name}`;
                    } else {
                        // alert('No user found with that pin');
                        swal('Oppps!!!', "No user found with that pin! Try again", 'error');
                        document.getElementById('receiver').value = '';  
                        document.getElementById('pin').value = '';  
                        
                        // Clear name field if no user is found
                    }
                } else {
                    swal('Oppps!!!', "No userdata found or request failed", 'error');
                    // alert('No userdata found or request failed');
                }
            } else if (xhr.readyState === 4) {
                // Handle errors
                console.error('Error fetching name:', xhr.responseText);
            }
        };

        // Send the request
        xhr.send();
    } else {
        swal('Oppps!!!', "Please enter a pin", 'error');
        // alert('Please enter a pin');
    }
}

function fetchQuantityItem() {
    const receiverPin = document.getElementById('pin').value.trim();

    // Check if the receiver's pin is not empty
    if (receiverPin) {
        // Create an XMLHttpRequest object
        var xhr = new XMLHttpRequest();
        xhr.open("GET", '../backend/request.php?function=get-all-userdata', true);
       
        xhr.setRequestHeader('Content-Type', 'application/json');

        // Define a callback function
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Parse the response
                var response = JSON.parse(xhr.responseText);
                console.log("response", response);

                // Ensure userdata is available
                if (response.userdata && Array.isArray(response.userdata)) {
                    var userData = response.userdata;

                    // Find the user by pin
                    const user = userData.find(user => user.user_pin === receiverPin);
                    
                    if (user) {
                        // Populate the receiver (name) input field with the found user's full name
                        document.getElementById('receiver').value = `${user.first_name} ${user.last_name}`;
                    } else {
                        alert('No user found with that pin');
                        document.getElementById('receiver').value = '';  // Clear name field if no user is found
                    }
                } else {
                    alert('No userdata found or request failed');
                }
            } else if (xhr.readyState === 4) {
                // Handle errors
                console.error('Error fetching name:', xhr.responseText);
            }
        };

        // Send the request
        xhr.send();
    } else {
        alert('Please enter a pin');
    }
}

function addDisbursementData() {
    var modals = document.querySelector('.modals');
    var modalContent = `
        <style>
            input, select{
                padding: 12px 50px;
                border-radius: 8px;
                border: 1px solid var(--Foundation-Primary-P400, #097B48);
                background: var(--Foundation-White-W300, #F6F6F6);
            }
            #input-container{
                display:flex;
                flex-wrap:wrap;
                align-items:center;
            }
            .modal-container{
                display: none; 
                position: fixed;
                z-index: 12000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
            }
            .modal-content {
                background-color: #fefefe;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 80%;
                max-height: 100vh;
                max-width: 900px;
                overflow-y: scroll;
            }
            .close {
                color: white;
                font-size: 28px;
                font-weight: bold;
            }
            .close:hover, .close:focus {
                color: black;
                cursor: pointer;
            }
            .add-text-header {
                background: #097B48;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
                height: 35px;
                color: white;
            }
            .nav-btn {
                display: flex;
                width: 110px;
                height: 40px;
                justify-content: center;
                align-items: center;
                border-radius: 10px;
                background: #097B48;
                border: 0;
                color: #FFF;
                font-family: Roboto;
                font-size: 17px;
                cursor: pointer;
            }
            .save-button {
                width: 118px;
                height: 37px;
                background: #097B48;
                color: #FFF;
                border-radius: 10px;
                border: 0;
                margin-left:50% !important ;
                margin-top: 20px;
            }
            .add-recept {
                background-color: transparent;
                color: #097B48;
                font-family: Inter;
                cursor: pointer;
            }
            .form_element {
                margin-bottom: 1.5rem;
                width: 100%;
            }
            form {
                padding: 20px;
                font-family: Inter;
            }
                #preview"{
                padding: 12px 17px;
                border-radius: 8px;
                border: 1px solid var(--Foundation-Primary-P400, #097B48);
                background: var(--Foundation-White-W300, #F6F6F6);
}
                }
        </style>
        <div id="myModal" class="modal-container">
            <div class="modal-content">
                <div class="add-text-header">
                    <h3>Add</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <form id="form" class="dynamicForm">

                    <div class="three-forms">
                        <div class="form_element">
                            <label for="Item">Pin<em style="font-size:10px;color:red">(*Without the pin, nothing can be added)</em></label>
                            <input type="number" id="pin" required onchange="fetchPin()" oninput="checkPinFilled()" placeholder="Enter Your Pin"/>
                        </div>

                        <div class="form_element">
                            <label for="Donor">Name of Receiver</label>
                            <input type="text" id="receiver" required  disabled/>
                        </div>

                        <div class="form_element">
                            <label for="Date">Date</label>
                            <input type="date" id="Date" required/>
                        </div>
                        </div>
<div class="three-forms">

                        <div></div>
                        <div class="form_element">
                            <label for="status">Status</label>
                            <select id="status" disabled>
                                <option></option>
                                <option>Claimed</option>
                                <option selected>Unclaimed</option>
                            </select>
                        </div>
                        <div></div>
                    </div>
                    <div class="form_element">
                     

                        <button type="button" onclick="addInputs()" id="add-btn" disabled style="width:20%; margin-top:10px; background-color:#77DD77; color:white; margin-left:680px; padding:5px 0; border-color:transparent; outline:none;">Disabled</button>



                        <div style="display:flex; margin:10px 0; justify-content:space-between; align-items:center;border-bottom:1px solid gray">
                            <h4>Item(s)</h4>
                            <h4>Quantity</h4>
                        </div>
                        <div id="input-container" style="display:flex; margin:10px auto; width:80%; text-align:center; justify-content:center;" class="input-container"></div>
                    </div>
                    <button type="button" class="save-button" onclick="saveDisbursementData()" id="save-btn" style="margin:0 auto;">Save</button>  
                </form>
            </div>
        </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}


function saveDisbursementData() {
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    const form = document.getElementById('form');
    const receiver = document.getElementById('receiver').value.trim();
    const pin = document.getElementById('pin').value.trim();
    const date = document.getElementById('Date').value;
    const status = document.getElementById('status').value;

    if (!receiver || !pin || !date) {
        swal('Warning', "Please fill in all required fields!", 'warning');
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        return;
    }

    // Capture item and quantity inputs
    const itemInputs = document.querySelectorAll('select[name="item[]"]');
    const quantityInputs = document.querySelectorAll('input[name="quantity[]"]');

    var formData = new FormData();
    formData.append('receiver', receiver);
    formData.append('pin', pin);
    formData.append('date', date);
    formData.append('status', status);

    // Append each item and corresponding quantity
    itemInputs.forEach((itemInput, index) => {
        const enteredItem = itemInput.value.trim();
        const enteredQuantity = quantityInputs[index].value.trim();
        formData.append(`item[${index}]`, enteredItem);
        formData.append(`quantity[${index}]`, enteredQuantity);
    });

    // Debug: Log form data
    console.log('Form Data Content:');
    for (var pair of formData.entries()) {
        console.log(`${pair[0]}: ${pair[1]}`);
    }

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        if (xhttp.status >= 200 && xhttp.status < 300) {
            form.reset();
            
            getDisburseData();
            document.querySelector('.modals').style.display = 'none';
            savebtn.disabled = false;
            savebtn.innerHTML = "Save";
            swal('Success', "Record saved!", 'success');
            window.location.reload();
        } else {
            savebtn.disabled = false;
            savebtn.innerHTML = "Save";
            swal('Error', "An error occurred while saving the record. Please try again.", 'error');
        }
    };
    xhttp.onerror = function() {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "A network error occurred. Please check your connection and try again!", 'error');
    };
    xhttp.open("POST", '../backend/request.php?function=save-disburseData', true);
    xhttp.send(formData);
}


// function saveDisbursementData() {
//     // Your existing saveDisbursementData code remains the same
//     var savebtn = document.getElementById('save-btn');
//     savebtn.innerHTML = 'Saving...';
//     savebtn.disabled = true;
//     var modals = document.querySelector('.modals');
//     var form = document.getElementById('form');
//     const receiver = document.getElementById('receiver').value.trim();
//     const pin = document.getElementById('pin').value.trim();
//     const date = document.getElementById('Date').value;
//     const status = document.getElementById('status').value;

//     if (!receiver || !pin || !date) {
//         swal('Warning', "Please fill in all required fields!", 'warning');
//         savebtn.disabled = false;
//         savebtn.innerHTML = "Save";
//         return;
//     }

//     const itemInputs = document.querySelectorAll('input[name="item[]"]');
//     const quantityInputs = document.querySelectorAll('input[name="quantity[]"]');

//     var formData = new FormData();
//     formData.append('receiver', receiver);
//     formData.append('pin', pin);
//     formData.append('date', date);
//     formData.append('status', status);
    

//     let isValid = true;
//     itemInputs.forEach((itemInput, index) => {
//         const enteredQuantity = parseInt(quantityInputs[index].value.trim(), 10);
//         const availableQuantity = parseInt(itemInput.dataset.availableQuantity, 10);

//         if (enteredQuantity > availableQuantity) {
//             swal('Warning', `Quantity for ${itemInput.value} cannot exceed ${availableQuantity}.`, 'warning');
//             isValid = false;
//         }

//         formData.append(`item[${index}]`, itemInput.value.trim());
//         formData.append(`quantity[${index}]`, enteredQuantity);
//     });

//     if (!isValid) {
//         savebtn.disabled = false;
//         savebtn.innerHTML = "Save";
//         return;
//     }

//     for (var pair of formData.entries()) {
//         console.log(`${pair[0]}: ${pair[1]}`);
//     }
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function() {
//         if (xhttp.status >= 200 && xhttp.status < 300) {
//             form.reset();
//             modals.style.display = 'none';
//             savebtn.disabled = false;
//             savebtn.innerHTML = "Save";
//             swal('Success', "Record saved!", 'success');
//             // location.reload();
//         } else {
//             savebtn.disabled = false;
//             savebtn.innerHTML = "Save";
//             swal('Error', "An error occurred while saving the record. Please try again.", 'error');
//         }
//     };
//     xhttp.onerror = function() {
//         savebtn.disabled = false;
//         savebtn.innerHTML = "Save";
//         swal('Sorry', "A network error occurred. Please check your connection and try again!", 'error');
//     };
//     xhttp.open("POST", '../backend/request.php?function=save-disburseData', true);
//     xhttp.send(formData);
// }

function getDisburseData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
    //    var disburseData = response.data.sort((a, b) => b.id - a.id);
        //  disburseData = response.data.sort((a, b) => new Date(b.date) - new Date(a.date));

         disburseData = response.data.sort((a, b) => {
            return new Date(b.date) - new Date(a.date) || b.id - a.id;
        });

        console.log("disburseData::::", disburseData)
        // console.log("disburseData",disburseData)
        loopDisburseData(disburseData);
        // loopSegregationData(disburseData);
    }


    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }

    xhttp.open("GET", '../backend/request.php?function=get-disburseData', true);

    xhttp.send();
}


function loopDisburseData(data) {
    var container = document.getElementById('disburseTbody');

    if (!container) {
        console.warn("Disbursement container not found. Skipping data rendering.");
        return; // Exit the function if the container is not found
    }

    var tr = "";
    var counter = 1001; // Start counter from 1001

    if (data && data.length > 0) {
        data.sort((a, b) => b.id - a.id || new Date(b.date) - new Date(a.date));

        for (var i = 0; i < data.length; i++) {
            var remainingItems = data[i].items && data[i].items.length > 0 ? data[i].items : []; // Ensure items array exists
            var firstItem = remainingItems.length > 0 ? remainingItems[0] : null; // Get the first item if it exists
            // console.log("data[i]", data[i]);

            tr += `
                <tr class="ehi-tbody-tr">
                <td class="ehi-td">${data[i].date}</td>
                    <td class="ehi-td">${counter}</td> <!-- Counter -->

                    <td class="ehi-td"><img class="profile-image" src="${homepageUrl}/uploads/${data[i]?.image}" alt="" /></td>
                    <td class="ehi-td">${data[i].receiver}</td>
                    
                    <td class="ehi-td" style="color: ${data[i].status === 'CLAIMED' ? 'green' : 'black'}; font-weight: ${data[i].status === 'CLAIMED' ? '900' : 'normal'};">
                        ${data[i].status}
                    </td>
                    
                    <td class="ehi-td" style="position: relative; cursor:pointer;" onclick="showMiniTable(event, ${JSON.stringify(remainingItems).replace(/"/g, '&quot;')})">
                        ${remainingItems.length > 0 ? 'Click to Preview...' : 'No Items'}
                    </td>
                    
                    <!-- Options Dropdown -->
                    <td class="ehi-td flex-center">
                        <div style="position:relative;">
                            <button onclick="showOptions(${i})" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
                                <img src="../assets/images/three-options.png" alt="" class="three-options">
                            </button>

                            <div id="dropdown-${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
                                <button onclick="editDisbursementData(${data[i].disbursement_id})" class="openModalBtnEdit option-button">
                                    <img src="/assets/images/edit.png"/> Edit
                                </button>   

                                <button onclick="viewDisbursementData(${data[i].disbursement_id})" class="openModalBtnEdit option-button">
                                    <img src="/assets/images/view.png"/> View
                                </button>   

                                <button onclick="printVoucher(${data[i].disbursement_id})" class="openModalBtnView option-button">
                                    <img src="/assets/images/printvector.svg"/> Print Voucher
                                </button>   

                                <button onclick="deleteDisbursementData(${data[i].disbursement_id})" class="option-button">
                                    <img src="/assets/images/Delete.svg"/> Delete
                                </button>   
                            </div>
                        </div>
                    </td>
                </tr>
            `;

            counter++; // Increment the counter for each receiver
        }

        // Set the generated HTML to the container
        container.innerHTML = tr;
    } else {
        container.innerHTML = "No data yet!";
    }
}


// function loopDisburseData(data) {
//     console.log("data", data);
//     var container = document.getElementById('disburseTbody');

//     if (!container) {
//         console.warn("Bsheet container not found. Skipping data rendering.");
//         return; // Exit the function if the container is not found
//     }

//     var tr = "";
//     var counter = 1001; // Start counter from 1001

//     if (data && data.length > 0) {
//         for (var i = 0; i < data.length; i++) {
//             // Only take the first item from the items array
//             if (data[i].items.length > 0) {
//                 var allItem = data[i].items[i]; // Get the all the item
//                 var firstItem = data[i].items[0]; // Get the first item
//                 // var remainingItems = data[i].items.slice(1); // Get remaining items
//                 var remainingItems = data[i].items; // Get all items

//                 tr += `
//                     <tr class="ehi-tbody-tr">
//                         <td class="ehi-td">${counter}</td> <!-- Counter -->
//                         <td class="ehi-td">${data[i].receiver}</td>
//                         <td class="ehi-td">${data[i].date}</td>
//                  <td class="ehi-td" style="color: ${data[i].status === 'CLAIMED' ? 'green' : 'black'}; font-weight: ${data[i].status === 'CLAIMED' ? '900' : 'normal'};">
//     ${data[i].status}
// </td>

                       
                      
//                         <td class="ehi-td" style="position: relative; cursor:pointer;" onclick="showMiniTable(event, ${JSON.stringify(remainingItems).replace(/"/g, '&quot;')})">
//                             Click to Preview...
//                         </td>
                        
//                         <!-- First Item with ellipsis -->

                        
//                         <!-- First Quantity with ellipsis -->
//                         <td class="ehi-td flex-center">
//                             <div style="position:relative;">
//                                 <button onclick="showOptions(${i})" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
//                                     <img src="../assets/images/three-options.png" alt="" class="three-options">
//                                 </button>

//                                 <div id="${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">

//                                     <button onclick="editDisbursementData(${data[i].disbursement_id})" class="openModalBtnEdit option-button">
//                                         <img src="/assets/images/edit.png"/> Edit
//                                     </button>   

//                                       <button onclick="viewDisbursementData(${data[i].disbursement_id})" class="openModalBtnEdit option-button">
//                                         <img src="/assets/images/view.png"/> View
//                                     </button>   


//                                     <button onclick="printVoucher(${data[i].disbursement_id})" class="openModalBtnView option-button">
//                                         <img src="/assets/images/printvector.svg"/> Print Voucher
//                                     </button>   

//                                     <button onclick="deleteDisbursementData(${data[i].disbursement_id})" class="option-button">
//                                         <img src="/assets/images/Delete.svg"/> Delete
//                                     </button>   
//                                 </div>
//                             </div>
//                         </td>
//                     </tr>
//                 `;
//                 counter++; // Increment the counter for each receiver
//             }
//         }

//         if (container) {
//             container.innerHTML = tr; // Set the generated HTML to the container
//         }
//     } else {
//         if (container) {
//             container.innerHTML = "No data yet!";
//         }
//     }
// }

// function loopDisburseData(data) {
//     var container = document.getElementById('disburseTbody');

//     if (!container) {
//         console.warn("Disbursement container not found. Skipping data rendering.");
//         return; // Exit the function if the container is not found
//     }

//     var tr = "";
//     var counter = 1001; // Start counter from 1001

//      if (data && data.length > 0) {
//         for (var i = 0; i < data.length; i++) {
//             // Ensure there are items in the array
//             if (data[i].items.length > 0) {
//                 var firstItem = data[i].items[0]; // Get the first item
//                 var remainingItems = data[i].items; // Get all items (for preview)
// console.log("data[i]", data[i])

//                 tr += `
//                     <tr class="ehi-tbody-tr">
//                         <td class="ehi-td">${counter}</td> <!-- Counter -->
//                         <td class="ehi-td">${data[i].receiver}</td>
//                         <td class="ehi-td">${data[i].date}</td>
//                         <td class="ehi-td" style="color: ${data[i].status === 'CLAIMED' ? 'green' : 'black'}; font-weight: ${data[i].status === 'CLAIMED' ? '900' : 'normal'};">
//                             ${data[i].status}
//                         </td>
                        
//                         <td class="ehi-td" style="position: relative; cursor:pointer;" onclick="showMiniTable(event, ${JSON.stringify(remainingItems).replace(/"/g, '&quot;')})">
//                             Click to Preview...
//                         </td>
                        
//                         <!-- Options Dropdown -->
//                         <td class="ehi-td flex-center">
//                             <div style="position:relative;">
//                                 <button onclick="showOptions(${i})" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
//                                     <img src="../assets/images/three-options.png" alt="" class="three-options">
//                                 </button>

//                                 <div id="dropdown-${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
//                                     <button onclick="editDisbursementData(${data[i].disbursement_id})" class="openModalBtnEdit option-button">
//                                         <img src="/assets/images/edit.png"/> Edit
//                                     </button>   

//                                     <button onclick="viewDisbursementData(${data[i].disbursement_id})" class="openModalBtnEdit option-button">
//                                         <img src="/assets/images/view.png"/> View
//                                     </button>   

//                                     <button onclick="printVoucher(${data[i].disbursement_id})" class="openModalBtnView option-button">
//                                         <img src="/assets/images/printvector.svg"/> Print Voucher
//                                     </button>   

//                                     <button onclick="deleteDisbursementData(${data[i].disbursement_id})" class="option-button">
//                                         <img src="/assets/images/Delete.svg"/> Delete
//                                     </button>   
//                                 </div>
//                             </div>
//                         </td>
//                     </tr>
//                 `;
//                 counter++; // Increment the counter for each receiver
//             }
//         }

//         // Set the generated HTML to the container
//         container.innerHTML = tr;
//     } else {
//         container.innerHTML = "No data yet!";
//     }
// }




getDisburseData();

function printPage() {
    // Get the modal content
    // var modalContent = document.querySelector('.modal-content').innerHTML;
    // var modalContent = document.getElementById('form').innerHTML;
    var modalContent = document.querySelector('.dynamicForm').innerHTML;

    // Create a new window for printing
    var printWindow = window.open('', '', 'height=600,width=800');
    
    // Write the HTML structure for the print window
    printWindow.document.write(`
        <html>
        <head>
            <title>Print</title>
        </head>
        <body>

        <div style="margin:auto;">
           
                
                ${modalContent}
        </div>

        
        </body>
        </html>
    `);
    
    // Close the document to render the content
    printWindow.document.close();
    printWindow.focus(); // Focus on the new window

    // Trigger the print dialog
    printWindow.print();

    // Close the print window after printing
    printWindow.close();
}

function editDisbursementData(DisburseDataId) {
    // Convert DisburseDataId to string to ensure type consistency
    var data = disburseData.find((disburseDatum) => {
        // Ensure both are compared as strings
        return disburseDatum.disbursement_id === String(DisburseDataId);
    });

    // console.log("Found Data:", data);

    // Check if data is found
    if (!data) {
        console.error("No data found for DisburseDataId:", DisburseDataId);
        return;
    }

    var modals = document.querySelector('.modals');
    var modalContent = `
    <style>
        input,select {
            padding: 12px 17px;
            border-radius: 8px;
            width:100%;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        }

        #input-container {
            display: flex;
            flex-direction: column;
            margin: 10px 0;
        }

        .modal-container {
            display: none; 
            position: fixed; 
            z-index: 12000; 
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); 
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 900px;
            overflow-y: scroll; 
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
            background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .save-button {
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-weight: 600;
            margin-left: 125px;
            margin-top: 20px;
        }

        .form_element {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-bottom: 1.5rem;
            width: 100%;
        }

        .input-container {
            width: 100%;
            border-collapse: collapse;
            display: flex;
            flex-direction: column;
        }

        .input-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .input-row input {
            flex: 1;
            margin-left: 5px;
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <div class="add-text-header">
                <p>
                <h3>Edit</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
            <form id="form" class="dynamicForm" style="padding:5px 15px; name="sope">
                
        <div class="three-forms" >
            <div class="form_element">
                <label for="Donor">Name of Receiver</label>
                <input type="text" id="receiver" name="receiver" required value="${data.receiver}" disabled/>
            </div>
            <div class="form_element">
                <label for="Item">Pin</label>
                <input type="text" id="pin" name="pin" required value="${data.user_pin}" disabled/>
            </div>
            <div class="form_element">
                <label for="Date">Date</label>
                <input type="date" id="Date" name="date" required value="${data.date}" disabled/>
            </div>
        </div>

<div class="three-forms">
            <div></div>
        <select id="status" style="margin:10px 0">
                <option value="" ${data.status === "" ? "selected" : ""}></option>
                <option value="CLAIMED" ${data.status === "CLAIMED" ? "selected" : ""}>CLAIMED</option>
                <option value="UNCLAIMED" ${data.status === "UNCLAIMED" ? "selected" : ""}>UNCLAIMED</option>
            </select>
            
            <div></div>
    </div>

<div class="form_element">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h4>Item(s)</h4>
        <h4>Quantity</h4>
    </div>
    <div id="input-container" class="input-container">
        ${data.items.map((item, index) => `
            <div class="input-row">
                <input type="text" name="item[]" value="${item.item}" placeholder="Item Name"  disabled/>
                <input type="number" name="quantity[]" value="${item.quantity}" placeholder="Quantity" disabled/>
            </div>
        `).join('')}
    </div>
</div>


                <button type="button" class="save-button" onclick="updateDisbursementData(${data.disbursement_id})" id="save-btn" style="margin-left:46%;">Update</button>  
            </form>
        </div>
    </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewDisbursementData(DisburseDataId) {
    // Convert DisburseDataId to string to ensure type consistency
    var data = disburseData.find((disburseDatum) => {
        // Ensure both are compared as strings
        return disburseDatum.disbursement_id === String(DisburseDataId);
    });

    // console.log("Found Data:", data);

    // Check if data is found
    if (!data) {
        console.error("No data found for DisburseDataId:", DisburseDataId);
        return;
    }

    var modals = document.querySelector('.modals');
    var modalContent = `
    <style>
        input,select {
            padding: 12px 17px;
            border-radius: 8px;
            width:100%;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        }

        #input-container {
            display: flex;
            flex-direction: column;
            margin: 10px 0;
        }

        .modal-container {
            display: none; 
            position: fixed; 
            z-index: 12000; 
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); 
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 900px;
            overflow-y: scroll; 
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
            background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .save-button {
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-weight: 600;
            margin-left: 125px;
            margin-top: 20px;
        }

        .form_element {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-bottom: 1.5rem;
            width: 100%;
        }

        .input-container {
            width: 100%;
            border-collapse: collapse;
            display: flex;
            flex-direction: column;
        }

        .input-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .input-row input {
            flex: 1;
            margin-left: 5px;
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <div class="add-text-header">
                <p>
                <h3>View</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
            <form id="form" class="dynamicForm" style="padding:5px 15px;">
                
        <div class="three-forms">
            <div class="form_element">
                <label for="Donor">Name of Receiver</label>
                <input type="text" id="receiver" name="receiver" required value="${data.receiver}"  disabled/>
            </div>
            <div class="form_element">
                <label for="Item">Pin</label>
                <input type="text" id="pin" name="pin" required value="${data.user_pin}" disabled />
            </div>
            <div class="form_element">
                <label for="Date">Date</label>
                <input type="date" id="Date" name="date" required value="${data.date}" disabled />
            </div>
        </div>

<div class="three-forms">
            <div></div>
        <select id="status" style="margin:10px 0" disabled>
                <option value="${data.status}">${data.status}</option>
            </select>
            
            <div></div>
    </div>

<div class="form_element">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h4>Item(s)</h4>
        <h4>Quantity</h4>
    </div>
    <div id="input-container" class="input-container">
        ${data.items.map((item, index) => `
            <div class="input-row">
                <input type="text" name="item[]" value="${item.item}" placeholder="Item Name" disabled/>
                <input type="number" name="quantity[]" value="${item.quantity}" placeholder="Quantity" disabled/>
            </div>
        `).join('')}
    </div>
</div>


                <button type="button" class="save-button" onclick="updateDisbursementData(${data.disbursement_id})" id="save-btn" style="margin-left:46%;">Update</button>  
            </form>
        </div>
    </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}

function printVoucher(DisburseDataId) {
    // Convert DisburseDataId to string to ensure type consistency
    var data = disburseData.find((disburseDatum) => {
        // Ensure both are compared as strings
        return disburseDatum.disbursement_id === String(DisburseDataId);
    });

    console.log("Found Data:", data);

    // Check if data is found
    if (!data) {
        console.error("No data found for DisburseDataId:", DisburseDataId);
        return;
    }

    var modals = document.querySelector('.modals');
    var modalContent = `
    <style>
        input {
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        }

        #input-container {
            display: flex;
            flex-direction: column;
            margin: 10px 0;
        }

        .modal-container {
            display: none; 
            position: fixed; 
            z-index: 12000; 
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); 
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 900px;
            overflow-y: scroll; 
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
            background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: unset !important;
            height: 35px;
            color: white;
        }

        .save-button {
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-weight: 600;
            margin-left: 125px;
            margin-top: 20px;
        }

        .form_element {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-bottom: 1.5rem;
            width: 100%;
        }

        .input-container {
            width: 100%;
            border-collapse: collapse;
            display: flex;
            flex-direction: column;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

       @media print {
    /* Hide elements that should not appear in the printed version */
    .add-text-header {
        display: none;
    }

    /* Adjust styles for better print layout */
    body {
        font-size: 12pt;
        overflow-y: scroll; 
    }

     * {
        scrollbar-width: none; /* For Firefox */
    }

    ::-webkit-scrollbar {
        display: none; /* For Chrome, Safari, and Edge */
    }

    body {
        overflow: hidden; /* Hide any overflow to ensure no scrolling */
    }

}
        
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <div class="add-text-header" >
                <h3>Voucher</h3>

                <span onclick="window.print()" style="cursor:pointer; display:flex;gap:10px; align-items:center">
                <p>Print</p>
                <img src="/assets/images/printvectorW.svg"/>
                </span>
                <span onclick="closeModal()" class="close" style="cursor:pointer;">&times;</span>
            </div>

          <div class="voucher-ctn" style="display:flex;">
          
        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/ngoPix.png" alt="" style="height:auto;  flex:1" />  

            <form id="form" class="dynamicForm" style="padding:5px;flex:2.5;">
                <div style="display:flex; justify-content:space-between; margin-bottom: 55px;align-items:baseline;"> 
                    <div class="form_elemen" style="display:flex !important; flex-direction:unset !important; gap:20px;">
                        <p>Pin:<em style="font-weight:900; font-size: 12px">${data.user_pin}</em></p>
                       
                    </div>

                    <div style="display:flex !important; flex-direction:column; align-items:center;">
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/printLogo.png" alt="" style="height:60px; width:80px;" />
                        <p>Ehi Centre Voucher</p>
                    </div>

                    <div class="form_elemen" style="display:flex !important; flex-direction:unset !important; gap:20px;">
                        <p>Date:<em style="font-weight:900; font-size: 12px">${data.date}</p></em>
                    </div>
                </div>

     <div class="form_element" >
                        <p>Name: <em style="font-weight:900; font-size: 12px">${data.receiver}</p></em>
                    </div>           

                <div class="form_element">
                    <div id="input-container" class="input-container" >
                        <table  >
                            <thead >
                                <tr >
                                    <th padding:15px 100px>Item(s)</th>
                                    <th padding:15px 100px>Quantity</th>
                                </tr>
                            </thead>
                            <tbody >
                                ${data.items.map((item) => `
                                    <tr>
                                        <td style="padding:15px 100px ">${item.item}</td>
                                        <td style="padding:15px 100px">${item.quantity}</td>
                                    </tr>
                                `).join('')}
                                
                            </tbody>
                            <tfooter>
                            
                            </tfooter>

                        </table>
                        
                    </div>
                </div>
                <p style="margin-top:20px; margin-left:450px; ">Signature:.................................</p>
            </form>

    </div> 
        </div>
    </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateDisbursementData(DisburseDataId){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;
    
    var form = document.getElementById('form');
    var modals = document.querySelector('.modals');
    const receiver = document.getElementById('receiver').value;
    const pin = document.getElementById('pin').value;
    const date = document.getElementById('Date').value;
    const status = document.getElementById('status').value;

    // Correct the query selectors to match the updated input names
    const itemInputs = document.querySelectorAll('input[name="item[]"]');
    const quantityInputs = document.querySelectorAll('input[name="quantity[]"]');

    var formData = new FormData();
    formData.append('receiver', receiver);
    formData.append('pin', pin);
    formData.append('date', date);
    formData.append('status', status);
    formData.append('DisburseDataId', DisburseDataId);

    // Loop through item inputs and append their values to FormData
    itemInputs.forEach((itemInput, index) => {
        formData.append(`item[${index}]`, itemInput.value);
        formData.append(`quantity[${index}]`, quantityInputs[index].value);
    });

    // console.log("formData",formData)

    // Log FormData for debugging
    for (let [key, value] of formData.entries()) {
        console.log(key, value);
    }

    // AJAX request (uncomment and update the URL)
    var xhttp = new XMLHttpRequest();

    xhttp.onload = function(){
        var response = xhttp.response
         disbursementData = response.disburseData
        console.log('Response received:', disbursementData);
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
        window.location.reload();
        getDisburseData();
    };
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
        console.error('An error occurred.');
    };

    xhttp.open("POST", '../backend/request.php?function=update-disburseData', true);
    console.log("formData",formData)
    xhttp.send(formData);
}

function deleteDisbursementData(DisburseDataId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('DisburseDataId', DisburseDataId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getDisburseData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
        
            xhttp.open("POST", '../backend/request.php?function=delete-DisbursementData', true);
            console.log("formData", formData)
            xhttp.send(formData);
        }
      });
}


//balance Sheet
var bSheetData = null;

function addBsheetData(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input, select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 458px;
            /* overflow-x: scroll;
            overflow-y: scroll; 
            overflow-y: scroll;*/
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Add New</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                       

                       <div class="form_element">
                                <label for="Donor">Name </label>
                                <input type="text" id="name" required />
                        </div>

                       <div class="form_element">
                                <label for="Item">Category</label>
                                <select id="Item">
                                    <option></option>
                                    <option>Asset</option>
                                    <option>Liability</option>
                                </select>
                        </div>

                       <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required />
                        </div>
                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required />
                        </div>
                      
                       
                       
                       

                    <button type="button" class="save-button" onclick="saveBsheetData()" id="save-btn">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveBsheetData(){
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;
     var modals = document.querySelector('.modals');
     var form = document.getElementById('form');

    const name = document.getElementById('name').value;
    const item = document.getElementById('Item').value;
    const amount = document.getElementById('Amount').value;
    const date = document.getElementById('Date').value;
    
    var formData = new FormData();
    formData.append('name', name);
    formData.append('item', item);
    formData.append('amount', amount);
    formData.append('date', date);
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        // for(var modal of modals){
        //     modal.style.display = 'none';
        // }

        // for(var form of forms){
        //     form.reset();
        // }
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
        location.reload();
        getBsheetData();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=save-bSheetData', true);
   
    console.log("formData",formData )
    xhttp.send(formData);
}

var currentPage = 1;
var recordsPerPage = 10;

// function getBsheetData(page = 1, recordsPerPage = 9) {
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function() {
//         var response = JSON.parse(xhttp.response);
//         console.log("response", response);

//         // Fetch data and pagination info from response
//          bSheetData = response.bSheetData.data;
//         var totalPages = response.bSheetData.totalPages;
//         var totalRecords = response.bSheetData.totalRecords;

//         // Update the global currentPage variable to the requested page
//         currentPage = page;

//         // Display the data
//         loopBsheetData(bSheetData);

//         // Generate pagination controls
//         generatePaginationControls(currentPage, totalPages);
//     };

//     // Make a request to the backend, passing page and recordsPerPage as query parameters
//     xhttp.open("GET", `../backend/request.php?function=get-bSheetData&page=${page}&recordsPerPage=${recordsPerPage}`, true);
//     xhttp.send();
// }



// function loopBsheetData(data) {
//     var container = document.getElementById('bSheetTbody');

//     if (!container) {
//         console.warn("Bsheet container not found. Skipping data rendering.");
//         return; // Exit the function if the container is not found
//     }

//     var tr = "";
//     var counter = (currentPage - 1) * recordsPerPage;  // Adjust counter to reflect page number

//     if (data && data.length > 0) {
//         for (var i = 0; i < data.length; i++) {
//             counter++;
//             tr += `
//                 <tr class="ehi-tbody-tr">
//                     <td class="ehi-td">${(counter)}</td>
//                     <td class="ehi-td">${(data[i].name)}</td>
//                     <td class="ehi-td">${(data[i].item)}</td>
//                     <td class="ehi-td">₦${formatCurrency(data[i].amount)}</td>
//                     <td class="ehi-td">${formatDate(data[i].date)}</td>
//                     <td class="ehi-td flex-center">
//                         <div style="position:relative;">
//                             <button onclick="showOptions(${i})" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
//                                 <img src="../assets/images/three-options.png" alt="" class="three-options">
//                             </button>

//                             <div id="${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
//                                 <button onclick="editBsheetData(${data[i].id})" class="openModalBtnEdit option-button">
//                                     <img src="/assets/images/edit.png"/> Edit
//                                 </button>
//                                 <button onclick="viewBsheetData(${data[i].id})" class="openModalBtnView option-button">
//                                     <img src="/assets/images/view.png"/> View
//                                 </button>   
//                                 <button onclick="deleteBsheetData(${data[i].id})" class="option-button">
//                                     <img src="/assets/images/delete.png"/> Delete
//                                 </button>   
//                             </div>
//                         </div>
//                     </td>
//                 </tr>
//             `;
//         }
//         container.innerHTML = tr;
//     } else {
//         container.innerHTML = `<tr><td colspan="6" class="no-data">No data available!</td></tr>`;
//     }
// }

var bSheetAssetData;
var bSheetLiabilityData;
function getBsheetData() {
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function() {

        var response = JSON.parse(xhttp.response);
        console.log("response", response);

        // Fetch data and pagination info from response
         bSheetData = response.bSheetData;
         bSheetAssetData = response.bSheetData.assets;
         bSheetLiabilityData = response.bSheetData.liabilities;
       
        // Display the data
        loopBsheetData(bSheetData);

       
    };

    // Make a request to the backend, passing page and recordsPerPage as query parameters
    xhttp.open("GET", '../backend/request.php?function=get-bSheetDataAnnual', true);
    xhttp.send();
}

function showOptions2(indexNumber) {
    console.log("Attempting to show options for ID:", indexNumber);  // Log the received ID

    // Close any open dropdowns
    var dropdowns = document.querySelectorAll('.options-dropdown');
    dropdowns.forEach(function(dropdown) {
        if (dropdown.id !== indexNumber) {
            dropdown.style.display = 'none';
        }
    });

    // Access and toggle the specific dropdown
    var optionCard = document.getElementById(indexNumber);
    console.log("Found optionCard:", optionCard);  // Log the optionCard element

    if (optionCard) {
        optionCard.style.display = (optionCard.style.display === 'none' || optionCard.style.display === '') 
                                   ? 'block' : 'none';
    } else {
        console.error(`Element with id ${indexNumber} not found`);
    }
}


function loopBsheetData(data) {
    var container = document.getElementById('bSheetTbody');

    if (!container) {
        console.warn("Bsheet container not found. Skipping data rendering.");
        return; // Exit the function if the container is not found
    }

    var tr = "";
    var assetCounter = 0; // Counter for assets
    var liabilityCounter = 0; // Counter for liabilities

    // Add the Assets heading
    tr += `
        <tr class="ehi-tbody-tr heading">
            <td colspan="6" class="ehi-td-heading" style="padding:20px 0;font-weight:900;">ASSETS</td>
        </tr>
    `;

    // Loop through the assets
    if (data.assets && data.assets.length > 0) {
        for (var i = 0; i < data.assets.length; i++) {
            assetCounter++; // Increment the asset counter for each asset item
            tr += `
                <tr class="ehi-tbody-tr">
                    <td class="ehi-td">${assetCounter}</td>
                    <td class="ehi-td">${data.assets[i].name}</td>
                    <td class="ehi-td">${data.assets[i].item}</td>
                    <td class="ehi-td">₦${formatCurrency(data.assets[i].amount)}</td>
                    <td class="ehi-td">${formatDate(data.assets[i].date)}</td>
                    <td class="ehi-td flex-center">
                        <div style="position:relative;">
                            <button onclick="showOptions2('asset-${i}')" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
                                <img src="../assets/images/three-options.png" alt="" class="three-options">
                            </button>

                            <div id="asset-${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
                                <button onclick="editBsheetData(${data.assets[i].id})" class="openModalBtnEdit option-button">
                                    <img src="/assets/images/edit.png"/> Edit
                                </button>
                                <button onclick="viewBsheetData(${data.assets[i].id})" class="openModalBtnView option-button">
                                    <img src="/assets/images/view.png"/> View
                                </button>   
                                <button onclick="deleteBsheetData(${data.assets[i].id})" class="option-button">
                                    <img src="/assets/images/delete.png"/> Delete
                                </button>   
                            </div>
                        </div>
                    </td>
                </tr>
            `;
        }
    } else {
        tr += `<tr><td colspan="6" class="no-data">No assets available!</td></tr>`;
    }

    // Add the Liabilities heading
    tr += `
        <tr class="ehi-tbody-tr heading">
            <td colspan="6" class="ehi-td-heading" style="padding:20px 0;font-weight:900">LIABILITIES</td>
        </tr>
    `;

    // Loop through the liabilities
    if (data.liabilities && data.liabilities.length > 0) {
        for (var j = 0; j < data.liabilities.length; j++) {
            liabilityCounter++; // Increment the liability counter for each liability item
            tr += `
                <tr class="ehi-tbody-tr">
                    <td class="ehi-td">${liabilityCounter}</td>
                    <td class="ehi-td">${data.liabilities[j].name}</td>
                    <td class="ehi-td">${data.liabilities[j].item}</td>
                    <td class="ehi-td">₦${formatCurrency(data.liabilities[j].amount)}</td>
                    <td class="ehi-td">${formatDate(data.liabilities[j].date)}</td>
                    <td class="ehi-td flex-center">
                        <div style="position:relative;">
                            <button onclick="showOptions2('liability-${j}')" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
                                <img src="../assets/images/three-options.png" alt="" class="three-options">
                            </button>

                            <div id="liability-${j}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
                                <button onclick="editBsheetData(${data.liabilities[j].id})" class="openModalBtnEdit option-button">
                                    <img src="/assets/images/edit.png"/> Edit
                                </button>
                                <button onclick="viewBsheetData(${data.liabilities[j].id})" class="openModalBtnView option-button">
                                    <img src="/assets/images/view.png"/> View
                                </button>   
                                <button onclick="deleteBsheetData(${data.liabilities[j].id})" class="option-button">
                                    <img src="/assets/images/delete.png"/> Delete
                                </button>   
                            </div>
                        </div>
                    </td>
                </tr>
            `;
        }
    } else {
        tr += `<tr><td colspan="6" class="no-data">No liabilities available!</td></tr>`;
    }

    container.innerHTML = tr;
}




// function generatePaginationControls(currentPage, totalPages) {
//     var paginationContainer = document.getElementById('paginationControls');

//     if (!paginationContainer) {
//         console.warn("Bsheet container not found. Skipping data rendering.");
//         return; // Exit the function if the container is not found
//     }

//     var paginationHTML = '';

//     // Create Previous Button
//     if (currentPage > 1) {
//         paginationHTML += `<button  class="ctrBtn"  onclick="getBsheetData(${currentPage - 1}, ${recordsPerPage})" " >&lt;</button>`;
//     }


//     // Create page number buttons
//     for (var i = 1; i <= totalPages; i++) {
//         if (i === currentPage) {
//             paginationHTML += `<button class="active ctrBtn"  ">${i}</button>`;
//         } else {
//             paginationHTML += `<button onclick="getBsheetData(${i}, ${recordsPerPage})" class="ctrBtn" ">${i}</button>`;
//         }
//     }

//     // Create Next Button
//     if (currentPage < totalPages) {
//         paginationHTML += `<button class="ctrBtn" onclick="getBsheetData(${currentPage + 1}, ${recordsPerPage})"  ">&gt;</button>`;
//     }

//     paginationContainer.innerHTML = paginationHTML;
// }

// Initialize the table data on page load
getBsheetData();
// return disburseDatum.disbursement_id === String(DisburseDataId);
// function editBsheetData(bSheetDataId){
// console.log("bSheetDataId",bSheetDataId, typeof(bSheetDataId))

//     var data = bSheetData.find((bSheetDatum)=>{
//         console.log("bSheetDatum.id",bSheetDatum.id, typeof(bSheetDatum.id))
//         return bSheetDatum.id === String(bSheetDataId)
//     });
//     var modals = document.querySelector('.modals');
//     var modalContent = `
    
//     <style>
//         input, select{
//             padding: 12px 17px;
//             border-radius: 8px;
//             border: 1px solid var(--Foundation-Primary-P400, #097B48);
//             background: var(--Foundation-White-W300, #F6F6F6);
        
//         }
            

//         .modal-container{
//             display: none; 
//             position: fixed; /* Fixed position */
//             z-index: 12000; /* Make sure it appears on top of everything */
//             left: 0;
//             top: 0;
//             width: 100%;
//             height: 100%;
//             background-color: rgba(0,0,0,0.4); /* Black background with opacity */
//         }

//         .modal-content {
//             background-color: #fefefe; 
//             position: fixed; 
//             top: 50%; 
//             left: 50%; 
//             transform: translate(-50%, -50%); 
//             /* padding: 20px; */
//             border: 1px solid #888;
//             width: 80%;
//             max-height: 100vh; 
//             max-width: 500px;
//             max-width: 458px;
//             /* overflow-x: scroll;
//             overflow-y: scroll; 
//             overflow-y: scroll;*/
//         }

//         .close {
//             color: white;
//             font-size: 28px;
//             font-weight: bold;
//         }
        
//         .close:hover,
//         .close:focus {
//             color: black;
//             text-decoration: none;
//             cursor: pointer;
//         }

//         .add-text-header {
//         background: #097B48;
//             display: flex;
//             justify-content: space-between;
//             align-items: center;
//             padding: 10px;
//             margin-bottom: 4px;
//             height: 35px;
//             color: white;
//         }

//         .add-text > h3 {
//             color: #FFF;
//             font-family: Archivo;
//             font-size: 24px;
//             font-style: normal;
//             font-weight: 600;
//             line-height: 120%; /* 28.8px */
//             text-align: center;
//         }

//         .nav-btn {
//         display: flex;
//         width: 110px;
//         height: 40px;
//         justify-content: center;
//         align-items: center;
//         border-radius: 10px;
//         background: #097B48;
//         border: 0;
//         color: #FFF;
//         font-family: Roboto;
//         font-size: 17px;
//         font-style: normal;
//         font-weight: 400;
//         cursor: pointer;
//         }

//         .save-button{
//             display: flex;
//             width: 118px;
//             height: 37px;
//             padding: 10px;
//             justify-content: center;
//             align-items: center;
//             gap: 10px;
//             flex-shrink: 0;
//             border-radius: 10px;
//             background: #097B48;
//             color: #FFF;
//             text-align: center;
//             font-family: Archivo;
//             font-size: 18px;
//             font-style: normal;
//             font-weight: 600;
//             line-height: 120%; /* 19.2px */
//             border: 0;
//             margin-left: 110px;
//             margin-top: 20px;
//         }

//         .add-recept{
//         /* padding:10px; */
//         border-color: transparent;
//         background-color: transparent;
//         color: #097B48;
//         font-family: Inter;
//         cursor: pointer;
//         }

//     .form_element{
//         display: flex;
//         flex-direction: column;
//         justify-content: flex-start;
//         margin-bottom: 1.5rem;
//         width: 100%;
//     }

//     form{
//         padding: 20px;
//         font-family: Inter;
//     }
// </style>
//     <div id="myModal" class="modal-container">
//         <div class="modal-content">
            
//             <div class="add-text-header">
//             <h3></h3>
//                 <h3>Edit</h3>
//                 <span onclick="closeModal()" class="close">&times;</span>
//             </div>
//         <form id="form">
                       

//                        <div class="form_element">
//                                 <label for="Donor">Name </label>
//                                 <input type="text" id="name" required  value="${data.name}"/>
//                         </div>

//                       <div class="form_element">
//     <label for="Item">Category</label>
//     <select id="Item">
//         <option value="" ${data.item === "" ? "selected" : ""}></option>
//         <option value="Asset" ${data.item === "Asset" ? "selected" : ""}>Asset</option>
//         <option value="Liability" ${data.item === "Liability" ? "selected" : ""}>Liability</option>
//     </select>
// </div>

//                        <div class="form_element">
//                                 <label for="Amount">Amount</label>
//                                 <input type="number" id="Amount" required  value="${data.amount}"/>
//                         </div>
//                        <div class="form_element">
//                                 <label for="Date">Date</label>
//                                 <input type="date" id="Date" required  value="${data.date}"/>
//                         </div>
                      
                       
                       
                       

//                     <button type="button" class="save-button" onclick="updateBsheetData()" id="save-btn">Save</button>  
//     </form>

//         </div>
//     </div>
//     `;
//     if(modals){
//         modals.innerHTML = modalContent;
//         openModal();
//     }
// }

function editBsheetData(bSheetDataId) {
    console.log("bSheetDataId", bSheetDataId, typeof(bSheetDataId));

    // Check both assets and liabilities
    let data = bSheetData.assets.find((bSheetDatum) => {
        console.log("bSheetDatum.id", bSheetDatum.id, typeof(bSheetDatum.id));
        return bSheetDatum.id === String(bSheetDataId);
    });

    if (!data) {
        // If not found in assets, search in liabilities
        data = bSheetData.liabilities.find((bSheetDatum) => {
            console.log("bSheetDatum.id", bSheetDatum.id, typeof(bSheetDatum.id));
            return bSheetDatum.id === String(bSheetDataId);
        });
    }

    if (!data) {
        console.warn("No matching data found for id:", bSheetDataId);
        return;
    }

    // Continue with modal rendering logic as before
    var modals = document.querySelector('.modals');
    var modalContent = `
        <style>
            input, select{
                padding: 12px 17px;
                border-radius: 8px;
                border: 1px solid var(--Foundation-Primary-P400, #097B48);
                background: var(--Foundation-White-W300, #F6F6F6);
            }

            .modal-container{
                display: none; 
                position: fixed;
                z-index: 12000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
            }

            .modal-content {
                background-color: #fefefe;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 80%;
                max-width: 458px;
            }

            .close {
                color: white;
                font-size: 28px;
                font-weight: bold;
            }
            
            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }

            .add-text-header {
                background: #097B48;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px;
                margin-bottom: 4px;
                height: 35px;
                color: white;
            }

            .nav-btn {
                display: flex;
                width: 110px;
                height: 40px;
                justify-content: center;
                align-items: center;
                border-radius: 10px;
                background: #097B48;
                border: 0;
                color: #FFF;
                font-family: Roboto;
                font-size: 17px;
                font-weight: 400;
                cursor: pointer;
            }

            .save-button{
                display: flex;
                width: 118px;
                height: 37px;
                padding: 10px;
                justify-content: center;
                align-items: center;
                border-radius: 10px;
                background: #097B48;
                color: #FFF;
                font-family: Archivo;
                font-size: 18px;
                font-weight: 600;
                margin-left: 110px;
                margin-top: 20px;
                border: 0;
            }

            .form_element{
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
                margin-bottom: 1.5rem;
                width: 100%;
            }

            form{
                padding: 20px;
                font-family: Inter;
            }
        </style>
        <div id="myModal" class="modal-container">
            <div class="modal-content">
                <div class="add-text-header">
                    <h3>Edit</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <form id="form">
                    <div class="form_element">
                        <label for="name">Name</label>
                        <input type="text" id="name" required value="${data.name}"/>
                    </div>

                    <div class="form_element">
                        <label for="Item">Category</label>
                        <select id="Item">
                            <option value="Asset" ${data.item === "Asset" ? "selected" : ""}>Asset</option>
                            <option value="Liability" ${data.item === "Liability" ? "selected" : ""}>Liability</option>
                        </select>
                    </div>

                    <div class="form_element">
                        <label for="Amount">Amount</label>
                        <input type="number" id="Amount" required value="${data.amount}"/>
                    </div>

                    <div class="form_element">
                        <label for="Date">Date</label>
                        <input type="date" id="Date" required value="${data.date}"/>
                    </div>

                    <button type="button" class="save-button" onclick="updateBsheetData()" id="save-btn">Update</button>  
                </form>
            </div>
        </div>
    `;

    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}



function updateBsheetData(bSheetDataId){
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;
     var modals = document.querySelector('.modals');
     var form = document.getElementById('form');

    const name = document.getElementById('name').value;
    const item = document.getElementById('Item').value;
    const amount = document.getElementById('Amount').value;
    const date = document.getElementById('Date').value;
    
    var formData = new FormData();
    formData.append('name', name);
    formData.append('item', item);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('bSheetDataId', bSheetDataId);
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        // for(var modal of modals){
        //     modal.style.display = 'none';
        // }

        // for(var form of forms){
        //     form.reset();
        // }
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
        window.location.reload();
        getBsheetData();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=update-bSheetData', true);
   
    console.log("formData",formData )
    xhttp.send(formData);
}



function viewBsheetData(bSheetDataId){

    var data = bSheetData.find((bSheetDatum)=>{

        return bSheetDatum.id == bSheetDataId
    });
    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input, select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 458px;
            /* overflow-x: scroll;
            overflow-y: scroll; 
            overflow-y: scroll;*/
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>View</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                       

                       <div class="form_element">
                                <label for="Donor">Name </label>
                                <input type="text" id="name" required  value="${data.name}" readonly/>
                        </div>

                      <div class="form_element">
    <label for="Item">Category</label>
    <select id="Item" disabled>
        <option value="${data.item}">${data.item}</option>
        
    </select>
</div>

                       <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required  value="${data.amount}" readonly/>
                        </div>
                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required  value="${data.date}" readonly/>
                        </div>
                      
                       
                       
                       

                    
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function deleteBsheetData(bSheetDataId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('bSheetDataId', bSheetDataId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getBsheetData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
        
            xhttp.open("POST", '../backend/request.php?function=delete-bSheetData', true);
            console.log("formData", formData)
            xhttp.send(formData);
        }
      });
}


// function downloadBalancesheetReport() {
//     const element = document.getElementById('download-content'); 

//     if (!element) {
//         console.error("Element not found!");
//         return;
//     }

//     var { jsPDF } = window.jspdf;  // Get the jsPDF class from the library

//     html2canvas(element).then(function(canvas) {
//         var imgData = canvas.toDataURL('image/png');
//         var doc = new jsPDF();

//         // Add the image to the PDF, adjust size and position
//         doc.addImage(imgData, 'PNG', 10, 10, 190, canvas.height * 190 / canvas.width);  // Adjust width and height

//         doc.save('balancesheet_report.pdf');  // Save as 'beneficiary_report.pdf'
//     }).catch(function(error) {
//         console.error("Error generating PDF:", error);
//     });
// }

function downloadBalancesheetReport() {
    alert("To save as PDF, select 'Save as PDF' in the print dialog.");
    window.print();
}


var bSheetDataAnnual = null;
function viewBsheetDataAnnual() {
    var xhttp = new XMLHttpRequest();

    xhttp.onload = function() {
        var response = JSON.parse(xhttp.response);

        // Correct the data assignment
        var liabilityData = response.bSheetData.liabilities;
        var assetsData = response.bSheetData.assets;

        let totalAssets = 0;
        let totalLiabilities = 0;

        const modals = document.querySelector('.modals');
        if (!modals) {
            console.error("Element with class '.modals' not found");
            return;
        }

        const modalContent = `
            <style>
                input, select {
                    padding: 12px 17px;
                    border-radius: 8px;
                    border: 1px solid var(--Foundation-Primary-P400, #097B48);
                    background: var(--Foundation-White-W300, #F6F6F6);
                }

                .modal-container {
                    display: none; 
                    position: fixed;
                    z-index: 12000;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0,0,0,0.4);
                }

                .modal-content {
                    background-color: #fefefe;
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    border: 1px solid #888;
                    width: 80%;
                    max-height: 100vh;
                    max-width: 900px;
                    overflow-y: scroll;
                }

                .close {
                    color: white;
                    font-size: 28px;
                    font-weight: bold;
                }

                .add-text-header {
                    background: #097B48;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 10px;
                    margin-bottom: 4px;
                    height: 35px;
                    color: white;
                }

                .save-button {
                    display: flex;
                    width: 118px;
                    height: 37px;
                    padding: 10px;
                    justify-content: center;
                    align-items: center;
                    border-radius: 10px;
                    background: #097B48;
                    color: #FFF;
                    text-align: center;
                    margin-left: 110px;
                    margin-top: 20px;
                }

                form {
                    padding: 20px;
                    font-family: Inter;
                }

                td, th {
                    font-family: Roboto;
                    font-size: 14px;
                    font-weight: 400;
                    text-align: left;
                    padding: 10px;
                    border-bottom: 5px solid #dbd6d6;
                    text-overflow: ellipsis;
                    border-collapse: collapse;
                }

                th{
                font-weight:800;}

                table {
                    border-collapse: collapse;
                    width: 100%;
                }

                .total-row {
                    font-weight: bold;
                    text-align: right;
                }

         @media print {
    /* Hide elements that should not appear in the printed version */
    .add-text-header {
        display: none;
    }

    /* Adjust styles for better print layout */
    body {
        font-size: 12pt;
        overflow: hidden; /* Hide vertical scrollbar */
        margin: 0; /* Remove default margin */
        padding: 0; /* Remove default padding */
    }

    /* Remove default border around printed page */
    @page {
        margin: 0; /* Remove margins */
    }

    /* You can also adjust other elements here as needed */
    /* For example, hiding buttons or specific sections */
    button {
        display: none; /* Hide buttons in the print version */
    }
}

                </style>
            <div id="myModal" class="modal-container">
                <div class="modal-content"  id="download-content">
                    <div class="add-text-header">

                        <button class="add-button" onclick="downloadBalancesheetReport()"><img src="../assets/images/download-icon.png" alt="" class="icon">Download</button>


                        <h3>Balance Sheet </h3>


                        <span onclick="closeModal()" class="close">&times;</span>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:baseline; padding:5px  30px">
                            <div></div>                
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/printLogo.png" alt="" style="height:40px; width:80px;margin-left:60px" />

                        <div></div>
                    </div>

                  

                    <div style="display:flex; justify-content:space-between; align-items:baseline; padding:5px 30px">
                    
                     <input type="date" placeholder="Add Date" style="; border-color:transparent">
                    
                    <input type="text" placeholder="Add Title" style="width:40%; border-color:transparent">
                    </div>

                    <div id="data-container"  style="padding:0 30px;">
                        <table  id="asset-table">
                            <thead>
                                <tr>
                                    <th>ASSET</th>
                                    <th>AMOUNT(₦)</th>
                                    <th>DATE</th>
                                </tr>
                            </thead>
                            <tbody id="assetTbody"></tbody>
                            <tfoot>
                        
                            </tfoot>

                            
                        </table>
                          <div style="background: #097B48; color:white; padding:10px 0; margin:10px 0; display:flex; justify-content:space-around;">
                        <p></p>
                            <span style="display:flex; gap:5px;">
                        <p></p>
                        <p id="totalAssets"></p>
                        </span>
                        
                    </div>
                    </div>

                    

                    <div id="data-container2" style="padding:0 30px;">
                        <table>
                            <thead>
                                <tr>
                                    <th>LIABILITY</th>
                                    <th>AMOUNT(₦)</th>
                                    <th>DATE</th>
                                </tr>
                            </thead>
                            <tbody id="liabilityTbody"></tbody>
                            <tfoot>


                                            
                            </tfoot>

                               
                        </table>

                         <div style="background: #097B48; color:white; padding:10px 0; margin:10px 0; display:flex; justify-content:space-around;">
                                        <p></p>
                                        <span style="display:flex;gap:5px">

                                        <p></P>
                                        <p id="totalLiabilities"></p>
                                        
                                        </span>
                                        
                                    </div>
                    </div>
                </div>
            </div>
        `;

        modals.innerHTML = modalContent;

       

        assetsData.forEach(element => {
            const tableBody = document.querySelector('#assetTbody');
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${element.name}</td>
                <td>₦${formatCurrency(element.amount)}</td>
                <td>${element.date}</td>
            `;
            tableBody.appendChild(row);
        
            // Add to the total assets as a number
            totalAssets += parseFloat(element.amount);
        });
        
        // Format the total assets after the loop
        const formattedTotalAssets = formatCurrency(totalAssets);
        
        // Display the formatted total assets somewhere in your UI
        document.getElementById('totalAssets').innerText = `Total Assets: ₦${formattedTotalAssets}`;
        


liabilityData.forEach(element => {
    const tableBody2 = document.querySelector('#liabilityTbody');
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${element.name}</td>
        <td>₦${formatCurrency(element.amount)}</td>
        <td>${element.date}</td>
    `;
    tableBody2.appendChild(row);

    // Add to the total liabilities as a number
    totalLiabilities += parseFloat(element.amount);
});

// Format the total liabilities after the loop
const formattedTotalLiabilities = formatCurrency(totalLiabilities);

document.getElementById('totalLiabilities').innerText = `Total Liabilities: ₦${formattedTotalLiabilities}`;



        // Update the total assets and liabilities in the UI
        // document.getElementById('totalAssets').textContent = totalAssets.toFixed(2);


        // document.getElementById('totalLiabilities').textContent = totalLiabilities.toFixed(2);

        openModal(); // Assuming a separate function to open the modal



        

    };

    xhttp.onerror = function() {
        console.error("An error occurred while fetching data");
    };

    xhttp.open("GET", '../backend/request.php?function=get-bSheetDataAnnual', true);
    xhttp.send();


}


function getArchive(){
    var xhttp = new XMLHttpRequest();
    
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        achiveData = response.archiveData;
        loopArchiveData(achiveData);
    }

    xhttp.open("GET", '../backend/request.php?function=get-Archive', true);
    xhttp.send();
}


function loopArchiveData(data) {
    var container = document.getElementById('Arch_Tbody');
    if (!container) {
        console.warn("Program container not found. Skipping data rendering.");
        return; // Exit the function if the container is not found
    }

    var tr = "";
    var counter = 1000;
    
    if (data && data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            counter++;
            tr += `
                <tr class="ehi-tbody-tr">
                    <td class="ehi-td">${counter}</td>
                    <td class="ehi-td">${formatDate(data[i].date)}</td>
                    <td class="ehi-td"><img class="profile-image" src="${homepageUrl}/uploads/${data[i]?.image}" alt="" /></td>
                    <td class="ehi-td">${data[i].first_name}</td>
                    <td class="ehi-td">${data[i].last_name}</td>
                    <td class="ehi-td">${data[i].user_pin}</td>
                    <td class="ehi-td">${data[i].gender}</td>
                    
                    <td class="ehi-td flex-center">
                        <div style="position:relative;">
                            <!-- Button to show the dropdown -->
                            <button onclick="showOptions(${i})" class="three" style="cursor: pointer; background-color: transparent; border: none; outline: none;">
                                <img src="../assets/images/three-options.png" alt="" class="three-options">
                            </button>

                            <!-- Dropdown with dynamic ID based on 'i' -->
                            <div id="dropdown-${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
                                

                                <button onclic="viewProgramData(${data[i].id})" class="openModalBtnView option-button">
                                    <img src="/assets/images/restore.svg"/> Restore
                                </button>   

                                <button onclick="deleteArchiveData(${data[i].id})" class="option-button"  style="    border: 2px solid transparent">
                                    <img src="/assets/images/Delete.svg"/> Delete
                                </button>   
                            </div>
                        </div>
                    </td>

                    <!-- Checkbox for selection -->
                    <td class="ehi-td">

                    
                        <input type="checkbox" id="select-${i}" class="archive-checkbox" value="${data[i].user_pin}"/>
                    </td>
                </tr>
            `;
        }
        container.innerHTML = tr;
    } else {
        container.innerHTML = "No data yet!";
    }
}

getArchive();


function deleteArchiveData(archiveDataId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('archiveDataId', archiveDataId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getBsheetData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
        
            xhttp.open("POST", '../backend/request.php?function=delete-Archive', true);
            console.log("formData", formData)
            xhttp.send(formData);
        }
      });
}


document.getElementById('select-all').addEventListener('change', function() {
    var checkboxes = document.querySelectorAll('.archive-checkbox');
    for (var checkbox of checkboxes) {
        checkbox.checked = this.checked;
    }
});

function deleteSelectedArchiveData() {
    swal({
        title: "Are you sure?",
        text: "This will delete selected items permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            var selectedValues = [];
            var checkboxes = document.querySelectorAll('.archive-checkbox:checked');
            checkboxes.forEach(checkbox => {
                selectedValues.push(checkbox.value);
            });

            if (selectedValues.length > 0) {
                var formData = new FormData();
                formData.append('archiveDataIds', JSON.stringify(selectedValues));
                
                var xhttp = new XMLHttpRequest();
                xhttp.onload = function() {
                    var response = JSON.parse(xhttp.response);
                    if (response.success) {
                        getBsheetData();
                        swal('Hurray', response.success, 'success');
                    } else {
                        swal('Sorry', response.error, 'error');
                    }
                }
                xhttp.onerror = function(error) {
                    swal('Sorry', "An error occurred, try again!", 'error');
                }
                xhttp.open("POST", '../backend/request.php?function=delete-SelectedArchive', true);
                for (var pair of formData.entries()) {
                    console.log(pair[0]+ ', ' + pair[1]); 
                }
                xhttp.send(formData);
            } else {
                swal('Sorry', "No items selected.", 'error');
            }
        }
    });
}



// function toggleSelectAll() {
//     var checkboxes = document.querySelectorAll('.archive-checkbox');
//     var selectAllCheckbox = document.getElementById('select-all');
//     var selectAllLabel = document.getElementById('select-all-label');
//     var deleteAllLabel = document.getElementById('delete-all-label');
//     var restoreAllLabel = document.getElementById('restore-all-label');

//     if (selectAllCheckbox.checked) {
//         // Check all checkboxes
//         checkboxes.forEach(function(checkbox) {
//             checkbox.checked = true;
//         });
        
//         // Hide "Select All" label and show "Delete All" and "Restore All" labels
//         selectAllLabel.style.display = 'none';
//         deleteAllLabel.style.display = 'inline-block';
//         restoreAllLabel.style.display = 'inline-block';
//     } else {
//         // Uncheck all checkboxes
//         checkboxes.forEach(function(checkbox) {
//             checkbox.checked = false;
//         });

//         // Revert to showing "Select All" and hide "Delete All" and "Restore All" labels
//         selectAllLabel.style.display = 'inline-block';
//         deleteAllLabel.style.display = 'none';
//         restoreAllLabel.style.display = 'none';
//     }
// }

// function deleteSelectedArchives() {
//     var selectedCheckboxes = document.querySelectorAll('.archive-checkbox:checked');
//     var selectedArchiveIds = [];

//     selectedCheckboxes.forEach(function(checkbox) {
//         selectedArchiveIds.push(checkbox.value);
//     });

//     if (selectedArchiveIds.length > 0) {
//         swal({
//             title: "Are you sure?",
//             text: "These items will be deleted permanently.",
//             type: "warning",
//             showCancelButton: true,
//             confirmButtonColor: "#DD6B55",
//             confirmButtonText: "Delete",
//             cancelButtonText: "Cancel",
//             closeOnConfirm: true,
//             closeOnCancel: true
//         }, function(isConfirm) {
//             if (isConfirm) {
//                 var formData = new FormData();
//                 formData.append('archiveDataIds', JSON.stringify(selectedArchiveIds));

//                 var xhttp = new XMLHttpRequest();
//                 xhttp.onload = function() {
//                     var response = JSON.parse(xhttp.response);
//                     if (response.success) {
//                         getArchive(); // Refresh table
//                         swal('Hurray', response.success, 'success');
//                     } else {
//                         swal('Sorry', response.error, 'error');
//                     }
//                 };
//                 xhttp.onerror = function() {
//                     swal('Sorry', "An error occurred, try again!", 'error');
//                 };

//                 xhttp.open("POST", '../backend/request.php?function=delete-Archives', true);
//                 xhttp.send(formData);
//             }
//         });
//     } else {
//         swal('Oops', 'Please select at least one item to delete.', 'warning');
//     }
// }

// function restoreSelectedArchives() {
//     var selectedCheckboxes = document.querySelectorAll('.archive-checkbox:checked');
//     var selectedArchiveIds = [];

//     selectedCheckboxes.forEach(function(checkbox) {
//         selectedArchiveIds.push(checkbox.value);
//     });

//     if (selectedArchiveIds.length > 0) {
//         swal({
//             title: "Are you sure?",
//             text: "These items will be restored.",
//             type: "info",
//             showCancelButton: true,
//             confirmButtonColor: "#4CAF50",
//             confirmButtonText: "Restore",
//             cancelButtonText: "Cancel",
//             closeOnConfirm: true,
//             closeOnCancel: true
//         }, function(isConfirm) {
//             if (isConfirm) {
//                 var formData = new FormData();
//                 formData.append('archiveDataIds', JSON.stringify(selectedArchiveIds));

//                 var xhttp = new XMLHttpRequest();
//                 xhttp.onload = function() {
//                     var response = JSON.parse(xhttp.response);
//                     if (response.success) {
//                         getArchive(); // Refresh table
//                         swal('Hurray', response.success, 'success');
//                     } else {
//                         swal('Sorry', response.error, 'error');
//                     }
//                 };
//                 xhttp.onerror = function() {
//                     swal('Sorry', "An error occurred, try again!", 'error');
//                 };

//                 xhttp.open("POST", '../backend/request.php?function=restore-Archives', true);
//                 xhttp.send(formData);
//             }
//         });
//     } else {
//         swal('Oops', 'Please select at least one item to restore.', 'warning');
//     }
// }






const searchBar1 = document.getElementById('search-bar-sheet')



if (searchBar1) {
    searchBar1.addEventListener('input', () => {
        let searchTerm = searchBar1.value.toLowerCase().trim();

        // Filter program data
        let filteredProgramData = programData.filter(user => user.beneficiary.toLowerCase().includes(searchTerm));

        // Filter liabilities and assets for balance sheet
        let filteredLiability = bSheetLiabilityData.filter(bsheet => 
            bsheet.name.toLowerCase().includes(searchTerm) || bsheet.item.toLowerCase().includes(searchTerm)
        );
        
        let filteredAssetS = bSheetAssetData.filter(bsheet => 
            bsheet.name.toLowerCase().includes(searchTerm) || bsheet.item.toLowerCase().includes(searchTerm)
        );

        // Filter other data
        let filteredDisburse = disburseData.filter(user => user.receiver.toLowerCase().includes(searchTerm));
        let filteredMaterialData = materialData.filter(material => 
            material.donor.toLowerCase().includes(searchTerm) || material.item.toLowerCase().includes(searchTerm)
        );
        let filteredBeneficiaryData = beneficiaryData.filter(beneficiary => 
            beneficiary.first_name.toLowerCase().includes(searchTerm) || 
            beneficiary.last_name.toLowerCase().includes(searchTerm) || 
            beneficiary.user_pin.toLowerCase().includes(searchTerm)
        );

        // Check if the search term is empty to reset the UI
        if (searchTerm === "") {
            // Reset all data
            loopProgramData(programData);
            loopBsheetData({ assets: bSheetAssetData, liabilities: bSheetLiabilityData });
            loopDisburseData(disburseData);
            loopMaterialReport(materialData);
            loopBeneficiaryReport(beneficiaryData);
        } else {
            // Update the UI with filtered data
            loopProgramData(filteredProgramData);
            loopBsheetData({ assets: filteredAssetS, liabilities: filteredLiability });
            loopDisburseData(filteredDisburse);
            loopMaterialReport(filteredMaterialData);
            loopBeneficiaryReport(filteredBeneficiaryData);
        }
    });
}

function addProgramDatav1(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input,select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 900px;
            /* overflow-x: scroll;
            overflow-y: scroll; 
             overflow-y: scroll;
            */
           
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }

    /* Hide spinner controls in Chrome, Safari, Edge, and Opera */
input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Hide spinner controls in Firefox */
input[type="number"] {
    -moz-appearance: textfield;
}
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Add </h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                       
                  <div class="three-forms">
                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required  value="Ehi"/>
                        </div>


                          <div class="form_element">
                                <label for="Item">Category Items</label>
                                <select id="category" onchange
                                ="toggleQuantityField()">
                                    <option  value=""></option>
                                    <option  value="Cash">Cash</option>
                                    <option  value="Medication">Medication</option>
                                    <option  value="Rice">Rice</option>
                                    <option  value="Beans">Beans</option>
                                    <option  value="Clothes">Clothes</option>
                                    
                                </select>
                        </div>

                       <div class="form_element" id="quantityField">
                                <label for="Item">Quantity <em style="font-size:10px;">( in Kg,Pcs,Pack)</em></label>
                                <input type="text" id="quantity" required  placeholder="for cash, enter the amount")"/>
                        </div>

                      
                </div>

                <div class="three-forms">

                        <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required />
                        </div>

                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required />
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required />
                        </div>
                    
                       
                 </div>

                 <div class="three-forms">

                 <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex;  " id="mother_preview">
                            <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Add Attachment</button> 

                            <span id="preview"></span>
                        </div>
                </div>

                    <button type="button" class="save-button" onclick="saveProgramData()" id="save-btn" style="margin-left:46% !important">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }

   

}


function saveProgramDatav1(){
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var modals = document.querySelector('.modals');
    var form = document.getElementById('form');
    const donor = document.getElementById('Donor').value.trim();
    const quantity = document.getElementById('quantity').value.trim();
    const amount = document.getElementById('Amount').value.trim();
    const date = document.getElementById('Date').value.trim();
    const receiptNo = document.getElementById('ReceiptNo').value.trim();
    const category = document.getElementById('category').value.trim();

    // Validate required fields
    if (!donor || !amount || !date || !receiptNo || !category) {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Error', 'All fields are required. Please fill in all fields before saving.', 'error');
        return;
    }

    var formData = new FormData();
    formData.append('donor', donor);
    formData.append('quantity', quantity);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('receiptNo', receiptNo);
    formData.append('category', category);
    formData.append('image', chosen_file2); // Assuming 'chosen_file2' is set elsewhere

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);

        // Reset the form and close the modal
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        
        swal('Success', "Record saved!", 'success');
        window.location.reload(); // Reload the page after saving
        getProgramData(); // Refresh data after saving
    }

    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=save-ProgramData', true);
   
    console.log("formData", formData);
    xhttp.send(formData);
}

function editProgramDatav1(programDataId){

    var data = programData.find((programDatum)=>{
        console.log("programDatum.id",programDatum.id)
        return programDatum.id == programDataId
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input,select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 900px;
            /* overflow-x: scroll;
            overflow-y: scroll; 
             overflow-y: scroll;
            */
           
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Edit</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                       
                  <div class="three-forms">
                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required  value="${data.donor}" />
                        </div>


                <div class="form_element">
                    <label for="Item">Category Items</label>
                    <select id="category" onchange="toggleQuantityField()">
                        <option value=""></option>
                        <option value="Cash" ${data.item === 'Cash' ? 'selected' : ''}>Cash</option>
                        <option value="Medication" ${data.item === 'Medication' ? 'selected' : ''}>Medication</option>
                        <option value="Rice" ${data.item === 'Rice' ? 'selected' : ''}>Rice</option>
                        <option value="Beans" ${data.item === 'Beans' ? 'selected' : ''}>Beans</option>
                        <option value="Clothes" ${data.item === 'Clothes' ? 'selected' : ''}>Clothes</option>
                    </select>
            </div>


                       <div class="form_element" id="quantityField">
                                <label for="Item">Quantity <em style="font-size:10px;">( in Kg,Pcs,Pack)</em></label>
                                <input type="text" id="quantity" required  placeholder="" value="${data.quantity}" />
                        </div>

                      
                </div>

                <div class="three-forms">

                        <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required  value="${data.amount}"/>
                        </div>

                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required  value="${data.date}"/>
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required  value="${data.receiptNo}"/>
                        </div>
                    
                       
                 </div>

                 <div class="three-forms">
                  <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex; flex-direction:column; justify-content:flex-start;align-items:flex-start; " id="mother_preview">

                         <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Change Attachment</button> 

                            

                            <span id="preview" style="display:flex; flex-direction:column; ">
                           
                                    <img class="receipt-imag" src="../uploads/${data.receipt_Image}" alt="Receipts" style="width:260px;height:40px;" margin-bottom: 40px;">
                            </span>

                        </div>
                </div>

                    <button type="button" class="save-button" onclick="updateProgramData(${data.id})" id="save-btn" style="margin-left:46% !important">Update</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function viewProgramDatav1(programDataId){

    var data = programData.find((programDatum)=>{
        console.log("programDatum.id",programDatum.id)
        return programDatum.id == programDataId
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input,select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 900px;
            /* overflow-x: scroll;
            overflow-y: scroll; 
             overflow-y: scroll;
            */
           
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>View</h3>
                 <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">

        <div class="three-forms">
        <div></div>
        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/printLogo.png" alt="" style="height:60px; width:80px;margin-left:90px; margin-bottom:40px" />
         <div></div>
        </div>
                    <div class="three-forms">
                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required  value="${data.donor}"  readonly disabled/>
                        </div>


                <div class="form_element">
                    <label for="Item">Category Items</label>
                    <select id="category" onchange="toggleQuantityField()"  disabled>
                        <option value=""></option>
                        <option value="Cash" ${data.item === 'Cash' ? 'selected' : ''}>Cash</option>
                        <option value="Medication" ${data.item === 'Medication' ? 'selected' : ''}>Medication</option>
                        <option value="Rice" ${data.item === 'Rice' ? 'selected' : ''}>Rice</option>
                        <option value="Beans" ${data.item === 'Beans' ? 'selected' : ''}>Beans</option>
                        <option value="Clothes" ${data.item === 'Clothes' ? 'selected' : ''}>Clothes</option>
                    </select>
            </div>


                       <div class="form_element" id="quantityField">
                                <label for="Item">Quantity <em style="font-size:10px;">( in Kg,Pcs,Pack)</em></label>
                                <input type="text" id="quantity" required  placeholder="" value="${data.quantity}" readonly disabled/>
                        </div>

                      
                </div>

                <div class="three-forms">

                        <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required  value="${data.amount}" readonly disabled/>
                        </div>

                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required  value="${data.date}" readonly disabled/>
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required  value="${data.receiptNo}" readonly disabled/>
                        </div>
                    
                       
                 </div>

                 <div class="three-forms">
<div></div>
                  <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex; flex-direction:column; justify-content:flex-start; " id="mother_preview">

         

                            <span id="preview">
                                    <img class="receipt-imag" src="../uploads/${data.receipt_Image}" alt="Receipts" style="width:370px;height:190px;" margin-bottom: 40px;">
                            </span>
                        </div>
                        <div></div>
                </div>

    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}


function updateProgramDatav1(programDataId){
    console.log("programDataId",programDataId)
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var modals = document.querySelector('.modals');
    var form = document.getElementById('form');
    const donor = document.getElementById('Donor').value.trim();
    const quantity = document.getElementById('quantity').value.trim();
    const amount = document.getElementById('Amount').value.trim();
    const date = document.getElementById('Date').value.trim();
    const receiptNo = document.getElementById('ReceiptNo').value.trim();
    const category = document.getElementById('category').value.trim();

    // Validate required fields
    if (!donor || !amount || !date || !receiptNo || !category) {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Error', 'All fields are required. Please fill in all fields before saving.', 'error');
        return;
    }

    var formData = new FormData();
    formData.append('donor', donor);
    formData.append('quantity', quantity);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('receiptNo', receiptNo);
    formData.append('category', category);
    formData.append('image', chosen_file2);
    formData.append('programDataId', programDataId);
    
    // Assuming 'chosen_file2' is set elsewhere
    console.log("formData", formData);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);

        // Reset the form and close the modal
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        
        swal('Success', "Record saved!", 'success');
        window.location.reload(); 
        // Reload the page after saving
        getProgramData(); // Refresh data after saving
    }

    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=update-ProgramData', true);
   
   
    xhttp.send(formData);
}