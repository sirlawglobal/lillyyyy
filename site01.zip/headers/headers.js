if (window.location.pathname !== '/index.html') { // Adjust the path according to your setup
    document.addEventListener('DOMContentLoaded', function(){
        var admin = JSON.parse(window.sessionStorage.getItem('admin'));
        
        
        if (!admin) {
            window.location.href = '../index.html';
        }
    });
}
// Finance dropdown
function viewDropdownItems(element) {
    var path = window.location.pathname;
    
    // Check if the current path matches any of the specified pages
    if (path == '/balanceSheet/balancesheet.html' || 
        path == '/receipt/receipt.html' || 
        path == '/payment/payment.html') {
        
        // Get the id of the clicked element
        var id = element.getAttribute('id');
        var split_id = id.split('-');
        var value = split_id[0];
        
        // Get the dropdown element and toggle its display
        var dropdownElement = document.getElementById(value);
        dropdownElement.style.display = dropdownElement.style.display === 'block' ? 'none' : 'block'; // Toggle visibility

    } else {
        // Navigate to dashboard for other paths
        window.location.href = '#';
    }
}
function viewDropdownReport(element) {
    var path = window.location.pathname;
    
    // Check if the current path matches any of the specified pages
    if (path == '/report/beneficiarydomain.html' || 
        path == '/report/programmedomain.html' || 
        path == '/report/balancesheetreport.html' || 
        path == 'report/receiptreport.html' || 
        path == '/report/paymentreport.html'|| 
        path == '/report/balancesheetreport.html' ) {
        
        // Get the id of the clicked element
        var id = element.getAttribute('id');
        var split_id = id.split('-');
        var value = split_id[0];
        
        // Get the dropdown element and toggle its display
        var dropdownElement = document.getElementById(value);
        dropdownElement.style.display = dropdownElement.style.display === 'block' ? 'none' : 'block'; // Toggle visibility

    } else {
        // Navigate to dashboard for other paths
        window.location.href = '#';
    }
}

function viewDropdownItem(route){
    window.location.href = route;
}


var itemsdropped = false;
function toggleFinanceCollapse() {
    var contactElement = document.getElementById('finance');
    var contactDropdownImg = document.getElementById('finance-dropdown-img');
    itemsdropped = !itemsdropped;
    contactElement.style.display = itemsdropped ? 'block' : 'none';
    contactDropdownImg.style.transform = itemsdropped ? "rotate(180deg)" : "rotate(0deg)";
}

var reportdropped = false;
function toggleReportCollapse() {
    var reportElement = document.getElementById('report');
    var reportDropdownImg = document.getElementById('report-dropdown-img');
    reportdropped = !reportdropped;
    reportElement.style.display = reportdropped ? 'flex' : 'none';
    reportDropdownImg.style.transform = reportdropped ? "rotate(180deg)" : "rotate(0deg)";
}
// ensure finance dropdown remains opened

// ../receipt/receipt.html


document.addEventListener('DOMContentLoaded', function(event) {
    // alert("loaded")
    // var path = window.location.pathname;
    const path = window.location.pathname.toLowerCase();

    // Ensure the finance dropdown is opened if on the correct pages
    if (path === '/balanceSheet/balancesheet.html'|| 
        path === '/receipt/receipt.html' || 
        path === '/payment/payment.html') {
        var projectDropdownImg = document.getElementById('finance-dropdown-img');
        var dropdownElement = document.getElementById('finance');
        dropdownElement.style.display = 'block'; // Open the dropdown
    }
    // Ensure the report dropdown is opened if on the correct pages
    if (path === '/report/segregation.html' || 
        path === '/report/beneficiarydomain.html' || 
        path === '/report/programmedomain.html' || 
        path === '/report/receiptreport.html' || 
        path === '/report/paymentreport.html'|| 
        path === '/report/balancesheetreport.html') {
        var projectDropdownImg = document.getElementById('report-dropdown-img');
        var dropdownElement = document.getElementById('report');
        dropdownElement.style.display = 'block'; // Open the dropdown
    }

    // Highlight the active link in the sidebar
    const sidebarLinks = document.querySelectorAll('.leftbar-list a');
    sidebarLinks.forEach(link => {
        // Check if the link matches the current page URL
        
        if (link.href === window.location.href) {
            link.classList.add('active-link');
            
          
            // Toggle icons for the dashboard link
            if (link.classList.contains('dashboard-list')) {
                const dashboardIconGreen = link.querySelector('.icon-green');
                const dashboardIconWhite = link.querySelector('.icon-white');
                
                if (dashboardIconGreen && dashboardIconWhite) {
                    dashboardIconGreen.style.display = 'none'; // Hide green icon
                    dashboardIconWhite.style.display = 'inline'; // Show white icon
                }
            }
        } else {
            // Reset the dashboard icons if not on the dashboard
            if (link.classList.contains('dashboard-list')) {
                const dashboardIconGreen = link.querySelector('.icon-green');
                const dashboardIconWhite = link.querySelector('.icon-white');
                
                if (dashboardIconGreen && dashboardIconWhite) {
                    dashboardIconGreen.style.display = 'inline'; // Show green icon
                    dashboardIconWhite.style.display = 'none'; // Hide white icon
                }
            }
        }
    });

    // Highlight the active finance dropdown item
    const dropdownItemsFinance = document.querySelectorAll('#finance .dropdown-item');

    const dropdownItemsReport = document.querySelectorAll('#report .dropdown-item');

    dropdownItemsFinance.forEach(item => {
        const itemLink = item.querySelector('.dropdown-text');
        const itemPage = itemLink.textContent.trim().toLowerCase().replace(/\s+/g, '') + '.html'; // Adjust based on your naming convention
        
        // Check if the current path matches the item page

        
        if (path.endsWith(itemPage)) {
            item.classList.add('active-sublink'); // Add the active class to the matched item
        }
    });

    dropdownItemsReport.forEach(item => {
        const itemLink = item.querySelector('.dropdown-text');
        const itemPage = itemLink.textContent.trim().toLowerCase().replace(/\s+/g, '') + '.html'; // Adjust based on your naming convention
        
        // Check if the current path matches the item page

    
        if (path.includes(itemPage)) {
            item.classList.add('active-sublink'); // Add the active class to the matched item
        }
    });
});


const topHeader = document.getElementById('top-header');
const headerHide = document.getElementById('header-hide');

let headerText = ''
if(headerHide){
     headerText = headerHide.innerText;
}
const deletedHeader = `                <div style="display:flex; flex-direction:column">
                    <p class="top-text" style="font-size:30px; letter-spacing:3.5px; ">Ehi Centre</p>
                    <p class="top-text" style="font-size:9px; margin-top:-8px"><em>For social and economic development</em></p>

                </div>`

const topHeaderContent = 
` <nav class="top-nav2">
                <div style="display:flex;">

                <img src="../assets/images/ehi-logo.png" alt="" class="ehi-logo" syle="border:1px solid transparent; outline:none;">


                </div>


            <p class="top-text">${headerText}</p>

            <button class="sign-out-button" onclick="signOut()">Sign Out</button>
        </nav>
`

console.log(headerText);
if(topHeader){
    topHeader.innerHTML = topHeaderContent;
}

const leftBar = document.getElementById('left-bar');

const leftBarContent = ` <ul class="leftbar-list">
                <li >
                    <a href="../dashboard/dashboard.html" class="dashboard-list">
                        <img src="../assets/images/dashboard-icon.png" alt="" class="dashboard-icon icon-green">

                        <img src="../assets/images/white.svg" alt="" class="dashboard-icon icon-white">

                        Dashboard
                    </a>
                </li>
                <li >
                    <a href="../userdata/userdata.html" class="anchor-list">
                        User Data
                    </a>
                </li>
                <li >
                    <a href="../donordata/donordata.html" class="anchor-list">
                        Donor Data
                    </a>
                </li>
                <li >
                     <a href="../programdata/programdata.html" class="anchor-list">
                        Programme Data 
                        
                    </a>

                </li>
                <li >
                    <a href="../Disbursment/disbursement.html" class="anchor-list">
                        Disbursement 
                    </a>
                </li>

                <li >
                        <a href="javascript:void(0)" class="anchor-list" >
                            <span style="display:flex; gap:5px">
                                <p id="contact-dropdown" onclick="viewDropdownItems(this)">Finance </p>

                                <div onclick="toggleFinanceCollapse()" >
                                    <img class="search-dropdown-icon" src="../assets/images/dropdown-icon.png" alt="" id="finance-dropdown-img">
                                </div> 
                            </span>
                         <div id="finance" class="dropdown-container" style="display:none !important; margin-left:5px; ">

                       

                        <div class="dropdown-item" onclick="viewDropdownItem('../receipt/receipt.html')" syle=" cursor: pointer;"><span class="dropdown-text">Receipt </span>
                        </div>

                        <div class="dropdown-item" onclick="viewDropdownItem('../payment/payment.html')" syle=" cursor: pointer;"><span class="dropdown-text">Payment </span>
                        </div>

                         <div class="dropdown-item" onclick="viewDropdownItem('../balanceSheet/balancesheet.html')" syle=" cursor: pointer;"><span class="dropdown-text">BalanceSheet</span>
                        </div>
                        
                        </div>
                        </a>
                </li>
                <li>

                        <a href="javascript:void(0)" class="anchor-list" >
                            <span style="display:flex; gap:5px">
                                <p id="report-dropdown" onclick="viewDropdownReport(this)">Report</p>

                                <div onclick="toggleReportCollapse()" >
                                    <img class="search-dropdown-icon" src="../assets/images/dropdown-icon.png" alt="" id="report-dropdown-img">
                                </div> 
                            </span>


                         <div id="report" class="dropdown-container">

                        <div class="dropdown-item" onclick="viewDropdownItem('../report/segregation.html')" syle=" cursor: pointer;"><span class="dropdown-text">Segregation</span>
                        </div>

                        <div class="dropdown-item" onclick="viewDropdownItem('../report/beneficiarydomain.html')" syle=" cursor: pointer;"><span class="dropdown-text">Beneficiary Domain</span>
                        </div>
                        
                        <div class="dropdown-item" onclick="viewDropdownItem('../report/programmedomain.html')" syle=" cursor: pointer;"><span class="dropdown-text">Programme Domain</span>
                        </div>

                        

                        <div class="dropdown-item" onclick="viewDropdownItem('../report/receiptreport.html')" syle=" cursor: pointer;"><span class="dropdown-text"> Receipt  Report</span>
                        </div>
                        <div class="dropdown-item" onclick="viewDropdownItem('../report/paymentreport.html')" syle=" cursor: pointer;"><span class="dropdown-text"> Payment Report</span>
                        </div>
                        
                        
                        </div>
                        </a>
                </li>
 <li >
                    <a href="../archieve.html" class="anchor-list">
                       Archive
                    </a>
                </li>
            
            </ul>
`

if(leftBar){
    leftBar.innerHTML =leftBarContent
}

const footer = document.getElementById('footer');

const footerContent = `   <div class="first-footer">
            <img class="hans-logo" src="../assets/images/hans-logo.png" alt="hans-logo">
            <p class="footer-copyright">Powered by Hans Technology </p>

        </div>
        <div class="first-footer">
            <p class="footer-copyright">copyright <span><img src="../assets/images/Vector.png" alt=""></span>ehicentre2024</p>
        </div>
`
if(footer){
    footer.innerHTML = footerContent;
}

function signOut(){
   
    window.sessionStorage.removeItem('admin');
    window.location.href = '../index.html';
}



