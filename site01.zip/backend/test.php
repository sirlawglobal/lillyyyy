<?php

class Database {
    protected $host = "localhost";
    protected $user = "dgn128_new";
    protected $pass = "N!I(VPRjL+LO";
    protected $database = "dgn128_database_software";

    public $connect;

    public function __construct() {
        $this->logCronExecution("Cron job started");
        $this->connect = new mysqli($this->host, $this->user, $this->pass, $this->database);
        
        if ($this->connect->connect_error) {
            $this->logCronExecution("Connection error: " . $this->connect->connect_error);
            echo "Sorry, couldn't connect to the database: " . $this->connect->connect_error;
        } else {
            $this->logCronExecution("Database connected successfully");
            $this->insertArchive();
        }
    }

    public function query($sql) {
        return $this->connect->query($sql);
    }

    public function insertArchive() {
        $sql = "
        INSERT INTO archive (user_pin, first_name, last_name, gender, image, date, claimed_status)
        SELECT bd.user_pin, bd.first_name, bd.last_name, bd.gender, bd.image, dt.date, dt.status
        FROM biodata bd
        JOIN disbursement_table2 dt ON bd.user_pin = dt.user_pin
        WHERE dt.status = 'CLAIMED'
        AND dt.date < NOW() - INTERVAL 1 YEAR;
        ";

        $query = $this->connect->query($sql);
    
        if ($query === TRUE) {
            $this->logCronExecution("Records moved to archive successfully.");
            echo "Records moved to archive successfully.\n";
            $this->deleteMovedRecords();
        } else {
            $this->logCronExecution("Error moving records to archive: " . $this->connect->error);
            echo "Error moving records to archive: " . $this->connect->error . "\n";
        }
    }

    public function deleteMovedRecords() {
        $sql = "
        DELETE dt
        FROM disbursement_table2 dt
        JOIN archive a ON dt.user_pin = a.user_pin
        AND dt.date = a.date
        WHERE dt.status = 'CLAIMED'
        AND dt.date < NOW() - INTERVAL 1 YEAR;
        ";

        $query = $this->connect->query($sql);

        if ($query === TRUE) {
            $this->logCronExecution("Records deleted from disbursement_table2 successfully.");
            echo "Records deleted from disbursement_table2 successfully.\n";
        } else {
            $this->logCronExecution("Error deleting records from disbursement_table2: " . $this->connect->error);
            echo "Error deleting records from disbursement_table2: " . $this->connect->error . "\n";
        }
    }

    private function logCronExecution($message) {
        $currentDateTime = date('Y-m-d H:i:s');
        $logFile = '/home/dgn128/public_html/cron_test.log';
        file_put_contents($logFile, "$currentDateTime - $message\n", FILE_APPEND);
    }
}

new Database();

?>
