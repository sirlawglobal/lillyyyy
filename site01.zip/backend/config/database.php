<?php 


    class Database {
        protected $host = "localhost";
        protected $user = "ehicentre_sam";
        protected $pass = "v=[$+{w0,#ro";
        protected $database = "ehicentre_database_software";

        public $connect;

        public function __construct(){
            $this->connect = new mysqli($this->host, $this->user, $this->pass, $this->database);
            if($this->connect->connect_error){
                echo "Sorry, couldn't connect to the database".$this->connect->connect_error;
            }else{
                // $this->createAdminLogin();
            }
        }

        public function query($sql){
            $query = $this->connect->query($sql);
            return $query;
        }

        // public function createAdminLogin(){
        //     $email = "admin01@ehicentre.org.ng";
        //     $password = "fuTIc1owrf";
        //     $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
        //     $sql = "INSERT INTO admins(email, password) VALUES('{$email}', '{$hashed_password}')";
        //     $query = $this->connect->query($sql);
        //     return $query;
            
        // }

        public function adminLogin($email, $password){
            $sql = "SELECT * FROM admins WHERE email = '$email'";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $row = $query->fetch_assoc();
                $verify_password = password_verify($password, $row['password']);
                if($verify_password){
                    return $row;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }

        // UserData

        public function savePin($data){
            $user_pin = isset($data['user_pin']) ? $this->connect->real_escape_string($data['user_pin']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
          

            
            $sql = "INSERT INTO users(user_pin, date) VALUE('{$user_pin}', '{$date}' )";
            $query = $this->connect->query($sql);
            return $query;
        }

        public function getPin(){
            $sql = "SELECT * FROM users";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }


        public function saveBiodata($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
            $user_pin = isset($data['user_pin']) ? $this->connect->real_escape_string($data['user_pin']) : null;
            $first_name = isset($data['first_name']) ? $this->connect->real_escape_string($data['first_name']) : null;
            $last_name = isset($data['last_name']) ? $this->connect->real_escape_string($data['last_name']) : null;
            $age = isset($data['age']) ? $this->connect->real_escape_string($data['age']) : null;
            $gender = isset($data['gender']) ? $this->connect->real_escape_string($data['gender']) : null;
            $marital_status = isset($data['marital_status']) ? $this->connect->real_escape_string($data['marital_status']) : null;
            $disability = isset($data['disability']) ? $this->connect->real_escape_string($data['disability']) : null;
            $economic_activities = isset($data['economic_activities']) ? $this->connect->real_escape_string($data['economic_activities']) : null;
            $family_support = isset($data['family_support']) ? $this->connect->real_escape_string($data['family_support']) : null;
            $image = isset($data['image']) ? $this->connect->real_escape_string($data['image']) : null;

            
            $sql = "INSERT INTO biodata(user_id, user_pin, first_name, last_name, age, gender, marital_status, disability, economic_activities, family_support, image ) VALUES('{$user_id}', '{$user_pin}', '{$first_name}', '{$last_name}', '{$age}', '{$gender}', '{$marital_status}', '{$disability}', '{$economic_activities}', '{$family_support}', '{$image}' )";
            $query = $this->connect->query($sql);
            return $query;
        }

        
        public function updateBiodata($data, $files){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
  
            $first_name = isset($data['first_name']) ? $this->connect->real_escape_string($data['first_name']) : null;
            $last_name = isset($data['last_name']) ? $this->connect->real_escape_string($data['last_name']) : null;
            $age = isset($data['age']) ? $this->connect->real_escape_string($data['age']) : null;
            $gender = isset($data['gender']) ? $this->connect->real_escape_string($data['gender']) : null;
            $marital_status = isset($data['marital_status']) ? $this->connect->real_escape_string($data['marital_status']) : null;
            $disability = isset($data['disability']) ? $this->connect->real_escape_string($data['disability']) : null;
            $economic_activities = isset($data['economic_activities']) ? $this->connect->real_escape_string($data['economic_activities']) : null;
            $family_support = isset($data['family_support']) ? $this->connect->real_escape_string($data['family_support']) : null;

            $sql_img = "SELECT * FROM biodata WHERE user_id = '$user_id'";
            $query = $this->query($sql_img);
            $row_img = $query->fetch_assoc();
            $existing_image = $row_img['image']; 
            
            $image = $existing_image; 
    
            if (isset($files['image']) && $files['image']['error'] == UPLOAD_ERR_OK) {
               
                $upload_folder = "/home/ehicentre/public_html/uploads/";
                $file = $files['image'];
                $encrypted_name = uniqid() . '-' . $file['name'];
                $directory = $upload_folder . $encrypted_name;
    
                if (move_uploaded_file($file['tmp_name'], $directory)) {
                    if ($existing_image && file_exists($upload_folder . $existing_image)) {
                        unlink($upload_folder . $existing_image); // Delete the old image file
                    }
                    $image = $encrypted_name;
                } else {
                    return false; 
                }
            }



            
            $sql = "UPDATE biodata SET first_name = '$first_name', last_name = '$last_name', age = '$age', gender = '$gender', marital_status = '$marital_status', disability = '$disability', economic_activities = '$economic_activities', family_support = '$family_support', image = '$image' WHERE user_id = '$user_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
       
        public function saveLocation($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
            $user_pin = isset($data['user_pin']) ? $this->connect->real_escape_string($data['user_pin']) : null;
            $house_number = isset($data['house_number']) ? $this->connect->real_escape_string($data['house_number']) : null;
            $street = isset($data['street']) ? $this->connect->real_escape_string($data['street']) : null;
            $area_community = isset($data['area_community']) ? $this->connect->real_escape_string($data['area_community']) : null;
            $city_village = isset($data['city_village']) ? $this->connect->real_escape_string($data['city_village']) : null;
            $state = isset($data['state']) ? $this->connect->real_escape_string($data['state']) : null;
          
            
            $sql = "INSERT INTO location(user_id, user_pin, house_number, street, area_community, city_village, state) VALUES('{$user_id}', '{$user_pin}', '{$house_number}', '{$street}', '{$area_community}', '{$city_village}', '{$state}' )";
            $query = $this->connect->query($sql);
            return $query;
        }

        public function updateLocation($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
  
   
   
            $house_number = isset($data['house_number']) ? $this->connect->real_escape_string($data['house_number']) : null;
            $street = isset($data['street']) ? $this->connect->real_escape_string($data['street']) : null;
            $area_community = isset($data['area_community']) ? $this->connect->real_escape_string($data['area_community']) : null;
            $city_village = isset($data['city_village']) ? $this->connect->real_escape_string($data['city_village']) : null;
            $state = isset($data['state']) ? $this->connect->real_escape_string($data['state']) : null;


            
            $sql = "UPDATE location SET house_number = '$house_number', street = '$street', area_community = '$area_community', city_village = '$city_village', state = '$state' WHERE user_id = '$user_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }






        public function savePovertyStatus($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
            $user_pin = isset($data['user_pin']) ? $this->connect->real_escape_string($data['user_pin']) : null;
            $nature_type_of_business = isset($data['nature_type_of_business']) ? $this->connect->real_escape_string($data['nature_type_of_business']) : null;
            $size_of_business = isset($data['size_of_business']) ? $this->connect->real_escape_string($data['size_of_business']) : null;
            $location_of_business = isset($data['location_of_business']) ? $this->connect->real_escape_string($data['location_of_business']) : null;
            $daily_income = isset($data['daily_income']) ? $this->connect->real_escape_string($data['daily_income']) : null;
            $family_marital_status = isset($data['family_marital_status']) ? $this->connect->real_escape_string($data['family_marital_status']) : null;
            $family_size_of_business = isset($data['family_size_of_business']) ? $this->connect->real_escape_string($data['family_size_of_business']) : null;
            $number_of_children = isset($data['number_of_children']) ? $this->connect->real_escape_string($data['number_of_children']) : null;
            $age_of_spouse = isset($data['age_of_spouse']) ? $this->connect->real_escape_string($data['age_of_spouse']) : null;
            $nature_of_occupation_spouse = isset($data['nature_of_occupation_spouse']) ? $this->connect->real_escape_string($data['nature_of_occupation_spouse']) : null;
            $own_home = isset($data['own_home']) ? $this->connect->real_escape_string($data['own_home']) : null;
            $size_of_dwelling = isset($data['size_of_dwelling']) ? $this->connect->real_escape_string($data['size_of_dwelling']) : null;
            $main_type_of_meal = isset($data['main_type_of_meal']) ? $this->connect->real_escape_string($data['main_type_of_meal']) : null;
            $level_of_education = isset($data['level_of_education']) ? $this->connect->real_escape_string($data['level_of_education']) : null;
            $major_illiness = isset($data['major_illiness']) ? $this->connect->real_escape_string($data['major_illiness']) : null;

        
            $sql = "INSERT INTO poverty_status(
                        user_id, user_pin, nature_type_of_business, size_of_business, 
                        location_of_business, daily_income, family_marital_status, family_size_of_business, number_of_children, age_of_spouse, nature_of_occupation_spouse, 
                        own_home, size_of_dwelling, main_type_of_meal, level_of_education, major_illiness
                    ) VALUES(
                        '{$user_id}', '{$user_pin}', '{$nature_type_of_business}', 
                        '{$size_of_business}', '{$location_of_business}', '{$daily_income}','{$family_marital_status}', '{$family_size_of_business}','{$number_of_children}', 
                        '{$age_of_spouse}', '{$nature_of_occupation_spouse}', '{$own_home}', '{$size_of_dwelling}', 
                        '{$main_type_of_meal}', '{$level_of_education}', '{$major_illiness}'
                    )";

            $query = $this->connect->query($sql);
            return $query;
        }

        public function updatePovertyStatus($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;

            $nature_type_of_business = isset($data['nature_type_of_business']) ? $this->connect->real_escape_string($data['nature_type_of_business']) : null;
            $size_of_business = isset($data['size_of_business']) ? $this->connect->real_escape_string($data['size_of_business']) : null;
            $location_of_business = isset($data['location_of_business']) ? $this->connect->real_escape_string($data['location_of_business']) : null;
            $daily_income = isset($data['daily_income']) ? $this->connect->real_escape_string($data['daily_income']) : null;
            $family_marital_status = isset($data['family_marital_status']) ? $this->connect->real_escape_string($data['family_marital_status']) : null;
            $family_size_of_business = isset($data['family_size_of_business']) ? $this->connect->real_escape_string($data['family_size_of_business']) : null;
            $number_of_children = isset($data['number_of_children']) ? $this->connect->real_escape_string($data['number_of_children']) : null;
            $age_of_spouse = isset($data['age_of_spouse']) ? $this->connect->real_escape_string($data['age_of_spouse']) : null;
            $nature_of_occupation_spouse = isset($data['nature_of_occupation_spouse']) ? $this->connect->real_escape_string($data['nature_of_occupation_spouse']) : null;
            $own_home = isset($data['own_home']) ? $this->connect->real_escape_string($data['own_home']) : null;
            $size_of_dwelling = isset($data['size_of_dwelling']) ? $this->connect->real_escape_string($data['size_of_dwelling']) : null;
            $main_type_of_meal = isset($data['main_type_of_meal']) ? $this->connect->real_escape_string($data['main_type_of_meal']) : null;
            $level_of_education = isset($data['level_of_education']) ? $this->connect->real_escape_string($data['level_of_education']) : null;
            $major_illiness = isset($data['major_illiness']) ? $this->connect->real_escape_string($data['major_illiness']) : null;

            
            $sql = "UPDATE poverty_status SET nature_type_of_business = '$nature_type_of_business', size_of_business = '$size_of_business', location_of_business = '$location_of_business', daily_income = '$daily_income', family_marital_status = '$family_marital_status' ,family_size_of_business = '$family_size_of_business' ,number_of_children = '$number_of_children' , age_of_spouse = '$age_of_spouse' , nature_of_occupation_spouse = '$nature_of_occupation_spouse' , own_home = '$own_home' , size_of_dwelling = '$size_of_dwelling' , main_type_of_meal = '$main_type_of_meal' , level_of_education = '$level_of_education' , major_illiness = '$major_illiness'  WHERE user_id = '$user_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }


        public function saveId($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
            $user_pin = isset($data['user_pin']) ? $this->connect->real_escape_string($data['user_pin']) : null;
            $id_name = isset($data['id_name']) ? $this->connect->real_escape_string($data['id_name']) : null;
            $id_number = isset($data['id_number']) ? $this->connect->real_escape_string($data['id_number']) : null;
            $issue_date_number = isset($data['issue_date_number']) ? $this->connect->real_escape_string($data['issue_date_number']) : null;
            $expiry_date_number = isset($data['expiry_date_number']) ? $this->connect->real_escape_string($data['expiry_date_number']) : null;
        

            $sql = "INSERT INTO id_info(user_id, user_pin, id_name, id_number, issue_date_number, expiry_date_number) 
                    VALUES('{$user_id}', '{$user_pin}', '{$id_name}', '{$id_number}', '{$issue_date_number}', '{$expiry_date_number}')";
            
            $query = $this->connect->query($sql);
            return $query;
        }

        public function updateId($data){
            $user_id = isset($data['user_id']) ? $this->connect->real_escape_string($data['user_id']) : null;
  
   
   
            $id_name = isset($data['id_name']) ? $this->connect->real_escape_string($data['id_name']) : null;
            $id_number = isset($data['id_number']) ? $this->connect->real_escape_string($data['id_number']) : null;
            $issue_date_number = isset($data['issue_date_number']) ? $this->connect->real_escape_string($data['issue_date_number']) : null;
            $expiry_date_number = isset($data['expiry_date_number']) ? $this->connect->real_escape_string($data['expiry_date_number']) : null;

            
            $sql = "UPDATE id_info SET id_name = '$id_name', id_number = '$id_number', issue_date_number = '$issue_date_number', expiry_date_number = '$expiry_date_number' WHERE user_id = '$user_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function getAllUserData(){
            $sql = "
                SELECT 
                    users.id,
                    users.user_pin,
                    users.date,
                    biodata.first_name, biodata.last_name, biodata.age, biodata.gender, 
                    biodata.marital_status, biodata.disability, biodata.economic_activities, 
                    biodata.family_support,  biodata.image,
                    location.house_number, location.area_community, location.street, location.city_village,location.state,
                    poverty_status.nature_type_of_business, poverty_status.size_of_business, 
                    poverty_status.location_of_business, poverty_status.number_of_children, 
                    poverty_status.age_of_spouse, poverty_status.nature_of_occupation_spouse, 
                    poverty_status.own_home, poverty_status.size_of_dwelling, 
                    poverty_status.main_type_of_meal, poverty_status.level_of_education, 
                    poverty_status.major_illiness, poverty_status.daily_income, poverty_status.family_size_of_business, poverty_status.family_marital_status,
                    id_info.id_name, id_info.id_number, id_info.issue_date_number, 
                    id_info.expiry_date_number
                FROM users
                LEFT JOIN biodata ON users.id = biodata.user_id AND users.user_pin = biodata.user_pin
                LEFT JOIN location ON users.id = location.user_id AND users.user_pin = location.user_pin
                LEFT JOIN poverty_status ON users.id = poverty_status.user_id AND users.user_pin = poverty_status.user_pin
                LEFT JOIN id_info ON users.id = id_info.user_id AND users.user_pin = id_info.user_pin
            ";
        
            $query = $this->connect->query($sql);
            
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

        
        public function deleteUserData($data) {
            $id = $data['id'];
            $user_pin = isset($data['user_pin']) ? $this->connect->real_escape_string($data['user_pin']) : null;
        
            $sql = "
                DELETE users, biodata, location, poverty_status, id_info
                FROM users
                LEFT JOIN biodata ON users.id = biodata.user_id
                LEFT JOIN location ON users.id = location.user_id
                LEFT JOIN poverty_status ON users.id = poverty_status.user_id
                LEFT JOIN id_info ON users.id = id_info.user_id
                WHERE users.id = ?
            ";
        
            $stmt = $this->connect->prepare($sql);
            $stmt->bind_param("i", $id);

            $sqlItems = "DELETE FROM disbursement_items2 WHERE user_pin = '$user_pin'";

            $this->connect->query($sqlItems);
        
            
            $sql = "DELETE FROM disbursement_table2 WHERE user_pin = '$user_pin'";
            
            $this->connect->query($sql);

            if ($stmt->execute()) {
                return $stmt->affected_rows;
            } else {
                error_log("Delete operation failed: " . $stmt->error);
                return false;
            }
        }
        




                // Receipt



                public function saveReceipt($data){
                    $receipt = isset($data['receipt']) ? $this->connect->real_escape_string($data['receipt']) : null;
                    $donor_name = isset($data['donor_name']) ? $this->connect->real_escape_string($data['donor_name']) : null;
                    $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;
                    $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
             
                  
                    
                    $sql = "INSERT INTO receipt(receipt, donor_name, amount, date) VALUES('{$receipt}', '{$donor_name}', '{$amount}', '{$date}')";
                    $query = $this->connect->query($sql);
                    return $query;
                }

                public function getReceipt(){
                    $sql = "SELECT * FROM receipt";
                
                    $query = $this->connect->query($sql);
                    
                    if($query->num_rows > 0){
                        $data = [];
                        while($row = $query->fetch_assoc()){
                            array_push($data, $row);
                        }
                        return $data;
                    }else{
                        return false;
                    }
                }

                public function updateReceipt($data){
                    $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
          
           
           
                    $receipt = isset($data['receipt']) ? $this->connect->real_escape_string($data['receipt']) : null;
                    $donor_name = isset($data['donor_name']) ? $this->connect->real_escape_string($data['donor_name']) : null;
                    $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;
                    $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
        
                    
                    $sql = "UPDATE receipt SET receipt = '$receipt', donor_name = '$donor_name', amount = '$amount', date = '$date' WHERE id = '$id'";
                    $query = $this->connect->query($sql);
                    if($query){
                        return true;
                    }else{
                        return false;
                    }
                }

                public function deleteReceipt($data){
                    $id = $data['id'];
                    $sql = "DELETE FROM receipt WHERE id = '$id'";
                    $query = $this->connect->query($sql);
                    if($query){
                        return true;
                    }else{
                        return false;
                    }
                }

                // Payment

                public function savePayment($data){
                    $payment = isset($data['payment']) ? $this->connect->real_escape_string($data['payment']) : null;
                    $payment_details = isset($data['payment']) ? $this->connect->real_escape_string($data['payment_details']) : null;
                    $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;
                    $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
             
                  
                    
                    $sql = "INSERT INTO payment(payment, amount, date, payment_details) VALUES('{$payment}', '{$amount}', '{$date}', '{$payment_details}')";
                    $query = $this->connect->query($sql);
                    return $query;
                }

                public function getPayment(){
                    $sql = "SELECT * FROM payment";
                
                    $query = $this->connect->query($sql);
                    
                    if($query->num_rows > 0){
                        $data = [];
                        while($row = $query->fetch_assoc()){
                            array_push($data, $row);
                        }
                        return $data;
                    }else{
                        return false;
                    }
                }

                
                public function updatePayment($data){
                    $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
          
                    $payment = isset($data['payment']) ? $this->connect->real_escape_string($data['payment']) : null;
                    $payment_details = isset($data['payment_details']) ? $this->connect->real_escape_string($data['payment_details']) : null;
                    $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;
                    $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
        
                    
                    $sql = "UPDATE payment SET payment = '$payment', amount = '$amount', date = '$date', payment_details = '$payment_details' WHERE id = '$id'";
                    $query = $this->connect->query($sql);
                    if($query){
                        return true;
                    }else{
                        return false;
                    }
                }

                public function deletePayment($data){
                    $id = $data['id'];
                    $sql = "DELETE FROM payment WHERE id = '$id'";
                    $query = $this->connect->query($sql);
                    if($query){
                        return true;
                    }else{
                        return false;
                    }
                }



                // Donor
                // public function saveDonor($data){
                //     $last_name = isset($data['last_name']) ? $this->connect->real_escape_string($data['last_name']) : null;
                //     $first_name = isset($data['first_name']) ? $this->connect->real_escape_string($data['first_name']) : null;
                //     $email = isset($data['email']) ? $this->connect->real_escape_string($data['email']) : null;
                //     $phone_no = isset($data['phone_no']) ? $this->connect->real_escape_string($data['phone_no']) : null;
                //     $address = isset($data['address']) ? $this->connect->real_escape_string($data['address']) : null;
                //     $gender = isset($data['gender']) ? $this->connect->real_escape_string($data['gender']) : null;
                //     $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
             
                  
                    
                //     $sql = "INSERT INTO donors(last_name, first_name email, phone_no, address, gender, date) VALUES('{$last_name}', '{$first_name}', '{$email}', '{$phone_no}', '{$address}', '{$gender}', '{$date}')";
                //     $query = $this->connect->query($sql);
                //     return $query;
                // }

                // public function getDonor(){
                //     $sql = "SELECT * FROM donors";
                
                //     $query = $this->connect->query($sql);
                    
                //     if($query->num_rows > 0){
                //         $data = [];
                //         while($row = $query->fetch_assoc()){
                //             array_push($data, $row);
                //         }
                //         return $data;
                //     }else{
                //         return false;
                //     }
                // }

                
                // public function updateDonor($data){
                //     $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
          
                //     $last_name = isset($data['last_name']) ? $this->connect->real_escape_string($data['last_name']) : null;
                //     $first_name = isset($data['first_name']) ? $this->connect->real_escape_string($data['first_name']) : null;
                //     $email = isset($data['email']) ? $this->connect->real_escape_string($data['email']) : null;
                //     $phone_no = isset($data['phone_no']) ? $this->connect->real_escape_string($data['phone_no']) : null;
                //     $address = isset($data['address']) ? $this->connect->real_escape_string($data['address']) : null;
                //     $gender = isset($data['gender']) ? $this->connect->real_escape_string($data['gender']) : null;
        
                    
                //     $sql = "UPDATE donors SET last_name = '$last_name', first_name = '$first_name', email = '$email', phone_no = '$phone_no', address = '$address', gender = '$gender' WHERE id = '$id'";
                //     $query = $this->connect->query($sql);
                //     if($query){
                //         return true;
                //     }else{
                //         return false;
                //     }
                // }




        
        


        
        //programm data "v1" is the old code
        public function saveDonor($data , $files){

            $last_name = isset($data['last_name']) ? $this->connect->real_escape_string($data['last_name']) : null;
            $first_name = isset($data['first_name']) ? $this->connect->real_escape_string($data['first_name']) : null;
            $email = isset($data['email']) ? $this->connect->real_escape_string($data['email']) : null;
            $phone_no = isset($data['phone_no']) ? $this->connect->real_escape_string($data['phone_no']) : null;
            $address = isset($data['address']) ? $this->connect->real_escape_string($data['address']) : null;
            $gender = isset($data['gender']) ? $this->connect->real_escape_string($data['gender']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;

            $donor = isset($data['donor']) ? $this->connect->real_escape_string($data['donor']) : null;


            $type_of_donor = isset($data['type_of_donor']) ? $this->connect->real_escape_string($data['type_of_donor']) : null;

            $item_category = isset($data['category']) ? $this->connect->real_escape_string($data['category']) : null;

            $quantity = isset($data['quantity']) ? $this->connect->real_escape_string($data['quantity']) : null;

            $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;

            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;

            $receiptNo = isset($data['receiptNo']) ? $this->connect->real_escape_string($data['receiptNo']) : null;


            $image = '';
            if(isset($files['image'])){
                $upload_folder = "/home/ehicentre/public_html/uploads/";
                // $upload_folder = "./uploads/"
                $file = $files['image'];
                $encrypted_name = uniqid(). '-' .$file['name'];
                $directory = $upload_folder.$encrypted_name;

                if(move_uploaded_file($file['tmp_name'], $directory)){
                    $image = $encrypted_name;
                } else {
                    return false;
                }
                }

              $sql = "INSERT INTO ProgramData_table (last_name, first_name, email, phone_no, address, gender,donor,type_of_donor, item, quantity, amount, date, receiptNo, receipt_Image) 
            VALUES ('{$last_name}', '{$first_name}', '{$email}', '{$phone_no}', '{$address}', '{$gender}','{$donor}', '{$type_of_donor}', '$item_category','$quantity', '$amount', '$date', '$receiptNo', '$image')";

            $query = $this->connect->query($sql);
            return $query;
        }

        public function updateDonor($data , $files){

            $programDataId = isset($data['programDataId']) ? $this->connect->real_escape_string($data['programDataId']) : null;

            
            $last_name = isset($data['last_name']) ? $this->connect->real_escape_string($data['last_name']) : null;
            $first_name = isset($data['first_name']) ? $this->connect->real_escape_string($data['first_name']) : null;
            $email = isset($data['email']) ? $this->connect->real_escape_string($data['email']) : null;
            $phone_no = isset($data['phone_no']) ? $this->connect->real_escape_string($data['phone_no']) : null;
            $address = isset($data['address']) ? $this->connect->real_escape_string($data['address']) : null;
            $gender = isset($data['gender']) ? $this->connect->real_escape_string($data['gender']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;


            $donor = isset($data['donor']) ? $this->connect->real_escape_string($data['donor']) : null;

            $type_of_donor = isset($data['type_of_donor']) ? $this->connect->real_escape_string($data['type_of_donor']) : null;


            $item_category = isset($data['category']) ? $this->connect->real_escape_string($data['category']) : null;

            $quantity = isset($data['quantity']) ? $this->connect->real_escape_string($data['quantity']) : null;

            $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;

            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;

            $receiptNo = isset($data['receiptNo']) ? $this->connect->real_escape_string($data['receiptNo']) : null;


            $image = '';
            if(isset($files['image'])){
                $upload_folder = "/home/ehicentre/public_html/uploads/";
                // $upload_folder = "./uploads/"
                $file = $files['image'];
                $encrypted_name = uniqid(). '-' .$file['name'];
                $directory = $upload_folder.$encrypted_name;

                if(move_uploaded_file($file['tmp_name'], $directory)){
                    $image = $encrypted_name;
                } else {
                    return false;
                }
                }

                $sql = "UPDATE ProgramData_table SET 
                last_name = '$last_name', first_name = '$first_name', email = '$email', phone_no = '$phone_no', address = '$address', gender = '$gender',
                donor = '$donor', 
                type_of_donor = '$type_of_donor', 
                receipt_image = '$image',
                item = '$item_category', 
                quantity = '$quantity', 
                amount = '$amount', 
                date = '$date', 
                receiptNo = '$receiptNo' WHERE id = '$programDataId'";

            $query = $this->connect->query($sql);
            return $query;
        }

        public function getDonor(){
            $sql = "SELECT * FROM ProgramData_table ORDER BY id DESC";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

        public function deleteDonor($data){
            $id = $data['id'];
            $sql = "DELETE FROM ProgramData_table WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function updateStock($data) {

            $id = 1;
            $rice_quantity = $data['riceQuantity'];
            $rice_amount = $data['riceAmount'];
            $beans_quantity = $data['beansQuantity'];
            $beans_amount = $data['beansAmount'];
            $cash_quantity = $data['cashQuantity'];
            $cash_amount = $data['cashAmount'];
            $medicine_quantity = $data['medicineQuantity'];
            $medicine_amount = $data['medicineAmount'];
            $clothes_quantity = $data['clothesQuantity'];
            $clothes_amount = $data['clothesAmount'];
        
            $sql_rice = "UPDATE rice_in_stock SET 
                        quantity = '$rice_quantity', 
                        amount = '$rice_amount' 
                        WHERE id = '$id'";
            $query_rice = $this->connect->query($sql_rice);
        
            $sql_beans = "UPDATE beans_in_stock SET 
                        quantity = '$beans_quantity', 
                        amount = '$beans_amount' 
                        WHERE id = '$id'";
            $query_beans = $this->connect->query($sql_beans);
        
            $sql_cash = "UPDATE cash_in_stock SET 
                        quantity = '$cash_quantity', 
                        amount = '$cash_amount' 
                        WHERE id = '$id'";
            $query_cash = $this->connect->query($sql_cash);
        
            $sql_medicine = "UPDATE medicine_in_stock SET 
                        quantity = '$medicine_quantity', 
                        amount = '$medicine_amount' 
                        WHERE id = '$id'";
            $query_medicine = $this->connect->query($sql_medicine);
        
            $sql_clothes = "UPDATE clothes_in_stock SET 
                        quantity = '$clothes_quantity', 
                        amount = '$clothes_amount' 
                        WHERE id = '$id'";
            $query_clothes = $this->connect->query($sql_clothes);
        
            if ($query_rice && $query_beans && $query_cash && $query_medicine && $query_clothes) {
                return ['success' => "Data updated successfully!"];
            } else {
                return ['error' => "Failed to update data"];
            }
        }

        public function getItemsInStock() {
            $sql = "
                SELECT 'Rice' AS item, quantity, amount FROM rice_in_stock
                UNION ALL
                SELECT 'Beans', quantity, amount FROM beans_in_stock
                UNION ALL
                SELECT 'Medication', quantity, amount FROM medicine_in_stock
                UNION ALL
                SELECT 'Clothes', quantity, amount FROM clothes_in_stock
                UNION ALL
                SELECT 'Cash', quantity, amount FROM cash_in_stock;
            ";
        
            $result = $this->connect->query($sql);
        
            $items = [];
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $items[] = $row;
                }
            }
        
            echo json_encode(['items' => $items]);
        }
        

        


        



        public function saveProgramData($data) { 
            // Fetch and sanitize the data
            $beneficiary = isset($data['beneficiary']) ? $this->connect->real_escape_string($data['beneficiary']) : null;
            $pin = isset($data['pin']) ? $this->connect->real_escape_string($data['pin']) : null;
            $safety = isset($data['safety']) ? $this->connect->real_escape_string($data['safety']) : null;
            $enrolledDate = isset($data['enrolledDate']) ? $this->connect->real_escape_string($data['enrolledDate']) : null;
            
            // Set exitedDate to null if not provided
            $exitedDate = isset($data['exitedDate']) && !empty($data['exitedDate']) ? $this->connect->real_escape_string($data['exitedDate']) : null;
        
            $upliftment = isset($data['upliftment']) ? $this->connect->real_escape_string($data['upliftment']) : null;
            $upliftmentEnrolledDate = isset($data['upliftmentEnrolledDate']) ? $this->connect->real_escape_string($data['upliftmentEnrolledDate']) : null;
            $upliftmentExitedDate = isset($data['upliftmentExitedDate']) ? $this->connect->real_escape_string($data['upliftmentExitedDate']) : null;
            $microCredit = isset($data['microCredit']) ? $this->connect->real_escape_string($data['microCredit']) : null;
            $institution = isset($data['institution']) ? $this->connect->real_escape_string($data['institution']) : null;
        
            // Prepare the SQL statement
            $sql = "INSERT INTO ProgramData_table2 (
                        beneficiary, safety, enrolledDate, exitedDate, upliftment, 
                        upliftmentEnrolledDate, upliftmentExitedDate, microCredit, institution,user_pin
                    ) VALUES (
                        '$beneficiary', '$safety', '$enrolledDate', '$exitedDate', '$upliftment', 
                        '$upliftmentEnrolledDate', '$upliftmentExitedDate', '$microCredit', '$institution','$pin'
                    )";
        
            // Execute the query
            $query = $this->connect->query($sql);
            return $query;
        }
        
        public function updateProgramData($data) {
            // Fetch and sanitize the data
            $programDataId = isset($data['programDataId']) ? $this->connect->real_escape_string($data['programDataId']) : null;

            $pin = isset($data['pin']) ? $this->connect->real_escape_string($data['pin']) : null;
            $beneficiary = isset($data['beneficiary']) ? $this->connect->real_escape_string($data['beneficiary']) : null;
            $safety = isset($data['safety']) ? $this->connect->real_escape_string($data['safety']) : null;
            $enrolledDate = isset($data['enrolledDate']) ? $this->connect->real_escape_string($data['enrolledDate']) : null;
            
            // Set exitedDate to null if not provided
            $exitedDate = isset($data['exitedDate']) && !empty($data['exitedDate']) ? $this->connect->real_escape_string($data['exitedDate']) : null;
        
            $upliftment = isset($data['upliftment']) ? $this->connect->real_escape_string($data['upliftment']) : null;
            $upliftmentEnrolledDate = isset($data['upliftmentEnrolledDate']) ? $this->connect->real_escape_string($data['upliftmentEnrolledDate']) : null;
            $upliftmentExitedDate = isset($data['upliftmentExitedDate']) ? $this->connect->real_escape_string($data['upliftmentExitedDate']) : null;
            $microCredit = isset($data['microCredit']) ? $this->connect->real_escape_string($data['microCredit']) : null;
            $institution = isset($data['institution']) ? $this->connect->real_escape_string($data['institution']) : null;
        
            // Prepare the SQL update statement
            $sql = "UPDATE ProgramData_table2 SET 
                        beneficiary = '$beneficiary', 
                        safety = '$safety', 
                        enrolledDate = '$enrolledDate', 
                        exitedDate = '$exitedDate', 
                        upliftment = '$upliftment', 
                        upliftmentEnrolledDate = '$upliftmentEnrolledDate', 
                        upliftmentExitedDate = '$upliftmentExitedDate', 
                        microCredit = '$microCredit', 
                        institution = '$institution',
                        user_pin = '$pin' 
                    WHERE id = '$programDataId'";
        
            // Execute the query
            $query = $this->connect->query($sql);
            return $query;
        }
        
        



        public function getProgramData(){
            $sql = "SELECT * FROM ProgramData_table2 ORDER BY id DESC";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }
        
        public function deleteProgramData($data){
            $programDataId = $data['programDataId'];
            $sql = "DELETE FROM ProgramData_table2 WHERE id = '$programDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }



        // public function getProgramDataByCategories(){
        //     // Prepare the SQL query to get the sum of amounts grouped by item, without needing categories
        //     $sql = "SELECT LOWER(item) as item, SUM(amount) as total_amount 
        //             FROM ProgramData_table 
        //             GROUP BY LOWER(item) 
        //             ORDER BY id DESC";
            
        //     $query = $this->connect->query($sql);
            
        //     if($query->num_rows > 0){
        //         $data = [];
        //         while($row = $query->fetch_assoc()){
        //             array_push($data, $row);
        //         }
        //         return $data;
        //     }else{
        //         return false;
        //     }
        // }
        
        public function getProgramDataByCategories() {
            // Initialize the response array
            $response = [
                'genderData' => [
                    'male' => [
                        'Claimed' => 0,
                        'Unclaimed' => 0
                    ],
                    'female' => [
                        'Claimed' => 0,
                        'Unclaimed' => 0
                    ]
                ],
                'total_donors' => 0,
                'total_users' => 0,
                'items' => [],
                'programData' => [], // To hold program data
                'disbursementData' => [], // To hold disbursement data
                'itemsInStock' => [] // New section to hold item stock data
            ];
        
            // SQL query to get each item, its total quantity, and date for programData
            $programDataSql = "
                SELECT item, SUM(quantity) AS total_quantity, MAX(date) AS date
                FROM ProgramData_table
                GROUP BY item;
            ";
        
            // Execute the program data query
            $programDataQuery = $this->connect->query($programDataSql);
        
            if ($programDataQuery) {
                // Fetch each record for programData
                while ($row = $programDataQuery->fetch_assoc()) {
                    $itemLower = strtolower($row['item']); // Convert item name to lowercase
                    $response['programData'][] = [
                        'item' => $itemLower, // Store the lowercase item name
                        'total_quantity' => $row['total_quantity'],
                        'date' => $row['date'] // Include the date
                    ];
                }
            } else {
                // Handle error for program data query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching program data: ' . $this->connect->error
                ]);
                exit();
            }
        
            // SQL query to get each item, its total quantity, and date for disbursementData
            $disbursementDataSql = "
                SELECT d.status, di.item, SUM(di.quantity) AS total_quantity, MAX(d.date) AS date
                FROM disbursement_table2 d
                INNER JOIN disbursement_items2 di ON d.id = di.disbursement_id
                GROUP BY d.status, di.item;
            ";
        
            // Execute the disbursement data query
            $disbursementDataQuery = $this->connect->query($disbursementDataSql);
        
            if ($disbursementDataQuery) {
                // Fetch each record for disbursementData
                while ($row = $disbursementDataQuery->fetch_assoc()) {
                    $itemLower = strtolower($row['item']); // Convert item name to lowercase
                    $response['disbursementData'][] = [
                        'status' => $row['status'],
                        'item' => $itemLower, // Store the lowercase item name
                        'total_quantity' => $row['total_quantity'],
                        'date' => $row['date'] // Include the date
                    ];
                }
            } else {
                // Handle error for disbursement data query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching disbursement data: ' . $this->connect->error
                ]);
                exit();
            }
        
            // Calculate itemsInStock as programData - disbursementData
            $itemQuantities = [];
        
            // Collect quantities from programData
            foreach ($response['programData'] as $programItem) {
                $itemQuantities[$programItem['item']] = [
                    'program_quantity' => $programItem['total_quantity'],
                    'disbursement_quantity' => 0, // Initialize for disbursement quantity
                    'date' => $programItem['date'] // Include the date
                ];
            }
        
            // Collect quantities from disbursementData
            foreach ($response['disbursementData'] as $disbursementItem) {
                $itemLower = $disbursementItem['item']; // Use the lowercase item name
        
                if (!isset($itemQuantities[$itemLower])) {
                    // If item is not in programData, initialize it
                    $itemQuantities[$itemLower] = [
                        'program_quantity' => 0, // No quantity in programData
                        'disbursement_quantity' => 0, // Initialize with 0
                        'date' => $disbursementItem['date'] // Include the date
                    ];
                }
                // Sum the disbursed quantities
                $itemQuantities[$itemLower]['disbursement_quantity'] += $disbursementItem['total_quantity'];
            }
        
            // Prepare itemsInStock based on the aggregated item quantities
            foreach ($itemQuantities as $itemName => $quantities) {
                // Calculate stock quantity
                $remainingStock = $quantities['program_quantity'] - $quantities['disbursement_quantity'];
                $response['itemsInStock'][] = [
                    'item' => $itemName,
                    'stock_quantity' => $remainingStock,
                    'date' => $quantities['date'] // Include the date for the item
                ];
            }
        
            // Output only the itemsInStock section as JSON
            echo json_encode([
                'status' => 'success',
                'itemsInStock' => $response['itemsInStock']
            ]);
        
            exit();  // Ensure no further output
        }
        
        
        

        //disbursement

        public function saveDisburseData($data) {
            // Sanitize input data
            $receiver = isset($data['receiver']) ? $this->connect->real_escape_string($data['receiver']) : null;
            $pin = isset($data['pin']) ? $this->connect->real_escape_string($data['pin']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
            $status = isset($data['status']) ? $this->connect->real_escape_string($data['status']) : null;
        
            // Extract items and quantities
            $items = isset($data['item']) ? $data['item'] : [];
            $quantities = isset($data['quantity']) ? $data['quantity'] : [];
        
            // Validate that the number of items matches the number of quantities
            if (count($items) !== count($quantities)) {
                echo json_encode(['status' => 'error', 'message' => 'Mismatched items and quantities.']);
                return;
            }
        
            // Begin the transaction
            $this->connect->begin_transaction();
        
            try {
                // Insert into the disbursement_table2
                $sql = "INSERT INTO disbursement_table2 (receiver, user_pin, date, status) VALUES ('$receiver', '$pin', '$date', '$status')";
                $query = $this->connect->query($sql);
        
                if (!$query) {
                    throw new Exception("Error inserting into disbursement_table2: " . $this->connect->error);
                }
        
                // Get the last inserted ID for disbursement
                $disbursementId = $this->connect->insert_id;
        
                // Loop through items and quantities to insert into disbursement_items table
                foreach ($items as $index => $item) {
                    $item = $this->connect->real_escape_string($item);
                    $quantity = $this->connect->real_escape_string($quantities[$index]);
        
                    $sqlItems = "INSERT INTO disbursement_items2 (disbursement_id,user_pin, item, quantity) 
                                 VALUES ('$disbursementId','$pin', '$item', '$quantity')";
                    $queryItems = $this->connect->query($sqlItems);
        
                    if (!$queryItems) {
                        throw new Exception("Error inserting into disbursement_items2: " . $this->connect->error);
                    }
                }
        
                // Commit the transaction
                $this->connect->commit();
        
                // Success response
                echo json_encode(['status' => 'success', 'message' => 'Record saved22!']);
            } catch (Exception $e) {
                // Rollback the transaction if something went wrong
                $this->connect->rollback();
        
                // Return error message
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
        
            exit();
        }

        // public function getDisbursementData() {
        //     // SQL query to retrieve all unique user_pin values from disbursement_table2
        //     $userPinsSql = "SELECT DISTINCT user_pin FROM disbursement_table2";
        //     $userPinsQuery = $this->connect->query($userPinsSql);
        
        //     // Initialize an empty array to hold the response data
        //     $disbursements = [];
        
        //     if ($userPinsQuery) {
        //         // Fetch each unique user_pin
        //         while ($pinRow = $userPinsQuery->fetch_assoc()) {
        //             $user_pin = $pinRow['user_pin'];
        
        //             // Sanitize the user_pin input
        //             $user_pin = $this->connect->real_escape_string($user_pin);
                    
        //             // Check if the user exists in the users table
        //             $checkUserSql = "SELECT * FROM users WHERE user_pin = '$user_pin'";
        //             $userQuery = $this->connect->query($checkUserSql);
                    
        //             if ($userQuery->num_rows > 0) {
        //                 // User exists, now fetch disbursement records for this user_pin
        //                 $sql = "
        //                     SELECT d.id AS disbursement_id, d.receiver, d.user_pin, d.date, d.status, di.item, di.quantity 
        //                     FROM disbursement_table2 d 
        //                     LEFT JOIN disbursement_items2 di ON d.id = di.disbursement_id
        //                     WHERE d.user_pin = '$user_pin' 
        //                 ";
        
        //                 // Execute the query
        //                 $query = $this->connect->query($sql);
                        
        //                 if ($query) {
        //                     // Fetch each record for this user_pin
        //                     while ($row = $query->fetch_assoc()) {
        //                         $disbursementId = $row['disbursement_id'];
        
        //                         // If this disbursement_id doesn't exist in the $disbursements array, create it
        //                         if (!isset($disbursements[$disbursementId])) {
        //                             $disbursements[$disbursementId] = [
        //                                 'disbursement_id' => $disbursementId,
        //                                 'receiver' => $row['receiver'],
        //                                 'user_pin' => $row['user_pin'],
        //                                 'date' => $row['date'],
        //                                 'status' => $row['status'],
        //                                 'items' => []
        //                             ];
        //                         }
        
        //                         // Append item information if it exists
        //                         if (!empty($row['item'])) {
        //                             $disbursements[$disbursementId]['items'][] = [
        //                                 'item' => $row['item'],
        //                                 'quantity' => $row['quantity']
        //                             ];
        //                         }
        //                     }
        //                 }
        //             }
        //         }
        
        //         // Output the data as JSON
        //         echo json_encode([
        //             'status' => 'success',
        //             'data' => array_values($disbursements)  // Reset array keys
        //         ]);
        //     } else {
        //         // Return error message if user_pin query fails
        //         echo json_encode([
        //             'status' => 'error',
        //             'message' => 'Error fetching user pins: ' . $this->connect->error
        //         ]);
        //     }
        
        //     exit();  // Ensure no further output
        // }


        public function getDisbursementData() {
            // SQL query to retrieve all unique user_pin values from disbursement_table2
            $userPinsSql = "SELECT DISTINCT user_pin FROM disbursement_table2";
            $userPinsQuery = $this->connect->query($userPinsSql);
        
            // Initialize an empty array to hold the response data
            $disbursements = [];
        
            if ($userPinsQuery) {
                // Fetch each unique user_pin
                while ($pinRow = $userPinsQuery->fetch_assoc()) {
                    $user_pin = $pinRow['user_pin'];
        
                    // Sanitize the user_pin input
                    $user_pin = $this->connect->real_escape_string($user_pin);
                    
                    // Check if the user exists in the users table
                    $checkUserSql = "SELECT * FROM users WHERE user_pin = '$user_pin'";
                    $userQuery = $this->connect->query($checkUserSql);
                    
                    if ($userQuery->num_rows > 0) {
                        // User exists, now fetch disbursement records and gender for this user_pin
                        $sql = "
                        SELECT 
                            d.id AS disbursement_id, 
                            d.receiver, 
                            d.user_pin, 
                            d.date, 
                            d.status, 
                            di.item, 
                            di.quantity, 
                            b.gender,    -- Retrieve gender from biodata table
                            b.image      -- Retrieve image from biodata table
                        FROM 
                            disbursement_table2 d 
                        LEFT JOIN 
                            disbursement_items2 di ON d.id = di.disbursement_id
                        LEFT JOIN 
                            biodata b ON d.user_pin = b.user_pin  -- Join biodata table using user_pin
                        WHERE 
                            d.user_pin = '$user_pin' 
                        ORDER BY 
                            d.date DESC, d.id DESC
                    ";
                    

        
                        // Execute the query
                        $query = $this->connect->query($sql);
                        
                        if ($query) {
                            // Fetch each record for this user_pin
                            while ($row = $query->fetch_assoc()) {
                                $disbursementId = $row['disbursement_id'];
        
                                // If this disbursement_id doesn't exist in the $disbursements array, create it
                                if (!isset($disbursements[$disbursementId])) {
                                    $disbursements[$disbursementId] = [
                                        'disbursement_id' => $disbursementId,
                                        'receiver' => $row['receiver'],
                                        'user_pin' => $row['user_pin'],
                                        'date' => $row['date'],
                                        'status' => $row['status'],
                                        'gender' => $row['gender'],  // Add gender to the response
                                        'image' => $row['image'],  // Add gender to the response
                                        'items' => []
                                    ];
                                }
        
                                // Append item information if it exists
                                if (!empty($row['item'])) {
                                    $disbursements[$disbursementId]['items'][] = [
                                        'item' => $row['item'],
                                        'quantity' => $row['quantity']
                                    ];
                                }
                            }
                        }
                    }
                }
        
                // Output the data as JSON
                echo json_encode([
                    'status' => 'success',
                    'data' => array_values($disbursements)  // Reset array keys
                ]);
            } else {
                // Return error message if user_pin query fails
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching user pins: ' . $this->connect->error
                ]);
            }
        
            exit();  // Ensure no further output
        }
        
        

        public function updateDisburseData($data) {
            // Sanitize input data
            $disbursementId = isset($data['DisburseDataId']) ? $this->connect->real_escape_string($data['DisburseDataId']) : null;
            $receiver = isset($data['receiver']) ? $this->connect->real_escape_string($data['receiver']) : null;
            $pin = isset($data['pin']) ? $this->connect->real_escape_string($data['pin']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
            $status = isset($data['status']) ? $this->connect->real_escape_string($data['status']) : null;
        
            // Extract items and quantities
            $items = isset($data['item']) ? $data['item'] : [];
            $quantities = isset($data['quantity']) ? $data['quantity'] : [];
        
            // Validate item and quantity count
            if (count($items) !== count($quantities)) {
                echo json_encode(['status' => 'error', 'message' => 'Mismatched items and quantities.']);
                return;
            }
        
            // Begin transaction
            $this->connect->begin_transaction();
        
            try {
                // Update disbursement_table2
                $sql = "UPDATE disbursement_table2 SET receiver='$receiver', user_pin='$pin', date='$date', status='$status' WHERE id='$disbursementId'";
                $query = $this->connect->query($sql);
        
                if (!$query) {
                    throw new Exception("Error updating disbursement_table2: " . $this->connect->error);
                }
        
                // Delete existing disbursement_items
                $sqlDeleteItems = "DELETE FROM disbursement_items2 WHERE disbursement_id='$disbursementId'";
                $queryDeleteItems = $this->connect->query($sqlDeleteItems);
        
                if (!$queryDeleteItems) {
                    throw new Exception("Error deleting existing disbursement_items: " . $this->connect->error);
                }
        
                // Insert new disbursement_items
                foreach ($items as $index => $item) {
                    $item = $this->connect->real_escape_string($item);
                    $quantity = $this->connect->real_escape_string($quantities[$index]);
        
                    $sqlItems = "INSERT INTO disbursement_items2 (disbursement_id, item, quantity) VALUES ('$disbursementId', '$item', '$quantity')";
                    $queryItems = $this->connect->query($sqlItems);
        
                    if (!$queryItems) {
                        throw new Exception("Error inserting into disbursement_items2: " . $this->connect->error);
                    }
                }
        
                // Commit the transaction
                $this->connect->commit();
        
                // Success response
                echo json_encode(['status' => 'success', 'message' => 'Record updated!']);
            } catch (Exception $e) {
                // Rollback the transaction if something went wrong
                $this->connect->rollback();
        
                // Return error message
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
        
            exit();
        }
        

        public function deleteDisburseData($data) {
            // Get the disbursement ID from the data
            $disbursementId = isset($data['DisburseDataId']) ? intval($data['DisburseDataId']) : null;
        
            // First, delete associated items in the disbursement_items table
            $sqlItems = "DELETE FROM disbursement_items2 WHERE disbursement_id = '$disbursementId'";
            $queryItems = $this->connect->query($sqlItems);
        
            // Check if the deletion of items was successful
            if (!$queryItems) {
                return false; // Return false on error
            }
        
            // Next, delete the disbursement record in the disbursements_table
            $sql = "DELETE FROM disbursement_table2 WHERE id = '$disbursementId'";
            $query = $this->connect->query($sql);
        
            // Check if the deletion of the disbursement record was successful
            if ($query) {
                return true; // Return true on success
            } else {
                return false; // Return false on error
            }
        }


        public function getDashboardData() {
            // Initialize the response array
            $response = [
                'genderData' => [
                    'male' => [
                        'Claimed' => 0,
                        'Unclaimed' => 0
                    ],
                    'female' => [
                        'Claimed' => 0,
                        'Unclaimed' => 0
                    ]
                ],
                'total_donors' => 0,
                'total_users' => 0,
                'items' => [],
                'programData' => [], // To hold program data
                'disbursementData' => [], // To hold disbursement data
                'itemsInStock' => [] // New section to hold item stock data
            ];
        
            // 1. SQL query to join biodata and disbursements_table and count genders and status
            $genderSql = "
                SELECT u.gender, d.status, COUNT(DISTINCT d.user_pin) AS total
                FROM biodata u
                INNER JOIN disbursement_table2 d ON u.user_pin = d.user_pin
                GROUP BY u.gender, d.status;

            ";
        
            // Execute the gender query
            $genderQuery = $this->connect->query($genderSql);
        
            if ($genderQuery) {
                // Fetch each row and update the count for each gender and status
                while ($row = $genderQuery->fetch_assoc()) {
                    $gender = strtolower($row['gender']);
                    $status = strtolower($row['status']);
        
                    // Check if gender and status are valid
                    if (isset($response['genderData'][$gender]) && in_array($status, ['claimed', 'unclaimed'])) {
                        $response['genderData'][$gender][ucfirst($status)] = (int)$row['total'];
                    }
                }
            } else {
                // Handle error for gender query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching gender data: ' . $this->connect->error
                ]);
                exit();
            }
        
            // 2. SQL query to count unique donors
            $donorSql = "SELECT COUNT(*) AS total_donors FROM `ProgramData_table`";
        
            // Execute the donor query
            $donorQuery = $this->connect->query($donorSql);
        
            if ($donorQuery) {
                // Fetch the result for total donors
                $result = $donorQuery->fetch_assoc();
                $response['total_donors'] = $result['total_donors'];
            } else {
                // Handle error for donor query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching total donors: ' . $this->connect->error
                ]);
                exit();
            }
        
            // 3. SQL query to get each item, its total quantity, and date for programData
            $programDataSql = "
                SELECT item, SUM(quantity) AS total_quantity, MAX(date) AS date
                FROM ProgramData_table
                GROUP BY item;
            ";
        
            // Execute the program data query
            $programDataQuery = $this->connect->query($programDataSql);
        
            if ($programDataQuery) {
                // Fetch each record for programData
                while ($row = $programDataQuery->fetch_assoc()) {
                    $itemLower = strtolower($row['item']); // Convert item name to lowercase
                    $response['programData'][] = [
                        'item' => $itemLower, // Store the lowercase item name
                        'total_quantity' => $row['total_quantity'],
                        'date' => $row['date'] // Include the date
                    ];
                }
            } else {
                // Handle error for program data query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching program data: ' . $this->connect->error
                ]);
                exit();
            }
        
            // 4. SQL query to get each item, its total quantity, and date for disbursementData
            $disbursementDataSql1 = "
               SELECT d.status, di.item, SUM(di.quantity) AS total_quantity, MAX(d.date) AS date
                FROM disbursement_table2 d
                INNER JOIN disbursement_items2 di ON d.id = di.disbursement_id
                WHERE d.status = 'claimed'
                GROUP BY d.status, di.item;

            ";
            $disbursementDataSql = "
              SELECT d.status, di.item, SUM(di.quantity) AS total_quantity, MAX(d.date) AS date, b.gender
            FROM disbursement_table2 d
            INNER JOIN disbursement_items2 di ON d.id = di.disbursement_id
            INNER JOIN biodata b ON d.user_pin = b.user_pin
            WHERE d.status = 'claimed'
            GROUP BY d.status, di.item, b.gender;
            ";
        
            // Execute the disbursement data query
            $disbursementDataQuery = $this->connect->query($disbursementDataSql);
        
            if ($disbursementDataQuery) {
                // Fetch each record for disbursementData
                while ($row = $disbursementDataQuery->fetch_assoc()) {
                    $itemLower = strtolower($row['item']); // Convert item name to lowercase
                    $response['disbursementData'][] = [
                        'status' => $row['status'],
                        'item' => $itemLower, // Store the lowercase item name
                        'total_quantity' => $row['total_quantity'],
                        'date' => $row['date'] ,// Include the date
                        'gender' => $row['gender']
                    ];
                }
            } else {
                // Handle error for disbursement data query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching disbursement data: ' . $this->connect->error
                ]);
                exit();
            }
        
            // 5. SQL query to count total users
            $AllUsersSql = "SELECT COUNT(*) AS total_users FROM `users`";
        
            // Execute the user query
            $userQuery = $this->connect->query($AllUsersSql);
        
            if ($userQuery) {
                // Fetch the result for total users
                $result = $userQuery->fetch_assoc();
                $response['total_users'] = $result['total_users'];
            } else {
                // Handle error for user query
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching total users: ' . $this->connect->error
                ]);
                exit();
            }
        
            // 6. Calculate itemsInStock as programData - disbursementData
            $itemQuantities = [];
        
            // Collect quantities from programData
            foreach ($response['programData'] as $programItem) {
                $itemQuantities[$programItem['item']] = [
                    'program_quantity' => $programItem['total_quantity'],
                    'disbursement_quantity' => 0, // Initialize for disbursement quantity
                    'date' => $programItem['date'] // Include the date
                ];
            }
        
            // Collect quantities from disbursementData
            foreach ($response['disbursementData'] as $disbursementItem) {
                $itemLower = $disbursementItem['item']; // Use the lowercase item name
        
                if (!isset($itemQuantities[$itemLower])) {
                    // If item is not in programData, initialize it
                    $itemQuantities[$itemLower] = [
                        'program_quantity' => 0, // No quantity in programData
                        'disbursement_quantity' => 0, // Initialize with 0
                        'date' => $disbursementItem['date'] // Include the date
                    ];
                }
                // Sum the disbursed quantities
                $itemQuantities[$itemLower]['disbursement_quantity'] += $disbursementItem['total_quantity'];
            }
        
            // Prepare itemsInStock based on the aggregated item quantities
            foreach ($itemQuantities as $itemName => $quantities) {
                // Calculate stock quantity
                $remainingStock = $quantities['program_quantity'] - $quantities['disbursement_quantity'];
                $response['itemsInStock'][] = [
                    'item' => $itemName,
                    'stock_quantity' => $remainingStock,
                    'date' => $quantities['date'] // Include the date for the item
                ];
            }
        
            // Output the combined data as JSON
            echo json_encode([
                'status' => 'success',
                'data' => $response
            ]);
        
            exit();  // Ensure no further output
        }
        
        


        
        

  
        //BALANCE SHEET data
        public function saveBsheetData($data){

            $name = isset($data['name']) ? $this->connect->real_escape_string($data['name']) : null;

            $item = isset($data['item']) ? $this->connect->real_escape_string($data['item']) : null;

            $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;

            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;


              $sql = "INSERT INTO balancesheet_table (name, item, amount, date) 
            VALUES ('$name', '$item', '$amount', '$date')";

            $query = $this->connect->query($sql);
            return $query;
        }

           
        public function getBsheetData($page , $recordsPerPage) {

            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $recordsPerPage = isset($_GET['recordsPerPage']) ? (int)$_GET['recordsPerPage'] : 10;
            
            // Calculate the offset
            $offset = ($page - 1) * $recordsPerPage;
        
            // Fetch the total number of records
            $sqlCount = "SELECT COUNT(*) AS total FROM balancesheet_table";
            $result = $this->connect->query($sqlCount);
            $totalRecords = $result->fetch_assoc()['total'];
        
            // Calculate total pages
            $totalPages = ceil($totalRecords / $recordsPerPage);
        
            // Fetch the data with LIMIT and OFFSET
            $sql = "SELECT * FROM balancesheet_table ORDER BY id DESC LIMIT $recordsPerPage OFFSET $offset";
            
            // Debug SQL query (optional, for testing)
            error_log($sql);  // Logs the generated SQL query for debugging
            
            $query = $this->connect->query($sql);
        
            if ($query->num_rows > 0) {
                $data = [];
                while ($row = $query->fetch_assoc()) {
                    array_push($data, $row);
                }
                
                // Return data along with pagination info
                return [
                    'data' => $data,
                    'currentPage' => $page,
                    'totalPages' => $totalPages,
                    'totalRecords' => $totalRecords,
                    'recordsPerPage' => $recordsPerPage
                ];
            } else {
                // Return empty data set with pagination info if no data found
                return [
                    'data' => [],
                    'currentPage' => $page,
                    'totalPages' => $totalPages,
                    'totalRecords' => $totalRecords,
                    'recordsPerPage' => $recordsPerPage
                ];
            }
        }
        

        public function updateBsheetData($data){

            $bSheetDataId = isset($data['bSheetDataId']) ? $this->connect->real_escape_string($data['bSheetDataId']) : null;
            $name = isset($data['name']) ? $this->connect->real_escape_string($data['name']) : null;

            $item = isset($data['item']) ? $this->connect->real_escape_string($data['item']) : null;

            $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;

            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;



                     $sql = "UPDATE balancesheet_table SET name = '$name', item= '$item', amount = '$amount', date = '$date' WHERE id = '$bSheetDataId'";
                $query = $this->connect->query($sql);
                if($query){
                    return true;
                }else{
                    return false;
                }
        }
        
        public function deleteBsheetData($data){
            $bSheetDataId = $data['bSheetDataId'];
            $sql = "DELETE FROM balancesheet_table WHERE id = '$bSheetDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

       
        //annual balancesheet.
        // 

        public function getBsheetDataByItem() {
            // SQL query for Asset
            $sqlAsset = "SELECT * FROM balancesheet_table WHERE item LIKE '%Asset%' ORDER BY id DESC";
            // SQL query for Liability
            $sqlLiability = "SELECT * FROM balancesheet_table WHERE item LIKE '%Liability%' ORDER BY id DESC";
        
            // Debug SQL query (optional)
            error_log($sqlAsset);
            error_log($sqlLiability);
        
            // Execute Asset query
            $queryAsset = $this->connect->query($sqlAsset);
            // Execute Liability query
            $queryLiability = $this->connect->query($sqlLiability);
        
            // Initialize data arrays for Asset and Liability
            $data = [
                'assets' => [],
                'liabilities' => []
            ];
        
            // Fetch Asset data
            if ($queryAsset && $queryAsset->num_rows > 0) {
                while ($row = $queryAsset->fetch_assoc()) {
                    $data['assets'][] = $row;
                }
            }
        
            // Fetch Liability data
            if ($queryLiability && $queryLiability->num_rows > 0) {
                while ($row = $queryLiability->fetch_assoc()) {
                    $data['liabilities'][] = $row;
                }
            }
        
            // Return the separated data for Assets and Liabilities
            return $data;
        }
        
        public function getClaimedItemWithGender() {
            // Initialize the response array
            $response = [
                'claimedItems' => []
            ];
        
            // Your SQL query to get the data
            $sql = "
                SELECT 
                    b.gender,
                    di.item,
                    SUM(di.quantity) AS total_quantity,
                    COUNT(DISTINCT d.user_pin) AS total_users
                FROM 
                    disbursement_table2 d
                INNER JOIN 
                    disbursement_items2 di ON d.id = di.disbursement_id
                INNER JOIN 
                    biodata b ON d.user_pin = b.user_pin
                WHERE 
                    d.status = 'claimed'
                GROUP BY 
                    b.gender, di.item
                ORDER BY 
                    di.item, b.gender;
            ";
        
            // Execute the query
            $query = $this->connect->query($sql);
        
            if ($query) {
                while ($row = $query->fetch_assoc()) {
                    $item = $row['item'];
                    $gender = strtolower($row['gender']); // Normalize gender to lowercase
                    
                    // Initialize item structure if it doesn't exist
                    if (!isset($response['claimedItems'][$item])) {
                        $response['claimedItems'][$item] = [
                            'male' => [
                                'total_quantity' => 0,
                                'total_users' => 0
                            ],
                            'female' => [
                                'total_quantity' => 0,
                                'total_users' => 0
                            ]
                        ];
                    }
        
                    // Update the totals for the specific item and gender
                    $response['claimedItems'][$item][$gender]['total_quantity'] += (int)$row['total_quantity'];
                    $response['claimedItems'][$item][$gender]['total_users'] += (int)$row['total_users'];
                }
            } else {
                // Handle error for query execution
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Error fetching claimed item statistics: ' . $this->connect->error
                ]);
                exit();
            }
        
            // Return the structured response
            echo json_encode([
                'status' => 'success',
                'data' => $response
            ]);
            exit();
        }
        


     
    
    // public function getBeneficiaryAnalytics() {
    //     // Initialize the response array
    //     $response = [
    //         'beneficiaries' => []
    //     ];
    
    //     // SQL query to get first name, last name, age, gender, user_pin, and date
    //     $sql = "
    //         SELECT 
    //             b.first_name, 
    //             b.last_name, 
    //             b.age, 
    //             b.gender, 
    //             b.user_pin, 
    //             d.date
    //         FROM 
    //             biodata b
    //         JOIN 
    //             disbursement_table2 d 
    //         ON 
    //             b.user_pin = d.user_pin
    //         WHERE 
    //             d.status = 'claimed'  -- Filter for claimed status
    //         ORDER BY 
    //             d.date;
    //     ";
    
    //     // Execute the query
    //     $query = $this->connect->query($sql);
    
    //     if ($query) {
    //         while ($row = $query->fetch_assoc()) {
    //             $first_name = $row['first_name'];
    //             $last_name = $row['last_name'];
    //             $age = (int)$row['age'];
    //             $gender = $row['gender'];
    //             $user_pin = $row['user_pin'];
    //             $date = $row['date'];
    
    //             // Append the beneficiary details to the response array
    //             $response['beneficiaries'][] = [
    //                 'first_name' => $first_name,
    //                 'last_name' => $last_name,
    //                 'age' => $age,
    //                 'gender' => $gender,
    //                 'user_pin' => $user_pin,
    //                 'date' => $date
    //             ];
    //         }
    //     } else {
    //         // Handle error for query execution
    //         echo json_encode([
    //             'status' => 'error',
    //             'message' => 'Error fetching beneficiary details: ' . $this->connect->error
    //         ]);
    //         exit();
    //     }
    
    //     // Return the structured response
    //     echo json_encode([
    //         'status' => 'success',
    //         'data' => $response
    //     ]);
    //     exit();
    // }

//now merged 
    // public function getViewBeneficiaryData() {
    //     // SQL query to get claimed disbursement data along with biodata, location, and poverty status details
    //     $sql = "
    //         SELECT 
    //             b.user_pin, 
    //             b.first_name, 
    //             b.last_name, 
    //             b.age, 
    //             b.gender, 
    //             b.marital_status, 
    //             b.disability, 
    //             b.economic_activities, 
    //             b.family_support, 
    //             b.image,
    //             l.house_number, 
    //             l.street, 
    //             l.area_community, 
    //             l.city_village, 
    //             l.state,
    //             p.nature_type_of_business, 
    //             p.size_of_business, 
    //             p.location_of_business, 
    //             p.daily_income, 
    //             p.family_marital_status, 
    //             p.family_size_of_business, 
    //             p.number_of_children, 
    //             p.age_of_spouse, 
    //             p.nature_of_occupation_spouse, 
    //             p.own_home, 
    //             p.size_of_dwelling, 
    //             p.main_type_of_meal, 
    //             p.level_of_education, 
    //             p.major_illiness,
    //             di.item, 
    //             di.quantity, 
    //             di.created_at AS disbursement_item_created_at
    //         FROM 
    //             disbursement_table2 AS d
    //         INNER JOIN 
    //             disbursement_items2 AS di ON d.id = di.disbursement_id
    //         INNER JOIN 
    //             biodata AS b ON d.user_pin = b.user_pin
    //         INNER JOIN 
    //             location AS l ON d.user_pin = l.user_pin
    //         INNER JOIN 
    //             poverty_status AS p ON d.user_pin = p.user_pin
    //         WHERE 
    //             d.status = 'claimed';
    //     ";
        
    //     // Execute the query
    //     $result = $this->connect->query($sql);
    
    //     // Check for query execution success
    //     if ($result === false) {
    //         return [
    //             'status' => 'error',
    //             'message' => 'Error fetching claimed disbursement data: ' . $this->connect->error
    //         ];
    //     }
        
    //     // Process the data and group items into a nested array for each user
    //     $data = [];
    //     while ($row = $result->fetch_assoc()) {
    //         $user_pin = $row['user_pin'];
    
    //         // Initialize user data if not already set
    //         if (!isset($data[$user_pin])) {
    //             $data[$user_pin] = [
    //                 "user_pin" => $row['user_pin'],
    //                 "first_name" => $row['first_name'],
    //                 "last_name" => $row['last_name'],
    //                 "age" => $row['age'],
    //                 "gender" => $row['gender'],
    //                 "marital_status" => $row['marital_status'],
    //                 "disability" => $row['disability'],
    //                 "economic_activities" => $row['economic_activities'],
    //                 "family_support" => $row['family_support'],
    //                 "image" => $row['image'],
    //                 "house_number" => $row['house_number'],
    //                 "street" => $row['street'],
    //                 "area_community" => $row['area_community'],
    //                 "city_village" => $row['city_village'],
    //                 "state" => $row['state'],
    //                 "nature_type_of_business" => $row['nature_type_of_business'],
    //                 "size_of_business" => $row['size_of_business'],
    //                 "location_of_business" => $row['location_of_business'],
    //                 "daily_income" => $row['daily_income'],
    //                 "family_marital_status" => $row['family_marital_status'],
    //                 "family_size_of_business" => $row['family_size_of_business'],
    //                 "number_of_children" => $row['number_of_children'],
    //                 "age_of_spouse" => $row['age_of_spouse'],
    //                 "nature_of_occupation_spouse" => $row['nature_of_occupation_spouse'],
    //                 "own_home" => $row['own_home'],
    //                 "size_of_dwelling" => $row['size_of_dwelling'],
    //                 "main_type_of_meal" => $row['main_type_of_meal'],
    //                 "level_of_education" => $row['level_of_education'],
    //                 "major_illiness" => $row['major_illiness'],
    //                 "items" => []  // Initialize items as an empty array
    //             ];
    //         }
            
    //         // Add each item to the items array
    //         $data[$user_pin]['items'][] = [
    //             "item" => $row['item'],
    //             "quantity" => $row['quantity'],
    //             "disbursement_item_created_at" => $row['disbursement_item_created_at']
    //         ];
    //     }
    
    //     // Convert data to a non-associative array
    //     $responseData = array_values($data);
    
    //     // Return the data as JSON response
    //     return [
    //         'status' => 'success',
    //         'data' => $responseData
    //     ];
    // }



   // responsible for the beneficiary domain modal whicj contain charts report
    public function getBeneficiaryDomain() {
        // Initialize the response array
        $response = [
            'claimedItemsByAgeRange' => [],
            'claimedItemsByGender' => [],
            'claimedItemsByMaritalStatus' => [],
            'userLocations' => [] // Add an array for user locations
        ];
    
        // Get month and year from request parameters
        $month = isset($_GET['month']) ? intval($_GET['month']) : null;
        $year = isset($_GET['year']) ? intval($_GET['year']) : null;
    
        // Validate month and year
        if ($month < 1 || $month > 12 || $year < 2000) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid month or year provided.'
            ]);
            exit();
        }
    
        // SQL query to get users with claimed status, their marital status, age, date, gender, and location
        $sql = "
            SELECT 
                b.gender,
                b.age,
                b.marital_status,
                d.date,
                b.user_pin,
                l.house_number,
                l.street,
                l.area_community,
                l.city_village,
                l.state,
                CASE
                    WHEN b.age BETWEEN 1 AND 20 THEN '20 and under years'
                    WHEN b.age BETWEEN 21 AND 40 THEN '21-40'
                    WHEN b.age BETWEEN 41 AND 60 THEN '41-60'
                    WHEN b.age BETWEEN 61 AND 80 THEN '61-80'
                    ELSE '81-above'
                END AS age_range
            FROM 
                disbursement_table2 d
            INNER JOIN 
                biodata b ON d.user_pin = b.user_pin
            INNER JOIN 
                location l ON b.user_pin = l.user_pin 
            WHERE 
                d.status = 'claimed' AND
                MONTH(d.date) = $month AND
                YEAR(d.date) = $year
            ORDER BY 
                age_range, d.date;
        ";
    
        // Execute the query
        $query = $this->connect->query($sql);
    
        if ($query) {
            while ($row = $query->fetch_assoc()) {
                $age_range = $row['age_range'];
                $age = (int)$row['age'];
                $date = $row['date']; // Get the date
                $user_pin = $row['user_pin'];
                $gender = $row['gender'];
                $marital_status = $row['marital_status'];
    
                // Append to claimed items by age range
                if (!isset($response['claimedItemsByAgeRange'][$age_range])) {
                    $response['claimedItemsByAgeRange'][$age_range] = [];
                }
                $response['claimedItemsByAgeRange'][$age_range][] = [
                    'user_pin' => $user_pin,
                    'age' => $age,
                    'date' => $date // Include date here
                ];
    
                // Append to claimed items by gender
                if (!isset($response['claimedItemsByGender'][$gender])) {
                    $response['claimedItemsByGender'][$gender] = [];
                }
                $response['claimedItemsByGender'][$gender][] = [
                    'user_pin' => $user_pin,
                    'age' => $age,
                    'date' => $date // Include date here
                ];
    
                // Append to claimed items by marital status
                if (!isset($response['claimedItemsByMaritalStatus'][$marital_status])) {
                    $response['claimedItemsByMaritalStatus'][$marital_status] = [];
                }
                $response['claimedItemsByMaritalStatus'][$marital_status][] = [
                    'user_pin' => $user_pin,
                    'age' => $age,
                    'date' => $date // Include date here
                ];
    
                // Append user location information with date
                $response['userLocations'][] = [
                    'user_pin' => $user_pin,
                    'house_number' => $row['house_number'],
                    'street' => $row['street'],
                    'area_community' => $row['area_community'],
                    'city_village' => $row['city_village'],
                    'state' => $row['state'],
                    'date' => $date // Include date here
                ];
            }
        } else {
            // Handle error for query execution
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching claimed item statistics: ' . $this->connect->error
            ]);
            exit();
        }
    
        // Return the structured response
        echo json_encode([
            'status' => 'success',
            'data' => $response
        ]);
        exit();
    }

    //for the main screen and the view icon display
    public function getBeneficiaryData() {
        // Initialize the response array with a single section for beneficiaries
        $response = [
            'beneficiaries' => []
        ];
    
        // SQL query to get basic analytics data (first name, last name, age, gender, user_pin, date, and disbursement id)
        $sqlAnalytics = "
            SELECT 
                b.first_name, 
                b.last_name, 
                b.age, 
                b.gender, 
                b.user_pin, 
                d.id AS disbursement_id,  -- Include the disbursement id in the selection
                d.date
            FROM 
                biodata b
            JOIN 
                disbursement_table2 d 
            ON 
                b.user_pin = d.user_pin
            WHERE 
                d.status = 'claimed'
            ORDER BY 
                d.date;
        ";
    
        // Execute the analytics query
        $queryAnalytics = $this->connect->query($sqlAnalytics);
        if ($queryAnalytics) {
            while ($row = $queryAnalytics->fetch_assoc()) {
                $user_pin = $row['user_pin'];
                // Initialize beneficiary data with analytics details
                $beneficiaryData = [
                    'first_name' => $row['first_name'],
                    'last_name' => $row['last_name'],
                    'age' => (int)$row['age'],
                    'gender' => $row['gender'],
                    'user_pin' => $user_pin, // Ensure user_pin is set correctly
                    'disbursement_id' => (int)$row['disbursement_id'], // Include the disbursement id
                    'date' => $row['date'],
                    'details' => [
                        'items' => []  // Initialize items array here
                    ]  
                ];
    
                // Add the beneficiary to the response
                $response['beneficiaries'][$user_pin] = $beneficiaryData;
            }
        } else {
            return [
                'status' => 'error',
                'message' => 'Error fetching beneficiary analytics: ' . $this->connect->error
            ];
        }
    
        // SQL query to get detailed beneficiary data with additional fields
        $sqlDetailed = "
            SELECT 
                b.user_pin, 
                b.first_name, 
                b.last_name, 
                b.age, 
                b.gender, 
                b.marital_status, 
                b.disability, 
                b.economic_activities, 
                b.family_support, 
                b.image,
                l.house_number, 
                l.street, 
                l.area_community, 
                l.city_village, 
                l.state,
                p.nature_type_of_business, 
                p.size_of_business, 
                p.location_of_business, 
                p.daily_income, 
                p.family_marital_status, 
                p.family_size_of_business, 
                p.number_of_children, 
                p.age_of_spouse, 
                p.nature_of_occupation_spouse, 
                p.own_home, 
                p.size_of_dwelling, 
                p.main_type_of_meal, 
                p.level_of_education, 
                p.major_illiness,
                di.item, 
                di.quantity, 
                di.created_at AS disbursement_item_created_at,
                d.id AS disbursement_id  -- Include the disbursement id in the detailed query
            FROM 
                disbursement_table2 AS d
            INNER JOIN 
                disbursement_items2 AS di ON d.id = di.disbursement_id
            INNER JOIN 
                biodata AS b ON d.user_pin = b.user_pin
            INNER JOIN 
                location AS l ON d.user_pin = l.user_pin
            INNER JOIN 
                poverty_status AS p ON d.user_pin = p.user_pin
            WHERE 
                d.status = 'claimed';
        ";
    
        // Execute the detailed query
        $queryDetailed = $this->connect->query($sqlDetailed);
        if ($queryDetailed) {
            while ($row = $queryDetailed->fetch_assoc()) {
                $user_pin = $row['user_pin'];
    
                // Log each row for debugging
                error_log(print_r($row, true)); // Log each row to check the fetched data
    
                // If the beneficiary exists in the response, add detailed data
                if (isset($response['beneficiaries'][$user_pin])) {
                    // Add each item to the items array
                    $response['beneficiaries'][$user_pin]['details']['items'][] = [
                        "item" => $row['item'],
                        "quantity" => $row['quantity'],
                        "disbursement_item_created_at" => $row['disbursement_item_created_at'],
                        "disbursement_id" => (int)$row['disbursement_id']  // Include the disbursement id in items
                    ];
                    
                    // Add other details only if they don't already exist
                    if (empty($response['beneficiaries'][$user_pin]['details']['marital_status'])) {
                        $response['beneficiaries'][$user_pin]['details']['marital_status'] = $row['marital_status'];
                        $response['beneficiaries'][$user_pin]['details']['disability'] = $row['disability'];
                        $response['beneficiaries'][$user_pin]['details']['economic_activities'] = $row['economic_activities'];
                        $response['beneficiaries'][$user_pin]['details']['family_support'] = $row['family_support'];
                        $response['beneficiaries'][$user_pin]['details']['image'] = $row['image'];
                        $response['beneficiaries'][$user_pin]['details']['location'] = [
                            'house_number' => $row['house_number'],
                            'street' => $row['street'],
                            'area_community' => $row['area_community'],
                            'city_village' => $row['city_village'],
                            'state' => $row['state']
                        ];
                        // Add business info only if it’s not already set
                        $response['beneficiaries'][$user_pin]['details']['business_info'] = [
                            'nature_type_of_business' => $row['nature_type_of_business'],
                            'size_of_business' => $row['size_of_business'],
                            'location_of_business' => $row['location_of_business'],
                            'daily_income' => $row['daily_income'],
                            'family_marital_status' => $row['family_marital_status'],
                            'family_size_of_business' => $row['family_size_of_business'],
                            'number_of_children' => $row['number_of_children'],
                            'age_of_spouse' => $row['age_of_spouse'],
                            'nature_of_occupation_spouse' => $row['nature_of_occupation_spouse'],
                            'own_home' => $row['own_home'],
                            'size_of_dwelling' => $row['size_of_dwelling'],
                            'main_type_of_meal' => $row['main_type_of_meal'],
                            'level_of_education' => $row['level_of_education'],
                            'major_illiness' => $row['major_illiness']
                        ];
                    }
                }
            }
        } else {
            return [
                'status' => 'error',
                'message' => 'Error fetching detailed beneficiary data: ' . $this->connect->error
            ];
        }
    
        // Convert beneficiaries array to a non-associative array
        $response['beneficiaries'] = array_values($response['beneficiaries']);
    
        // Log the final response structure
        error_log(print_r($response, true)); // Log the final response for debugging
    
        // Return the combined response in JSON format
        return [
            'status' => 'success',
            'data' => $response
        ];
    }
    
    


    
    
     //materials   
    public function getMaterialAnalytics() {
        // Initialize the response array
        $response = [
            'material_data' => []
        ];
    
        // SQL query to get donor, item, quantity, amount, and date
        $sql = "
            SELECT 
                donor, 
                item, 
                quantity, 
                amount, 
                date
            FROM 
                ProgramData_table
            WHERE 
                1;
        ";
    
        // Execute the query
        $query = $this->connect->query($sql);
    
        if ($query) {
            while ($row = $query->fetch_assoc()) {
                $donor = $row['donor'];
                $item = $row['item'];
                $quantity = (int)$row['quantity'];
                $amount = (float)$row['amount'];
                $date = $row['date'];
    
                // Append the program data details to the response array
                $response['material_data'][] = [
                    'donor' => $donor,
                    'item' => $item,
                    'quantity' => $quantity,
                    'amount' => $amount,
                    'date' => $date
                ];
            }
        } else {
            // Handle error for query execution
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching program data: ' . $this->connect->error
            ]);
            exit();
        }
    
        // Return the structured response
        echo json_encode([
            'status' => 'success',
            'data' => $response
        ]);
        exit();
    }
    
    public function getMaterialDomain($startDate = null, $endDate = null) {
        // Initialize the response array for programData, disbursementData, itemsInStock, materialDomain, and donorData
        $response = [
            'programData' => [],
            'disbursementData' => [],
            'itemsInStock' => [],
            'materialDomain' => [],
            'donorData' => [
                'Ehi' => [],
                'Unknown' => []
            ]
        ];
    
        // 1. SQL query to get each item, its total quantity, and date for programData
        $programDataSql = "
            SELECT item, SUM(quantity) AS total_quantity, MAX(date) AS date
            FROM ProgramData_table
            " . ($startDate && $endDate ? "WHERE date BETWEEN '$startDate' AND '$endDate' " : "") . "
            GROUP BY item;
        ";
    
        // Execute the program data query
        $programDataQuery = $this->connect->query($programDataSql);
    
        if ($programDataQuery) {
            // Fetch each record for programData
            while ($row = $programDataQuery->fetch_assoc()) {
                $itemLower = strtolower($row['item']); // Convert item name to lowercase
                $response['programData'][] = [
                    'item' => $itemLower, // Store the lowercase item name
                    'total_quantity' => $row['total_quantity'],
                    'date' => $row['date'] // Include the date
                ];
            }
        } else {
            // Handle error for program data query
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching program data: ' . $this->connect->error
            ]);
            exit();
        }
    
        // 2. SQL query to get each item, its total quantity, and date for disbursementData
        $disbursementDataSql = "
            SELECT d.status, di.item, SUM(di.quantity) AS total_quantity, MAX(d.date) AS date, b.gender
            FROM disbursement_table2 d
            INNER JOIN disbursement_items2 di ON d.id = di.disbursement_id
            INNER JOIN biodata b ON d.user_pin = b.user_pin
            WHERE d.status = 'claimed' " . ($startDate && $endDate ? "AND d.date BETWEEN '$startDate' AND '$endDate' " : "") . "
            GROUP BY d.status, di.item, b.gender;
        ";
    
        // Execute the disbursement data query
        $disbursementDataQuery = $this->connect->query($disbursementDataSql);
    
        if ($disbursementDataQuery) {
            // Fetch each record for disbursementData
            while ($row = $disbursementDataQuery->fetch_assoc()) {
                $itemLower = strtolower($row['item']); // Convert item name to lowercase
                $response['disbursementData'][] = [
                    'status' => $row['status'],
                    'item' => $itemLower, // Store the lowercase item name
                    'total_quantity' => $row['total_quantity'],
                    'date' => $row['date'], // Include the date
                    'gender' => $row['gender']
                ];
            }
        } else {
            // Handle error for disbursement data query
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching disbursement data: ' . $this->connect->error
            ]);
            exit();
        }
    
        // 3. Calculate itemsInStock as programData - disbursementData
        $itemQuantities = [];
    
        // Collect quantities from programData
        foreach ($response['programData'] as $programItem) {
            $itemQuantities[$programItem['item']] = [
                'program_quantity' => $programItem['total_quantity'],
                'disbursement_quantity' => 0, // Initialize for disbursement quantity
                'date' => $programItem['date'] // Include the date
            ];
        }
    
        // Collect quantities from disbursementData
        foreach ($response['disbursementData'] as $disbursementItem) {
            $itemLower = $disbursementItem['item']; // Use the lowercase item name
    
            if (!isset($itemQuantities[$itemLower])) {
                // If item is not in programData, initialize it
                $itemQuantities[$itemLower] = [
                    'program_quantity' => 0, // No quantity in programData
                    'disbursement_quantity' => 0, // Initialize with 0
                    'date' => $disbursementItem['date'] // Include the date
                ];
            }
            // Sum the disbursed quantities
            $itemQuantities[$itemLower]['disbursement_quantity'] += $disbursementItem['total_quantity'];
        }
    
        // Prepare itemsInStock based on the aggregated item quantities
        foreach ($itemQuantities as $itemName => $quantities) {
            // Calculate stock quantity
            $remainingStock = $quantities['program_quantity'] - $quantities['disbursement_quantity'];
            $remainingStock = max($remainingStock, 0); // Prevent negative stock
    
            $response['itemsInStock'][] = [
                'item' => $itemName,
                'stock_quantity' => $remainingStock,
                'date' => $quantities['date'] // Include the date for the item
            ];
        }
    
        // 4. SQL query to fetch item, quantity, and date from ProgramData_table for materialDomain
        $materialDomainSql = "
            SELECT 
                item, 
                quantity, 
                date 
            FROM 
                ProgramData_table
            " . ($startDate && $endDate ? "WHERE date BETWEEN '$startDate' AND '$endDate' " : "") . ";
        ";
    
        // Execute the query for material domain
        $materialDomainQuery = $this->connect->query($materialDomainSql);
    
        if ($materialDomainQuery) {
            // Fetch all results for material domain
            while ($row = $materialDomainQuery->fetch_assoc()) {
                $item = $row['item'];
    
                // Check if the item already exists in the materialDomain array
                if (!isset($response['materialDomain'][$item])) {
                    $response['materialDomain'][$item] = [];
                }
    
                // Add the quantity and date for the current item
                $response['materialDomain'][$item][] = [
                    'quantity' => $row['quantity'],
                    'date' => $row['date']
                ];
            }
        } else {
            // Handle any errors during material domain query execution
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching material domain data: ' . $this->connect->error
            ]);
            exit();
        }
    
        // 5. SQL query to structure donor data into Ehi and Unknown groups
        $donorDataSql = "
            SELECT 
                CASE 
                    WHEN `donor` LIKE '%Ehi%' THEN 'Ehi'
                    ELSE 'Unknown'
                END AS donor_group, 
                SUM(`amount`) AS total_amount, 
                `date`
            FROM `ProgramData_table` 
            WHERE `item` = 'cash'
            " . ($startDate && $endDate ? "AND date BETWEEN '$startDate' AND '$endDate' " : "") . "
            GROUP BY donor_group, `date`;
        ";
    
        // Execute the donor data query
        $donorDataQuery = $this->connect->query($donorDataSql);
    
        if ($donorDataQuery) {
            // Fetch each record for donorData
            while ($row = $donorDataQuery->fetch_assoc()) {
                $donorGroup = $row['donor_group']; // Get the donor group
    
                // Add the donation amount and date to the corresponding group
                $response['donorData'][$donorGroup][] = [
                    'total_amount' => $row['total_amount'],
                    'date' => $row['date']
                ];
            }
        } else {
            // Handle error for donor data query
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching donor data: ' . $this->connect->error
            ]);
            exit();
        }
    
        // Return the structured response in JSON format
        echo json_encode([
            'status' => 'success',
            'data' => $response // Wrap response in 'data' key
        ]);
    
        // Ensure the script exits after output
        exit();
    }
    

   
    
    public function getSegregation() {
        // Get filter parameters if they exist
        $genderFilter = isset($_GET['gender']) ? $this->connect->real_escape_string($_GET['gender']) : '';
        $itemFilter = isset($_GET['item']) ? $this->connect->real_escape_string($_GET['item']) : '';
    
        // SQL query to retrieve all unique user_pin values from disbursement_table2
        $userPinsSql = "SELECT DISTINCT user_pin FROM disbursement_table2";
        $userPinsQuery = $this->connect->query($userPinsSql);
    
        // Initialize an empty array to hold the response data
        $disbursements = [];
    
        if ($userPinsQuery) {
            // Fetch each unique user_pin
            while ($pinRow = $userPinsQuery->fetch_assoc()) {
                $user_pin = $pinRow['user_pin'];
    
                // Sanitize the user_pin input
                $user_pin = $this->connect->real_escape_string($user_pin);
    
                // Check if the user exists in the users table
                $checkUserSql = "SELECT * FROM users WHERE user_pin = '$user_pin'";
                $userQuery = $this->connect->query($checkUserSql);
    
                if ($userQuery->num_rows > 0) {
                    // User exists, now fetch disbursement records and gender for this user_pin
                    $sql = "
                        SELECT 
                            d.id AS disbursement_id, 
                            d.receiver, 
                            d.user_pin, 
                            d.date, 
                            d.status, 
                            di.item, 
                            di.quantity, 
                            b.gender  
                        FROM 
                            disbursement_table2 d 
                        LEFT JOIN 
                            disbursement_items2 di ON d.id = di.disbursement_id
                        LEFT JOIN 
                            biodata b ON d.user_pin = b.user_pin  
                        WHERE 
                            d.user_pin = '$user_pin'
                    ";
    
                    // Apply filters if they are set
                    if (!empty($genderFilter)) {
                        $sql .= " AND b.gender = '$genderFilter'";
                    }
                    if (!empty($itemFilter)) {
                        $sql .= " AND di.item = '$itemFilter'";
                    }
    
                    // Execute the query
                    $query = $this->connect->query($sql);
    
                    if ($query) {
                        // Fetch each record for this user_pin
                        while ($row = $query->fetch_assoc()) {
                            $disbursementId = $row['disbursement_id'];
    
                            // If this disbursement_id doesn't exist in the $disbursements array, create it
                            if (!isset($disbursements[$disbursementId])) {
                                $disbursements[$disbursementId] = [
                                    'disbursement_id' => $disbursementId,
                                    'receiver' => $row['receiver'],
                                    'user_pin' => $row['user_pin'],
                                    'date' => $row['date'],
                                    'status' => $row['status'],
                                    'gender' => $row['gender'], 
                                    'items' => []
                                ];
                            }
    
                            // Append item information if it exists
                            if (!empty($row['item'])) {
                                $disbursements[$disbursementId]['items'][] = [
                                    'item' => $row['item'],
                                    'quantity' => $row['quantity']
                                ];
                            }
                        }
                    }
                }
            }
    
            // Output the filtered data as JSON
            echo json_encode([
                'status' => 'success',
                'data' => array_values($disbursements) 
            ]);
        } else {
            // Return error message if user_pin query fails
            echo json_encode([
                'status' => 'error',
                'message' => 'Error fetching user pins: ' . $this->connect->error
            ]);
        }
    
        exit(); 
    }
    
    // public function getArchive() {
    //     // Initialize the response array
    //     $response = [
    //         'archive_data' => []
    //     ];
    
    //     // SQL query to get user_pin, first_name, last_name, gender, image, and date
    //     $sql = "
    //         SELECT 
    //             b.user_pin, 
    //             b.first_name, 
    //             b.last_name, 
    //             b.gender, 
    //             b.image, 
    //             d.date
    //         FROM 
    //             biodata b
    //         JOIN 
    //             disbursement_table2 d ON b.user_pin = d.user_pin
    //         WHERE 
    //             d.status = 'CLAIMED';
    //     ";
    
    //     // Execute the query
    //     $query = $this->connect->query($sql);
    
    //     if ($query) {
    //         while ($row = $query->fetch_assoc()) {
    //             $user_pin = $row['user_pin'];
    //             $first_name = $row['first_name'];
    //             $last_name = $row['last_name'];
    //             $gender = $row['gender'];
    //             $image = $row['image'];
    //             $date = $row['date'];
    
    //             // Append the archive data details to the response array
    //             $response['archive_data'][] = [
    //                 'user_pin' => $user_pin,
    //                 'first_name' => $first_name,
    //                 'last_name' => $last_name,
    //                 'gender' => $gender,
    //                 'image' => $image,
    //                 'date' => $date
    //             ];
    //         }
    //     } else {
    //         // Handle error for query execution
    //         echo json_encode([
    //             'status' => 'error',
    //             'message' => 'Error fetching archive data: ' . $this->connect->error
    //         ]);
    //         exit();
    //     }
    
    //     // Return the structured response
    //     echo json_encode([
    //         'status' => 'success',
    //         'data' => $response
    //     ]);
    //     exit();
    // }
    
   
    public function deleteArchiveData($data){
        
        $archiveDataId = isset($data['archiveDataId']) ? $this->connect->real_escape_string($data['archiveDataId']) : null;

        $sql = "DELETE FROM archive WHERE id = '$archiveDataId'";
        $query = $this->connect->query($sql);
        if($query){
            return true;
        }else{
            return false;
        }
    }

    public function getArchive(){
        $sql = "SELECT * FROM archive";
        $query = $this->connect->query($sql);
        if($query->num_rows > 0){
            $data = [];
            while($row = $query->fetch_assoc()){
                array_push($data, $row);
            }
            return $data;
        }else{
            return false;
        }
    }


    public function deleteSelectedArchiveData() {
        // Check if the key 'archiveDataIds' exists in the data array
        if (!isset($_POST['archiveDataIds'])) {
            echo json_encode(['error' => 'archiveDataIds key not found']);
            return; // Ensure we exit after the response
        }
    
        // Decode the JSON string into an array of archiveDataIds
        $archiveDataIds = json_decode($_POST['archiveDataIds'], true);
        
        if (empty($archiveDataIds)) {
            echo json_encode(['error' => 'archiveDataIds is empty or invalid']);
            return; // Exit after the response
        }
    
        // Sanitize and prepare the IDs for the SQL query
        $archiveDataIds = array_map('intval', $archiveDataIds);
        
        // Construct the SQL query to delete multiple records
        $idsString = implode(',', $archiveDataIds);
        $sql = "DELETE FROM archive WHERE id IN ($idsString)";
        $query = $this->connect->query($sql);
    
        if ($query) {
            return true; // Exit after the successful response
        } else {
            
            return false; // Exit after the error response
        }
    }
    



   
    
    

    

   
}

?>