<?php
// This file is specially created for cron job event scheduler.

// Define the path to the config folder
define('CONFIG_PATH', __DIR__ . '/config/');

// Include the database configuration file
include CONFIG_PATH . 'admin.php'; // Adjust the filename if necessary
include CONFIG_PATH . 'database.php'; // Adjust the filename if necessary

// Include the request.php file
include 'request.php';

// Function to move users to the archive
function moveUsersToArchive() {
    global $connect; // Make sure $connect is accessible here

    // SQL to select users with claimed status and no transactions in the last hour
    $sql = "
        INSERT INTO archive (user_pin, first_name, last_name, gender, image, date, claimed_status)
        SELECT bd.user_pin, bd.first_name, bd.last_name, bd.gender, bd.image, dt.date, dt.status
        FROM biodata bd
        JOIN disbursement_table2 dt ON bd.user_pin = dt.user_pin
        WHERE dt.status = 'CLAIMED'
        AND dt.date < NOW() - INTERVAL 1 WEEK
    ";

    if ($connect->query($sql) === TRUE) {
        echo "Users moved to archive successfully.\n";
    } else {
        echo "Error moving users to archive: " . $connect->error . "\n";
    }
}

// Move users to the archive
moveUsersToArchive();
?>


