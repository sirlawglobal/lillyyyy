<?php

error_reporting(E_ALL);           
ini_set('display_errors', 1);   

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    header("Access-Control-Allow-Headers: X-Requested-With");

    include('./config/database.php');

    $db = new Database();

    if(isset($_GET['function'])){
        $function = $_GET['function'];

        if($function == "admin-login"){
            //login as an admin
            $user = $db->adminLogin($_POST['email'], $_POST['password']);
            if($user){
                echo json_encode(['user'=>$user]);
            }else{
                echo json_encode(['error'=>'Wrong username or password']);
            }
        }
   // UserData

        if($function == "save-pin"){
            $save = $db->savePin($_POST);
            if($save){
                echo json_encode(['success'=>"Pin saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "get-pin"){
            $pin = $db->getPin();
            if($pin){
                echo json_encode(['pin'=>$pin]);
            }else{
                echo json_encode(['error'=>"No record found!"]);
            }
        }

        if($function == "save-biodata"){
            $save = $db->saveBiodata($_POST);
            if($save){
                echo json_encode(['success'=>"Biodata saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == 'update-biodata'){
            $save = $db->updateBiodata($_POST, $_FILES);
            if($save){
                echo json_encode(['success'=>"Biodata updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "save-location"){
            $save = $db->saveLocation($_POST);
            if($save){
                echo json_encode(['success'=>"Location saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == 'update-location'){
            $save = $db->updateLocation($_POST);
            if($save){
                echo json_encode(['success'=>"Location updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }



        

        if($function == "save-povertystatus"){
            $save = $db->savePovertyStatus($_POST);
            if($save){
                echo json_encode(['success'=>"Poverty Status saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == 'update-poverty-status'){
            $save = $db->updatePovertyStatus($_POST);
            if($save){
                echo json_encode(['success'=>"Poverty Status updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == "save-id"){
            $save = $db->saveId($_POST);
            if($save){
                echo json_encode(['success'=>"Id saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'update-id'){
            $save = $db->updateId($_POST);
            if($save){
                echo json_encode(['success'=>"Id Status updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "get-all-userdata"){
            $userdata = $db->getAllUserData();
            if($userdata){
                echo json_encode(['userdata'=>$userdata]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "get-specific-userdata"){
            $userdata = $db->getSpecificUserData($_POST);
            if($userdata){
                echo json_encode(['userdata'=>$userdata]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }
        if($function == 'delete-userdata'){
            $save = $db->deleteUserdata($_POST);
            if($save){
                echo json_encode(['success'=>"Data Deleted successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to update data"]);
            }
        }

        // Receipt
        if($function == "save-receipt"){
            $save = $db->saveReceipt($_POST);
            if($save){
                echo json_encode(['success'=>"Receipt saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "get-receipt"){
            $receipt = $db->getReceipt();
            if($receipt){
                echo json_encode(['receipt'=>$receipt]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == 'update-receipt'){
            $save = $db->updateReceipt($_POST);
            if($save){
                echo json_encode(['success'=>"Receipt Updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == 'delete-receipt'){
            $save = $db->deleteReceipt($_POST);
            if($save){
                echo json_encode(['success'=>"Data Deleted successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to update data"]);
            }
        }

        // Payment

        if($function == "save-payment"){
            $save = $db->savePayment($_POST);
            if($save){
                echo json_encode(['success'=>"Payment saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "get-payment"){
            $payment = $db->getPayment();
            if($payment){
                echo json_encode(['payment'=>$payment]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == 'update-payment'){
            $save = $db->updatePayment($_POST);
            if($save){
                echo json_encode(['success'=>"Payment Updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == 'delete-payment'){
            $save = $db->deletePayment($_POST);
            if($save){
                echo json_encode(['success'=>"Data Deleted successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to update data"]);
            }
        }

        // DONOR
        // if($function == "save-donor"){
        //     $save = $db->saveDonor($_POST);
        //     if($save){
        //         echo json_encode(['success'=>"Donor saved!"]);
        //     }else{
        //         echo json_encode(['error'=>'An error occured!']);
        //     }
        // }



        // if($function == 'update-donor'){
        //     $save = $db->updateDonor($_POST);
        //     if($save){
        //         echo json_encode(['success'=>"Donor Updated!"]);
        //     }else{
        //         echo json_encode(['error'=>'An error occured!']);
        //     }
        // }

        // if($function == 'delete-donor'){
        //     $save = $db->deleteDonor($_POST);
        //     if($save){
        //         echo json_encode(['success'=>"Data Deleted successfully!"]);
        //     }else{ 
        //         echo json_encode(['error'=>"Failed to update data"]);
        //     }
        // }
       
        




//programData
//programData
        if($function == "save-donor"){
            $programData = $db->saveDonor($_POST,$_FILES);
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in saving']);
            }
        }

        if($function == "get-donor"){
            $donor = $db->getDonor();
            if($donor){
                echo json_encode(['donor'=>$donor]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "update-donor"){
            $programData = $db->updateDonor($_POST,$_FILES);
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == 'delete-donor'){
            $save = $db->deleteDonor($_POST);
            if($save){
                echo json_encode(['success'=>"Data Deleted successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to update data"]);
            }
        }

        if($function == 'update-stock'){
            $save = $db->updateStock($_POST);
            if($save){
                echo json_encode(['success'=>"Data added successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to update data"]);
            }
        }

        if ($function == 'get-items-in-stock') {
            $response = $db->getItemsInStock();
        }
        



        if($function == "save-ProgramData"){
            $programData = $db->saveProgramData($_POST,$_FILES);
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in saving']);
            }
        }


        if($function == "get-ProgramData"){
            $programData = $db->getProgramData();
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "update-ProgramData"){
            $programData = $db->updateProgramData($_POST);
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }




       

        if($function == 'delete-ProgramData'){
            $delete = $db->deleteProgramData($_POST);
            if($delete){
                echo json_encode(['success'=>"Contact deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "get-ProgramDataByCat"){
            $programData = $db->getProgramDataByCategories();
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }
        
        if($function == "get-dashboardData"){
            $donorData = $db->getDashboardData();
            if($donorData){
                echo json_encode(['donorData'=>$donorData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        // if($function == "get-overallItem"){
        //     $ItemsAndQuantity = $db->getItemsWithQuantities();
        //     if($ItemsAndQuantity){
        //         echo json_encode(['ItemsAndQuantity'=>$ItemsAndQuantity]);
        //     }else{
        //         echo json_encode(['error'=>'error in fetching']);
        //     }
        // }




//disbursement
        if($function == "save-disburseData"){
            $disburseData = $db->saveDisburseData($_POST);
            if($disburseData){
                echo json_encode(['disburseData'=>$_POST]);
            }else{
                echo json_encode(['error'=>'error in saving']);
            }
        }

        if($function == "get-disburseData"){
            $disburseData = $db->getDisbursementData();
            if($disburseData){
                echo json_encode(['disburseData'=>$disburseData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        // if($function == "get-genderData"){
        //     $genderData = $db->getgenderData();
        //     if($genderData){
        //         echo json_encode(['genderData'=>$genderData]);
        //     }else{
        //         echo json_encode(['error'=>'error in fetching']);
        //     }
        // }

        if($function == "update-disburseData"){
            // echo json_encode(['disburseData'=>$_POST]);

            $disburseData = $db->updateDisburseData($_POST);
            if($disburseData){
                echo json_encode(['disburseData'=>$disburseData,$_POST]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }
        
        if($function == 'delete-DisbursementData'){
            $delete = $db->deleteDisburseData($_POST);
            if($delete){
                echo json_encode(['success'=>"Contact deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

// balancesheet

        if($function == "save-bSheetData"){
            $BsheetData = $db->saveBsheetData($_POST);
            if($BsheetData){
                echo json_encode(['BsheetData'=>$BsheetData]);
            }else{
                echo json_encode(['error'=>'error in saving']);
            }
        }
        if($function == "update-bSheetData"){
            $BsheetData = $db->updateBsheetData($_POST);
            if($BsheetData){
                echo json_encode(['BsheetData'=>$BsheetData]);
            }else{
                echo json_encode(['error'=>'error in saving']);
            }
        }

        if($function == "get-bSheetData"){
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $recordsPerPage = isset($_GET['recordsPerPage']) ? (int)$_GET['recordsPerPage'] : 10;
            $bSheetData = $db->getBsheetData($page , $recordsPerPage);
            if($bSheetData){
                echo json_encode(['bSheetData'=>$bSheetData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }


        
        if($function == 'delete-bSheetData'){
            $delete = $db->deleteBsheetData($_POST);
            if($delete){
                echo json_encode(['success'=>"Contact deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        if($function == "get-bSheetDataAnnual"){
            
            $bSheetData = $db->getBsheetDataByItem();
            if($bSheetData){
                echo json_encode(['bSheetData'=>$bSheetData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "get-ItemsWithGender"){
            
            $bSheetData = $db->getClaimedItemWithGender();
            if($bSheetData){
                echo json_encode(['bSheetData'=>$bSheetData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        // responsible for the beneficiary domain modal whicj contain charts report
        if($function == "get-BeneficiaryDomain"){
            
            $bSheetData = $db->getBeneficiaryDomain();
            if($bSheetData){
                echo json_encode(['bSheetData'=>$bSheetData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }


        if($function == "get-ViewBeneficiaryData"){
            
            $beneficiaryData = $db->getViewBeneficiaryData();
            if($beneficiaryData){
                echo json_encode(['beneficiaryData'=>$beneficiaryData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "get-materialDomain"){
            
            $bSheetData = $db->getMaterialDomain();
            if($bSheetData){
                echo json_encode(['bSheetData'=>$bSheetData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }


        // responsible for the beneficiary domain main screen and view icon modal
        if($function == "get-BeneficiaryAnalytics"){
            
            $beneficiaryData = $db->getBeneficiaryData();
            if($beneficiaryData){
                echo json_encode(['beneficiaryData'=>$beneficiaryData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "get-MaterialAnalytics"){
            
            $materialData = $db->getMaterialAnalytics();
            if($materialData){
                echo json_encode(['materialData'=>$materialData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }
       

        if($function == "get-Segregation"){
            $disburseData = $db->getSegregation();
            if($disburseData){
                echo json_encode(['disburseData'=>$disburseData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == "get-Archive"){
            $archiveData = $db->getArchive();
            if($archiveData){
                echo json_encode(['archiveData'=>$archiveData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }
        if($function == "delete-Archive"){
            // echo json_encode(['archiveData'=>$_POST]);

            $archiveData = $db->deleteArchiveData($_POST);
            if($archiveData){
                echo json_encode(['archiveData'=>$archiveData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }


        if($function == "delete-SelectedArchive"){
            $archiveData = $db->deleteSelectedArchiveData($_POST);
            if($archiveData){
                echo json_encode(['archiveData'=>$archiveData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }








        
    }

   

?>