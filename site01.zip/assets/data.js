const serverUrl = 'http://ehicentre.org.ng/';




let chosen_file = null;
function onFileSelect(event){
    chosen_file = event.target.files[0];
    var url = URL.createObjectURL(chosen_file);
    var imageContent = `<img src="${url}" class="preview-image" />`;
    var previewContainer = document.getElementById('preview');
    previewContainer.innerHTML = imageContent;
}

function addUserData(newData){
    var modals = document.querySelector('.modals');
    const data = newData || 0;
    
    var modalContent = `
    

    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3 class="test-user">User Data</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <div class="userdata-options-container">
                    <div class="userdata-options">
                        ${data?.user_pin ?
                            `<img id="userdata-option-1" class="userdata-image" src="${serverUrl}/assets/images/green-mark.png" alt="" /> `:
                            `<img id="userdata-option-1" class="userdata-image" src="${serverUrl}/assets/images/ash-mark.png" alt="" />`
                         }
                       
                        <h3 onclick="changeUserDataContent('pinContent')" class="userdata-option-text green-border-bottom" id="userdata-option-text-pin" >Pin</h3>
                    </div>
                    <div class="userdata-options">
                       
                            <img id="userdata-option-biodata" class="userdata-image" src="${serverUrl}/assets/images/ash-mark.png" alt="" /> 

                        <h3 onclick="changeUserDataContent('biodataContent')" class="userdata-option-text" id="userdata-option-text-biodata" >Biodata</h3>
                    </div>
                    <div class="userdata-options">
                            <img id="userdata-option-location" class="userdata-image" src="${serverUrl}/assets/images/ash-mark.png" alt="" />

                        <h3 onclick="changeUserDataContent('locationContent')" class="userdata-option-text" id="userdata-option-text-location" >Location</h3>

                    </div>
                    <div class="userdata-options">
                        <img id="userdata-option-poverty-status" class="userdata-image" src="${serverUrl}/assets/images/ash-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent('povertyStatusContent')" class="userdata-option-text" id="userdata-option-text-poverty_status" >Poverty Status</h3>
                    </div>
                    <div class="userdata-options">
                        <img id="userdata-option-id" class="userdata-image" src="${serverUrl}/assets/images/ash-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent('idContent')" class="userdata-option-text" id="userdata-option-text-id" >ID</h3>
                    </div>
                </div>
                <hr class="hr">
               <div id="user-data-content-container" class="user-data-content-container">
                    <div  id="user-data-content-container-pin">
                        <div class="content-header-container">
                            <h4 id="content-header" class="content-header">Generate Your Pin</h4>
                        </div>
                        <div class="generate-pin-container">
                            <p class="generate-text">Click the button below to generate your pin</p>
                    
                                <form id="form" class="generate-form">
                                    <div class="form_element">
                                        <label for="Donor">Pin</label>
                                        <input value='${data?.user_pin ?? ''}' class="modal-input" type="text" id="generated-pin" readonly/>
                                    </div>
                                <div class="modal-button-container">
                                    <button type="button" class="generate-button" onclick="generatePin()"       id="generate-btn">Generate</  button>  
                                </div>
                            
                            </form>

                        </div>
                    </div>
                    <div class="no-display-userdata " id="user-data-content-container-biodata">
                        <div class="content-header-container">
                            <h4 id="content-header" class="content-header">BioData</h4>
                        </div>
                        <div class="generate-pin-container">
                                <form id="form" class="biodata-form">
                                    <div class="three-forms">
                                        <div class="form_element">
                                            <label onclick="saveBiodata()" class="form-label" for="first_name">First Name</label>
                                            <input value='${data?.first_name ?? ''}' class="modal-input" type="text" id="first_name" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="last_name">Last Name</label>
                                            <input value='${data?.last_name ?? ''}' class="modal-input" type="text" id="last_name" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="age">Age</label>
                                            <input value='${data?.age ?? ''}' class="modal-input" type="number" id="age" />
                                        </div>
                                    </div>
                                    <div class="three-forms">
                                        <div class="form_element">
                                            <label class="form-label" for="gender">Gender</label>
                                            
                                            <select value='${data?.gender  ?? ''}' class="modal-input" id="gender">
                                                <option value="${data?.gender  ?? ''}">${data?.gender  ?? 'Choose a gender'}</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="marital_status">Marital Status</label>
                                                <select value='${data?.marital_status ?? ''}' class="modal-input"  id="marital_status">
                                                <option value="${data?.marital_status ?? ''}">${data?.marital_status ?? 'Choose a Marital Status'}</option>
                                                <option value="Single">Single</option>
                                                <option value="Married">Married</option>
                                                <option value="Widowed">Widowed</option>
                                                <option value="Divorced">Divorced</option>
                                                <option value="Separated">Separated</option>
                                            </select>
                                        </div>
                                         <div class="form_element">
                                            <label class="form-label" for="age">Picture</label>
                                            <input onchange="onFileSelect(event)" class="modal-input" type="file" id="age" />
                                        </div>
                                    

                                    </div>

                                    <div class="indicator margin-top">
                                        
                                        <img src="../assets/images/indicator-image.png" alt="" class="indicator-image">
                                    </div>

                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="disability">Disability</label>
                                            
                                                <select value='${data?.disability ?? ''}' class="modal-input" id="disability">
                                                    <option value="${data?.disability ?? ''}">${data?.disability ?? 'Are you disabled?'}</option>
                                                    <option value="No Disability">No Disability</option>
                                                    <option value="Mild Disability">Mild Disability</option>
                                                    <option value="Moderate">Moderate</option>
                                                    <option value="Severe">Severe</option>
                                                </select>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="economic_activities">Economic Activities</label>
                                                <select value='${data?.economic_activities ?? ''}' class="modal-input"  id="economic_activities">
                                                    <option value="${data?.economic_activities ?? ''}">${data?.economic_activities ?? 'Choose an Activity'}</option>
                                                    <option value="Unemployed">Unemployed</option>
                                                    <option value="Part-time Employed">Part-time Employed</option>
                                                    <option value="Full-time Employed">Full-time Employed</option>
                                                    <option value="Self Employed/Business Owner">Self-Employed/Business Owner</option>
                                        
                                                </select>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="family_support">Family Support</label>
                                                <select value='${data?.family_support ?? ''}' class="modal-input"  id="family_support">
                                                    <option value="">${data?.family_support ?? 'Level Of Support'}</option>
                                                    <option value="No Support">No Support</option>
                                                    <option value="Limited Support">Limited Support</option>
                                                    <option value="Moderate Support">Moderate Support</option>
                                                    <option value="Strong Support">Strong Support</option>
                                    
                                                </select>
                                            </div>
                                        </div>
                                                        
                                <div class="modal-button-container margin-bottom">
                                    <button type="button" class="generate-button" onclick="updateBiodata(${data.id}, ${data.user_pin} )" id="save-btn">
                                        Save
                                    </button>  
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="no-display-userdata" id="user-data-content-container-location">
                           <div class="content-header-container">
                                <h4 id="content-header" class="content-header">Location</h4>
                            </div>
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="house_number">House Number</label>
                                                <input value='${data?.house_number ?? '' }' class="modal-input" type="text" id="house_number" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="street">Street</label>
                                                <input value='${data?.street ?? ''}' class="modal-input" type="text" id="street" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="area_community">Area/Community</label>
                                                <input value='${data?.area_community ?? ''}' class="modal-input" type="text" id="area_community" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="city_village">City/Village</label>
                                                <input value='${data?.city_village ?? ''}' class="modal-input" type="text" id="city_village" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="state">State</label>
                                      
                                                <select  value='${data?.state ?? ''}' class="modal-input" id="state">
                                                    <option  value='${data?.state ?? ''}'> ${data?.state ?? 'Select a State'}</option>
                                                    <option value="Abuja">Abuja</option>
                                                    <option value="Abia">Abia</option>
                                                    <option value="Adamawa">Adamawa</option>
                                                    <option value="Akwa Ibom">Akwa Ibom</option>
                                                    <option value="Anambra">Anambra</option>
                                                    <option value="Bauchi">Bauchi</option>
                                                    <option value="Bayelsa">Bayelsa</option>
                                                    <option value="Benue">Benue</option>
                                                    <option value="Borno">Borno</option>
                                                    <option value="Cross River">Cross River</option>
                                                    <option value="Delta">Delta</option>
                                                    <option value="Ebonyi">Ebonyi</option>
                                                    <option value="Edo">Edo</option>
                                                    <option value="Ekiti">Ekiti</option>
                                                    <option value="Enugu">Enugu</option>
                                                    <option value="Gombe">Gombe</option>
                                                    <option value="Imo">Imo</option>
                                                    <option value="Jigawa">Jigawa</option>
                                                    <option value="Kaduna">Kaduna</option>
                                                    <option value="Kano">Kano</option>
                                                    <option value="Katsina">Katsina</option>
                                                    <option value="Kebbi">Kebbi</option>
                                                    <option value="Kogi">Kogi</option>
                                                    <option value="Kwara">Kwara</option>
                                                    <option value="Lagos">Lagos</option>
                                                    <option value="Nasarawa">Nasarawa</option>
                                                    <option value="Niger">Niger</option>
                                                    <option value="Ogun">Ogun</option>
                                                    <option value="Ondo">Ondo</option>
                                                    <option value="Osun">Osun</option>
                                                    <option value="Oyo">Oyo</option>
                                                    <option value="Plateau">Plateau</option>
                                                    <option value="Rivers">Rivers</option>
                                                    <option value="Sokoto">Sokoto</option>
                                                    <option value="Taraba">Taraba</option>
                                                    <option value="Yobe">Yobe</option>
                                                    <option value="Zamfara">Zamfara</option>
                                                </select>
                                            </div>
                                        
                                        

                                        </div>

                                    
                                                            
                                    <div class="modal-button-container margin-bottom">
                                        <button type="button" class="generate-button" onclick="updateLocation(${data.id}, ${data.user_pin} )" id="save-btn">
                                            Save
                                        </button>  
                                    </div>
                                
                                </form>

                            </div>
                    </div>
                    <div class="no-display-userdata" id="user-data-content-container-poverty_status">
                        <div class="content-header-container">
                            <h4 id="content-header" class="content-header">Poverty Status</h4>
                        </div>
                        <div class="generate-pin-container">
                                <form id="form" class="biodata-form">
                                    <div class="three-forms">
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Business Activity</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="nature_type_of_business">Nature/ Type of Business</label>
                                                <input value='${data?.nature_type_of_business ?? ''}' class="modal-input" type="text" id="nature_type_of_business" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="size_of_business">Size of Business (Estimated Value)</label>
                                                <input value='${data?.size_of_business ?? ''}' class="modal-input" type="text" id="size_of_business" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="location_of_business">Location of  Business</label>
                                                <input value='${data?.location_of_business ?? ''}' class="modal-input" type="text" id="location_of_business" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="daily_income">Daily Income</label>
                                                <input value='${data?.daily_income ?? ''}' class="modal-input" type="text" id="daily_income" />
                                            </div>
                                        </div>
                                    
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Family</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="marital_status">Marital Status</label>
                                                <select value='${data?.family_marital_status ?? ''}' class="modal-input"  id="family_marital_status">
                                                    <option value="">${data?.family_marital_status ?? 'Choose a Marital Status'}</option>
                                                    <option value="Single">Single</option>
                                                    <option value="Married">Married</option>
                                                    <option value="Widowed">Widowed</option>
                                                    <option value="Divorced">Divorced</option>
                                                    <option value="Separated">Separated</option>
                                                </select>
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="number_of_children">Number of children under 20 years</label>
                                                <input value='${data?.number_of_children ?? ''}' class="modal-input" type="text" id="number_of_children" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="age_of_spouse">Age of Spouse</label>
                                                <input value='${data.age_of_spouse ?? ''}' class="modal-input" type="text" id="age_of_spouse" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="nature_of_occupation_spouse">Nature of occupation of spouse</label>
                                                <input value='${data?.nature_of_occupation_spouse ?? ''}' class="modal-input" type="text" id="nature_of_occupation_spouse" />
                                            </div>
                                        </div>
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Dwelling Place</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="own_home">Own home or rent</label>
                                               
                                                <select value='${data?.own_home ?? ''}' class="modal-input"  id="own_home">
                                                    <option value="${data?.own_home ?? ''}">${data?.own_home ?? 'dwelling place'}</option>
                                                    <option value="Own a home">Own a home</option>
                                                    <option value="Rent">Rent</option>
                                                   
                                                </select>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="size_of_dwelling">Size of dwelling place ( Number of rooms)</label>
                                                <input value='${data?.size_of_dwelling ?? ''}' class="modal-input" type="text" id="size_of_dwelling" />
                                            </div>
                                        

                                        </div>
                                    </div>
                                    <div class="three-forms">
                                
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Nutrition</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="main_type_of_meal">Main type Of Meal</label>
                                                <input value='${data?.main_type_of_meal ?? ''}' class="modal-input" type="text" id="main_type_of_meal" />
                                            </div>
                                        </div>
                                    
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Level Of Formal Education</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="marital_status">Education</label>
                                                <select value='${data?.level_of_education ?? ''}' class="modal-input"  id="level_of_education">
                                                    <option value="${data?.level_of_education ?? ''}">${data?.level_of_education ?? 'Choose a Level of Education'}</option>
                                                    <option value="Non-Primary">Non-Primary</option>
                                                    <option value="Half-Primary">Half-Primary</option>
                                                    <option value="Full-Primary">Full-Primary</option>
                                                    <option value="Half-Secondary">Half-Secondary</option>
                                                </select>
                                            </div>
                                        
                                        </div>
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Health Status</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="major_illiness">Any major illness</label>
                                                <input value='${data?.major_illiness ?? ''}' class="modal-input" type="text" id="major_illiness" />
                                            </div>
                                        

                                        </div>
                                    </div>

                                
                                                        
                                <div class="modal-button-container margin-bottom">
                                    <button type="button" class="generate-button" onclick="updatePovertyStatus(${data.id})" id="save-btn">
                                        Save
                                    </button>  
                                </div>
                            
                            </form>

                        </div>
                    </div>
                    <div class="no-display-userdata" id="user-data-content-container-id">
                        <div class="content-header-container">
                            <h4 id="content-header" class="content-header">ID</h4>
                        </div>
                        <div class="generate-pin-container">
                                <form id="form" class="biodata-form">
                                    <div class="two-forms margin-top">
                                            <div class="id-form">
                                                <input onchange="chooseId()" class="modal-input" name="id" type="radio" id="nin-radio" />
                                                <label class="form-label" for="nin">NIN(National Identification Number)</label>
                                            
                                            </div>
                                            <div class="form-nin" id="nin-container">
                                                <p class="id-label text-center" >Please Enter Your NiN Below</p>
                                                <div class="form_element">
                                                    <label class="form-label" for="nin">NIN</label>
                                                    <input value='${data?.id_name == 'nin' ? data?.id_number : ''  }' class="modal-input" type="text" id="nin" />
                                                </div>
                                            </div>
                                    </div>
                                    <div class="two-forms margin-top">
                                        <div class="id-form">
                                            <input onchange="chooseId()" name="id" class="modal-input" type="radio" id="drivers-license-radio" />
                                            <label class="form-label" for="drivers_license">Driver's License</label>
                                        </div>
                                        <div class="form-nin" id="drivers-license-container">
                                            <p class="id-label text-center" >Please Enter Your Driver's License Below</p>
                                            <div class="form_element">
                                                <label class="form-label" for="nin">Driver's License</label>
                                                <input value='${data?.id_name == 'drivers_license' ? data?.id_number : ''  }' class="modal-input" type="text" id="drivers_license" />
                                            </div>
                                            <div class="double-forms ">
                                                <div class="form_element">
                                                    <label class="form-label" for="nin">Issue Date</label>
                                                    <input class="modal-input" type="date" id="issue_date" />
                                                </div>
                                                <div class="form_element">
                                                    <label class="form-label" for="nin">Expiry Date</label>
                                                    <input value='${data?.expiry_date ?? ''}' class="modal-input" type="date" id="expiry_date" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="two-forms margin-top">
                                        <div class="id-form">
                                            <input onchange="chooseId()" name="id" class="modal-input" type="radio" id="voters-card-radio" />
                                            <label class="form-label" for="voters_card">Voters Card</label>
                                        
                                        </div>
                                        <div class="form-nin" id="voters-card-container">
                                            <p class="id-label text-center" >Please Enter Your Voters Card Details Below</p>
                                            <div class="form_element">
                                                <label class="form-label" for="nin">Voters Card</label>
                                                <input value='${data?.id_name == 'voters_card' ? data?.id_number : ''  }' class="modal-input" type="text" id="voters_card" />
                                            </div>
                                        </div>
                                    </div>
                                

                                
                                                        
                                <div class="modal-button-container margin-bottom">
                                    <button type="button" class="generate-button" onclick="updateId(${data.id})" id="save-btn">
                                        Submit
                                    </button>  
                                </div>
                            
                            </form>

                        </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function viewUserData(newData){
  
    var modals = document.querySelector('.modals');
    const data = newData || 0;
    
    var modalContent = `
    

    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            <div id="everything-view">

                 <div class="add-text-header no-print">
                    <button class="sign-out-button" onclick="downloadView()">Download</button>
                    <h3>View User Data</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <div class="both-logo">
                     <div class="ec-container">
                    <img src="${serverUrl}/assets/images/ec-logo.png" class="" alt="" />
                    </div>
                    <div class="ec-container">
                        <img src="${serverUrl}/uploads/${data?.image}" class="profile-pic" alt="" />
                    </div>
                </div>
               
               

               <div id="user-data-content-container" class="user-data-content-container">
                    <div  id="user-data-content-container-pin">
                    
                        <div class="generate-pin-container2">
                        
                    
                            <form id="form" class="pin-generate-form">
                                <div class="content-header-container2 flex-column">
                                    <h4 id="content-header" class="content-header2">Pin</h4>
                                    <p class='form-label2'>${data?.user_pin ?? ''}</p>
                                </div>
                                <div class="form_element">
                                    
                                            

                                </div>
                            
                        
                        </form>

                        </div>
                    </div>
                    
                    <div class="display-userdata " id="user-data-content-container-biodata">
                        <div class="content-header-container2">
                            <h4 id="content-header" class="content-header2">BioData</h4>
                        </div>
                        <div class="generate-pin-container">
                                <form id="form" class="biodata-form">
                                    <div class="three-forms">
                                        <div class="form_element">
                                            <label onclick="saveBiodata()" class="form-label" for="first_name">First Name:</label>
                
                                            <p class='form-label2'>${data?.first_name ?? ''}</p>
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="last_name">Last Name:</label>
                                            <p class='form-label2'>${data?.last_name ?? ''}</p>

                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="age">Age:</label>
                                            <p class='form-label2'>${data?.age ?? ''}</p>


                                        </div>
                                    </div>
                                    <div class="three-forms">
                                        <div class="form_element">
                                            <label class="form-label" for="gender">Gender</label>
                                            <p class='form-label2'>${data?.gender ?? ''}</p>

                                         
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="marital_status">Marital Status:</label>
                                            <p class='form-label2'>${data?.marital_status ?? ''}</p>

                                          
                                               
                                        </div>
                                    

                                    </div>

               

                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="disability">Disability:</label>
                                                <p class='form-label2'>${data?.disability ?? ''}</p>

                                              
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="economic_activities">Economic Activities:</label>
                                                <p class='form-label2'>${data?.economic_activities ?? ''}</p>

                                              
                                                
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="family_support">Family Support:</label>
                                                <p class='form-label2'>${data?.family_support ?? ''}</p>

                                                  
                                            </div>
                                        </div>
                                                        
                              
                            </form>
                        </div>
                    </div>
                    <div class="display-userdata" id="user-data-content-container-location">
                           <div class="content-header-container2">
                                <h4 id="content-header" class="content-header2">Location:</h4>
                            </div>
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="house_number">House Number:</label>
                                                <p class='form-label2'>${data?.house_number ?? ''}</p>

                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="street">Street:</label>
                                                <p class='form-label2'>${data?.street ?? ''}</p>

                                   
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="area_community">Area/Community:</label>
                                                <p class='form-label2'>${data?.area_community ?? ''}</p>

                                              
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                                <div class="form_element">
                                                    <label class="form-label" for="city_village">City/Village:</label>
                                                    <p class='form-label2'>${data?.city_village ?? ''}</p>
                                                </div>
                                                <div class="form_element">
                                                    <label class="form-label" for="state">State</label>
                                                    <p class='form-label2'>${data?.state ?? ''}</p>
                                                </div>
                                        </div>

                                    
                                  
                                
                                </form>

                            </div>
                    </div>
                    <div class="display-userdata" id="user-data-content-container-poverty_status">
                        <div class="content-header-container2">
                            <h4 id="content-header" class="content-header2">Poverty Status</h4>
                        </div>
                        <div class="generate-pin-container">
                                <form id="form" class="biodata-form">
                                    <div class="three-forms">
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Business Activity: </h3>
                                            <div class="form_element">
                                                <label class="form-label" for="nature_type_of_business">Nature/ Type of Business:</label>
                                                <p class='form-label2'>${data?.nature_type_of_business ?? ''}</p>

                                               
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="size_of_business">Size of Business (Estimated Value):</label>
                                                <p class='form-label2'>${data?.size_of_business ?? ''}</p>

                                               
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="location_of_business">Location of  Business:</label>
                                                <p class='form-label2'>${data?.location_of_business ?? ''}</p>

                                           
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="daily_income">Daily Income:</label>
                                                <p class='form-label2'>${data?.daily_income ?? ''}</p>

                                            </div>
                                        </div>
                                    
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Family</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="marital_status">Marital Status:</label>
                                                <p class='form-label2'>${data?.family_marital_status ?? ''}</p>

                                               

                                              
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="number_of_children">Number of children under 20 years:</label>
                                                <p class='form-label2'>${data?.number_of_children ?? ''}</p>

                                               
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="age_of_spouse">Age of Spouse:</label>
                                                <p class='form-label2'>${data?.age_of_spouse ?? ''}</p>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="nature_of_occupation_spouse">Nature of occupation of spouse</label>
                                                <p class='form-label2'>${data?.nature_of_occupation_spouse ?? ''}</p>
                                            </div>
                                        </div>
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Dwelling Place</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="own_home">Own home or rent:</label>
                                                <p class='form-label2'>${data?.own_home ?? ''}</p>

                        
                                               
                                              
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="size_of_dwelling">Size of dwelling place ( Number of rooms):</label>
                                                <p class='form-label2'>${data?.size_of_dwelling ?? ''}</p>

                                            </div>
                                        

                                        </div>
                                    </div>
                                    <div class="three-forms">
                                
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Nutrition</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="main_type_of_meal">Main type Of Meal:</label>
                                                <p class='form-label2'>${data?.main_type_of_meal ?? ''}</p>

                              
                                            </div>
                                        </div>
                                    
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Level Of Formal Education</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="marital_status">Education:</label>
                                                <p class='form-label2'>${data?.level_of_education ?? ''}</p>


                                        
                                            </div>
                                        
                                        </div>
                                        <div class="poverty-column">
                                            <h3 class="poverty-heading">Health Status:</h3>
                                            <div class="form_element">
                                                <label class="form-label" for="major_illiness">Any major illness</label>
                                                <p class='form-label2'>${data?.major_illiness ?? ''}</p>

                                            </div>
                                        

                                        </div>
                                    </div>

                                
                              
                            
                            </form>

                        </div>
                    </div>
                    <div  id="user-data-content-container-pin">
                        <div class="content-header-container2">
                            <h4 id="content-header" class="content-header2">ID</h4>
                        </div>
                        <div class="generate-pin-container">
                        
                    
                                <form id="form" class="generate-form">
                                    <div class="form_element">
                                        <label for="Donor">${data?.id_name.toUpperCase() ?? ''}:</label>
                                        <p class='form-label2'>${data?.id_number ?? ''}</p>

                                    </div>
                                    
                              
                            
                            </form>

                        </div>
                    </div>
                   
                </div>
            </div>
            
      

        </div>
    </div>
    `;

    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }


  
   
    
}

function receiptPaymentChart(){
    var modals = document.querySelector('.modals');
    
    var modalContent = `
    

    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            <div id="everything-view">

                 <div class="add-text-header no-print">
                    <button class="sign-out-button" onclick="downloadView()">Download</button>
                    <h3>Financial Domain</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
               
                <div class="analytics-container2">
                    <div class="whole-card3">
                        <h3 class="card-text">Receipt & Payment</h3>
                        <div class="analytics-card-container2">
                            <div class="analytics-space">
                                <div class="analytics-button2" alt="">
                                    <p class="total-text">Total:</p>
                                    <div class="cr-container">
                                        <p class="cr">Cr</p>
                                        <span id=cr-text class="lytics-text"></span>
                                    </div>
                                    <div class="cr-container">
                                        <p class="cr">Dr</p>
                                        <span id=dr-text class="lytics-text"></span>
                                    </div>
                                  
                                </div>
                                <div class="analytics-button" alt="">
                                    <input type="number" id="yearInput" placeholder="Enter Year" />
                                    <button onclick="updateChart()" class="card-date">Submit</button>
                                </div>
                            </div>
                            
                            <div class="analytics-image">
                               <canvas id="analyticsChart" width="400" height="200"></canvas>

                            </div>

                        </div>
                    </div>
                    
                   
                    
                   
                </div>
        </div>
    </div>
    `;

    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
    fetchAllAnalyticsData();

  
   
    
}

function beneficiaryAnalytics(newData){
  
    var modals = document.querySelector('.modals');
    const data = newData || 0;
    
    var modalContent = `
    

    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            <div id="everything-view">

                 <div class="add-text-header no-print">
                    <button class="sign-out-button" onclick="downloadView()">Download</button>
                    <h3>(Beneficiaries)Total No Supported Per Period</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
               
                <div class="analytics-container">
                    <div class="whole-card">
                        <h3 class="card-text">Age</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt="">
                                <button class="card-date">Month</button>
                                <button class="card-date">Year</button>
                            </div>
                            <div class="analytics-image">
                                <img class="graph-image2" src="${serverUrl}/assets/images/age-analytics.png" alt="" />
                            </div>

                        </div>
                    </div>
                    <div class="whole-card">
                        <h3 class="card-text">Gender</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt="">
                                <button class="card-date">Month</button>
                                <button class="card-date">Year</button>
                            </div>
                            <div class="analytics-image">
                                <img class="graph-image" src="${serverUrl}/assets/images/gender-analytics.png" alt="" />
                            </div>

                        </div>
                    </div>
                    <div class="whole-card">
                        <h3 class="card-text">Marital Status</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt="">
                                <button class="card-date">Month</button>
                                <button class="card-date">Year</button>
                            </div>
                            <div class="analytics-image">
                                <img class="graph-image" src="${serverUrl}/assets/images/marital-status-analytics.png" alt="" />
                            </div>

                        </div>
                    </div>
                    <div class="whole-card2">
                        <h3 class="card-text">Location</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt="">
                                <button class="card-date">Month</button>
                                <button class="card-date">Year</button>
                            </div>
                            <div class="analytics-image">
                                <img class="graph-image" src="${serverUrl}/assets/images/location-analytics.png" alt="" />
                            </div>

                        </div>
                    </div>
                     <div class="whole-card">
                        <h3 class="card-text">Beneficiaries</h3>
                        <div class="analytics-card-container">
                            <div class="analytics-button" alt="">
                                <button class="card-date">Month</button>
                                <button class="card-date">Year</button>
                            </div>
                            <div class="analytics-image">
                                <img class="graph-image" src="${serverUrl}/assets/images/marital-status-analytics.png" alt="" />
                            </div>

                        </div>
                    </div>
                   
                    
                   
                </div>
        </div>
    </div>
    `;

    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }


  
   
    
}

function downloadView() {
    const element = document.getElementById('everything-view'); 
    console.log(element);
    
    if (!element) {
        console.error("Element not found!");
        return;
    }

    var originalContent = document.body.innerHTML;
    var printContent = element.innerHTML;

    document.body.innerHTML = printContent;
    window.print();
    document.body.innerHTML = originalContent;
}

let id_name = '';
let id_number = '';
let issue_date = '';
let expiry_date = '';

function chooseId(){
    const ninRadio = document.getElementById('nin-radio');
    const ninId = document.getElementById('nin-container');
    let ninNumber = document.getElementById('nin').value;
    const driversLicenseRadio = document.getElementById('drivers-license-radio');
    const driversLicenseId = document.getElementById('drivers-license-container');
    const driversLicenseNumber = document.getElementById('drivers_license').value;
    const issue_date_number = document.getElementById('issue_date').value;
    const expiry_date_number = document.getElementById('expiry_date').value;
    const votersCardRadio = document.getElementById('voters-card-radio');
    const votersCardId = document.getElementById('voters-card-container');
    const votersCardNumber = document.getElementById('voters_card').value;
    if (ninRadio.checked) {

        ninId.classList.add('display-id');
        driversLicenseId.classList.remove('display-id') 
        votersCardId.classList.remove('display-id')
        id_name = 'nin';
        id_number = ninNumber;

        console.log(id_number);
        
    } else if (driversLicenseRadio.checked) {
       
        ninId.classList.remove('display-id') 
        driversLicenseId.classList.add('display-id');
        votersCardId.classList.remove('display-id') 
        id_name = 'drivers_license';

        id_number = driversLicenseNumber;
      
    } else if (votersCardRadio.checked){
 
        ninId.classList.remove('display-id');
        driversLicenseId.classList.remove('display-id') 
        votersCardId.classList.add('display-id') 
        id_name = 'voters_card';
        id_number = votersCardNumber;
        console.log(id_number);

    }
}

function changeUserDataContent(content){

    const contentContainerPin = document.getElementById("user-data-content-container-pin");
    const contentContainerBiodata = document.getElementById("user-data-content-container-biodata");
    const contentContainerlocation = document.getElementById("user-data-content-container-location");
    const contentContainerPovertyStatus = document.getElementById("user-data-content-container-poverty_status");
    const contentContainerId = document.getElementById("user-data-content-container-id");
    const pinText = document.getElementById("userdata-option-text-pin");
    const biodataText = document.getElementById("userdata-option-text-biodata");
    const locationText = document.getElementById("userdata-option-text-location");
    const povertyStatusText = document.getElementById("userdata-option-text-poverty_status");
    const idText = document.getElementById("userdata-option-text-id");



    if(content == 'pinContent'){
        contentContainerPin.classList.remove('no-display-userdata');
        contentContainerBiodata.classList.add('no-display-userdata');
        contentContainerlocation.classList.add('no-display-userdata');
        contentContainerPovertyStatus.classList.add('no-display-userdata');
        contentContainerId.classList.add('no-display-userdata');
        pinText.classList.add('green-border-bottom');
        biodataText.classList.remove('green-border-bottom');
        locationText.classList.remove('green-border-bottom');
        povertyStatusText.classList.remove('green-border-bottom');
        idText.classList.remove('green-border-bottom');
    }else if(content == 'biodataContent'){
        contentContainerPin.classList.add('no-display-userdata');
        contentContainerBiodata.classList.remove('no-display-userdata');
        contentContainerlocation.classList.add('no-display-userdata');
        contentContainerPovertyStatus.classList.add('no-display-userdata');
        contentContainerId.classList.add('no-display-userdata');
        pinText.classList.remove('green-border-bottom');
        biodataText.classList.add('green-border-bottom');
        locationText.classList.remove('green-border-bottom');
        povertyStatusText.classList.remove('green-border-bottom');
        idText.classList.remove('green-border-bottom');
    }else if(content == 'locationContent'){
        contentContainerPin.classList.add('no-display-userdata');
        contentContainerBiodata.classList.add('no-display-userdata');
        contentContainerlocation.classList.remove('no-display-userdata');
        contentContainerPovertyStatus.classList.add('no-display-userdata');
        contentContainerId.classList.add('no-display-userdata');
        pinText.classList.remove('green-border-bottom');
        biodataText.classList.remove('green-border-bottom');
        locationText.classList.add('green-border-bottom');
        povertyStatusText.classList.remove('green-border-bottom');
        idText.classList.remove('green-border-bottom');
    }else if(content == 'povertyStatusContent'){
        contentContainerPin.classList.add('no-display-userdata');
        contentContainerBiodata.classList.add('no-display-userdata');
        contentContainerlocation.classList.add('no-display-userdata');
        contentContainerPovertyStatus.classList.remove('no-display-userdata');
        contentContainerId.classList.add('no-display-userdata');
        pinText.classList.remove('green-border-bottom');
        biodataText.classList.remove('green-border-bottom');
        locationText.classList.remove('green-border-bottom');
        povertyStatusText.classList.add('green-border-bottom');
        idText.classList.remove('green-border-bottom');
    }else if(content == 'idContent'){
        contentContainerPin.classList.add('no-display-userdata');
        contentContainerBiodata.classList.add('no-display-userdata');
        contentContainerlocation.classList.add('no-display-userdata');
        contentContainerPovertyStatus.classList.add('no-display-userdata');
        contentContainerId.classList.remove('no-display-userdata');
        pinText.classList.remove('green-border-bottom');
        biodataText.classList.remove('green-border-bottom');
        locationText.classList.remove('green-border-bottom');
        povertyStatusText.classList.remove('green-border-bottom');
        idText.classList.add('green-border-bottom');
    }
   
}

function updateGreenMark(id){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response) || '';
        const allUserData = response.userdata || '';

        let data = allUserData.find(f => f.id == id);
    
        const greenMarkBiodata = document.getElementById('userdata-option-biodata');
        const greenMarkLocation = document.getElementById('userdata-option-location');
        const greenMarkPovertyStatus = document.getElementById('userdata-option-poverty-status');
        const greenMarkId = document.getElementById('userdata-option-id');
        const generateButton = document.getElementById('generate-btn');


        if(data?.user_pin !== ''){
            generateButton.disabled = true;
            generateButton.innerHTML = 'Generated';
            generateButton.style.backgroundColor = '#B2BEB5';

            
        }
        if(data?.user_pin !== '' && data?.first_name !== '' && data?.last_name !== ''  && data?.age !== '' && data?.gender !== '' && data?.marital_status !== '' && data?.disability !== '' && data?.economic_activities !== '' && data?.family_support !== ''){
            greenMarkBiodata.src = `${serverUrl}/assets/images/green-mark.png`
         
        }

        if(data?.user_pin !== '' && data?.house_number !== '' && data?.street !== ''  && data?.area_community !== '' && data?.city_village !== '' ){
             greenMarkLocation.src = `${serverUrl}/assets/images/green-mark.png`
        }
        
        if(data?.user_pin !== '' && data?.nature_type_of_business !== '' && data?.family_marital_status !== ''  && data?.own_home !== '' && data?.size_of_business !== '' && data?.size_of_dwelling !== '' && data?.location_of_business !== '' && data?.number_of_children !== '' && data?.daily_income !== '' && data?.age_of_spouse !== '' && data?.nature_of_occupation_spouse !== '' && data?.main_type_of_meal !== '' && data?.level_of_education !== '' && data?.major_illiness !== ''){
            greenMarkPovertyStatus.src = `${serverUrl}/assets/images/green-mark.png`
        }

        
        if(data?.user_pin !== '' && data?.id_name !== '' && data?.id_number !== '' ){
            greenMarkId.src = `${serverUrl}/assets/images/green-mark.png`
       }

       

    }
    xhttp.open('GET', '../backend/request.php?function=get-all-userdata');
    xhttp.send();
    
}

function generatePin(){

    const user_pin = Math.floor(100000 + Math.random() * 900000);
    var openModalBtn = document.getElementById("generate-btn");
    let currentDate = new Date();

    let day = ("0" + currentDate.getDate()).slice(-2);
    let month = ("0" + (currentDate.getMonth() + 1)).slice(-2);
    let year = currentDate.getFullYear();
    
    let date = `${day}/${month}/${year}`;
    console.log(date);
    
  

    openModalBtn.disabled = true;
    openModalBtn.innerHTML = "Generating...";

    var formData = new FormData();
    
    formData.append('user_pin', user_pin);
    formData.append('date', date);

    var xhttp = new XMLHttpRequest();

    xhttp.onload = function(){
        openModalBtn.disabled = false;
        openModalBtn.innerHTML = "Generate";
        var response = JSON.parse(xhttp.response);
        if(response.success){
           swal('Hurray', response.success, 'success');
       
           getPin(user_pin);
        }
        else{
            swal('Sorry', response.error, 'error');
        }
    }
    xhttp.onerror = function(error){
        openModalBtn.disabled = false;
        openModalBtn.innerHTML = "Generate";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open("POST", '../backend/request.php?function=save-pin', true);
    xhttp.send(formData);

}

function getPin(pin){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        const pinData = response.pin
        let searchUserPin = pinData.find(f => f.user_pin == pin) || 0;
        let currentUserPin = searchUserPin.user_pin
        let currentUserid = searchUserPin.id
     
        
        saveBiodata(currentUserid, currentUserPin);
        saveLocation(currentUserid, currentUserPin);
        savePovertyStatus(currentUserid, currentUserPin);
        saveId(currentUserid, currentUserPin);
        getAllUserData(pin);
     
       
        
    }
    xhttp.open('GET', '../backend/request.php?function=get-pin');
    xhttp.send();
}

let allUserData = []
function getAllUserData(pin){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        allUserData = response.userdata
        loopAllUserData(allUserData);
    
        
    }
    xhttp.open('GET', '../backend/request.php?function=get-all-userdata');
    xhttp.send();
}

getAllUserData();

function getSpecificUserData(pin){
    var user_pin = pin;
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response) || '';
        const allUserData = response.userdata || '';
        let specificUserData = allUserData.find(f => f.user_pin == user_pin);
 
        addUserData(specificUserData);
        updateGreenMark(specificUserData.id)
    }
    xhttp.open('GET', '../backend/request.php?function=get-all-userdata');
    xhttp.send();
}

function getViewUserData(pin){
    var user_pin = pin;
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response) || '';
        const allUserData = response.userdata || '';
        let specificUserData = allUserData.find(f => f.user_pin == user_pin);
 
        viewUserData(specificUserData);
       
    }
    xhttp.open('GET', '../backend/request.php?function=get-all-userdata');
    xhttp.send();
}


var optionIndexNumber = -1


function openOptions(IndexNumber) {

    if (optionIndexNumber !== -1 && optionIndexNumber !== IndexNumber) {
     
        var previousOptionCard = document.getElementById(`options-${optionIndexNumber}`);
        if (previousOptionCard) {
            previousOptionCard.style.display = 'none';
        }
    }

   
    optionIndexNumber = IndexNumber;
    var optionCard = document.getElementById(`options-${IndexNumber}`);
    if (optionCard) {
        optionCard.style.display = 'block';
    }
}


function loopAllUserData(data){
    var container = document.getElementById('userdata-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){
        data.sort((a, b) => b.id - a.id);


        for(var i=0; i < data.length; i++){

            const score = calculateScore(data[i]);
        counter++;
        tr += `
            <tr>
            <td class="ehi-td">${data[i]?.date ?? ''}</td>
                <td class="ehi-td">${counter}</td>
                <td class="ehi-td"><img class="profile-image" src="${serverUrl}/uploads/${data[i]?.image}" alt="" /></td>
                <td class="ehi-td">${truncateText(data[i]?.first_name + ' ' +  data[i].last_name) ?? ''}</td>
                <td class="ehi-td">${data[i]?.area_community ?? ''}</td>
                <td class="ehi-td">${data[i]?.own_home ?? ''}</td>
                <td class="ehi-td">${data[i]?.user_pin ?? ''}</td>
                <td class="ehi-td">${score ?? ''}</td>
        
                <td class="ehi-td">
                    <div class="relative-position">
                        <button onclick="openOptions(${data[i].id + 200000})" class="three" style="cursor: pointer;">
                            <img src="../assets/images/three-options.png" alt="" class="three-options">
                        </button>
                        <div id="options-${data[i].id + 200000}" class="options-dropdown" style="right: 5px;">
                            <button onclick="getSpecificUserData(${data[i].user_pin} )" class="openModalBtnEdit option-button" >
                                 Open Data
                            </button>
                            <button onclick="getViewUserData(${data[i].user_pin} )" class="openModalBtnEdit option-button" >
                                 View
                            </button>
    
                            <button onclick="deleteUserData(${data[i].id}, ${data[i].user_pin})" class="openModalBtnEdit option-button">
                               
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

function calculateScore(userData) {
    const scoreIndicator = {
        'disability': {
            "No Disability": 1,
            "Mild Disability": 2,
            "Moderate": 3,
            "Severe": 4
        },
        'economic_activities': {
            "Self Employed/Business Owner": 1,
            "Full Time Employed": 2,
            "Part-Time Employed": 3,
            "Unemployed": 4
        },
        'family_support': {
            "No Support": 1,
            "Limited Support": 2,
            "Moderate Support": 3,
            "High Support": 4
        }
    };

    const disabilityScore = scoreIndicator.disability[userData.disability] || 0;
    const economicActivityScore = scoreIndicator.economic_activities[userData.economic_activities] || 0;
    const familySupportScore = scoreIndicator.family_support[userData.family_support] || 0;

    return disabilityScore + economicActivityScore + familySupportScore;
}



function saveBiodata(id, pin){
    if(id && pin){
        var openModalBtn = document.getElementById("save-btn");
        var user_id = id;
        var user_pin = pin;
        var first_name = '';
        var last_name = '';
        var age = 0;
        var gender = '';
        var marital_status = '';
        var disability = '';
        var economic_activities = '';
        var family_support = '';
        var image = '';
    
            var formData = new FormData();
        
            formData.append('user_id', user_id);
            formData.append('user_pin', user_pin);
            formData.append('first_name', first_name);
            formData.append('last_name', last_name);
            formData.append('age', age);
            formData.append('gender', gender);
            formData.append('marital_status', marital_status);
            formData.append('disability', disability);
            formData.append('economic_activities', economic_activities);
            formData.append('family_support', family_support);
            formData.append('image', image);
    
            openModalBtn.disabled = true;
            openModalBtn.innerHTML = "Saving...";
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
        
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
       
                var response = JSON.parse(xhttp.response);
                if(response.success){
                //    swal('Hurray', response.success, 'success');
                   getSpecificUserData(pin);
    
        
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
                // getContacts();
            }
            xhttp.onerror = function(error){
                // modal.style.display = 'none';
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open("POST", '../backend/request.php?function=save-biodata', true);
            xhttp.send(formData);
    }else {
        swal('Hurray', 'Please generate your pin first', 'error');
    }
    
   
  
    
    
}

function updateBiodata(id, pin){

    if(id){
        var openModalBtn = document.getElementById("save-btn");
        var user_id = id;
        
        var first_name = document.getElementById("first_name").value.trim();
        var last_name = document.getElementById("last_name").value.trim();
        var age = document.getElementById("age").value.trim();
        var gender = document.getElementById("gender").value.trim();
        var marital_status = document.getElementById("marital_status").value.trim();
        var disability = document.getElementById("disability").value.trim();
        var economic_activities = document.getElementById("economic_activities").value.trim();
        var family_support = document.getElementById("family_support").value.trim();
    
    
    
            var formData = new FormData();
    
            formData.append('user_id', user_id);
            formData.append('first_name', first_name);
            formData.append('last_name', last_name);
            formData.append('age', age);
            formData.append('gender', gender);
            formData.append('marital_status', marital_status);
            formData.append('disability', disability);
            formData.append('economic_activities', economic_activities);
            formData.append('family_support', family_support);
            formData.append('image', chosen_file);
    
            openModalBtn.disabled = true;
            openModalBtn.innerHTML = "Saving...";
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
        
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
       
                var response = JSON.parse(xhttp.response);
                if(response.success){
                   swal('Hurray', response.success, 'success');
                   getAllUserData()
                   updateGreenMark(id)
       
           
    
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
          
            }
            xhttp.onerror = function(error){
                // modal.style.display = 'none';
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open("POST", '../backend/request.php?function=update-biodata', true);
            xhttp.send(formData);
    }else{
        swal('Sorry', 'Please generate your Pin first', 'error');
    }

   
  
    
    
}

// house_number
// street
// area_community
// city_village

function saveLocation(id, pin){
    var openModalBtn = document.getElementById("save-btn");
    var user_id = id;
    var user_pin = pin;
    var house_number = '';
    var street = '';
    var area_community = '';
    var city_village = '';
    var state = '';

        var formData = new FormData();

        formData.append('user_id', user_id);
        formData.append('user_pin', user_pin);
        formData.append('house_number', house_number);
        formData.append('street', street);
        formData.append('area_community', area_community);
        formData.append('city_village', city_village);
        formData.append('state', state);
      
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
    
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
            //    swal('Hurray', response.success, 'success');

            
            }
            else{
                swal('Sorry', response.error, 'error');
            }
         
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=save-location', true);
        xhttp.send(formData);
  
    
    
}

function updateLocation(id, pin){
    if(id){
        var user_id = id;
        var openModalBtn = document.getElementById("save-btn");
        var house_number = document.getElementById("house_number").value.trim();
        var street = document.getElementById("street").value.trim();
        var area_community = document.getElementById("area_community").value.trim();
        var city_village = document.getElementById("city_village").value.trim();
        var state = document.getElementById("state").value.trim();
    
            var formData = new FormData();
            formData.append('user_id', user_id);
        
            formData.append('house_number', house_number);
            formData.append('street', street);
            formData.append('area_community', area_community);
            formData.append('city_village', city_village);
            formData.append('state', state);

    
            openModalBtn.disabled = true;
            openModalBtn.innerHTML = "Saving...";
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
        
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
       
                var response = JSON.parse(xhttp.response);
                if(response.success){
                   swal('Hurray', response.success, 'success');
                   getAllUserData();
                   updateGreenMark(id);
    
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
                // getContacts();
            }
            xhttp.onerror = function(error){
                // modal.style.display = 'none';
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open("POST", '../backend/request.php?function=update-location', true);
            xhttp.send(formData);
    }else{
        swal('Sorry', 'Please generate your Pin first', 'error');
    }

   
  
}



// nature_type_of_business
// size_of_business
// location_of_business
// daily_income
// family_marital_status

// number_of_children
// age_of_spouse
// nature_of_occupation_spouse
// own_home
// size_of_dwelling
// main_type_of_meal
// level_of_education
// major_illiness


function savePovertyStatus(id, pin){
    var user_id = id;
    var user_pin = pin;

    var openModalBtn = '';
    var nature_type_of_business = '';
    var size_of_business = '';
    var location_of_business = '';
    var daily_income = '';
    var family_marital_status = '';

    var number_of_children = '';
    var age_of_spouse = '';
    var nature_of_occupation_spouse = '';
    var own_home = '';
    var size_of_dwelling = '';
    var main_type_of_meal = '';
    var level_of_education = '';
    var major_illiness = '';

        var formData = new FormData();

        formData.append('user_id', user_id);
        formData.append('user_pin', user_pin);
        formData.append('nature_type_of_business', nature_type_of_business);
        formData.append('size_of_business', size_of_business);
        formData.append('location_of_business', location_of_business);
        formData.append('daily_income', daily_income);
        formData.append('family_marital_status', family_marital_status);

        formData.append('number_of_children', number_of_children);
        formData.append('age_of_spouse', age_of_spouse);
        formData.append('nature_of_occupation_spouse', nature_of_occupation_spouse);
        formData.append('own_home', own_home);
        formData.append('size_of_dwelling', size_of_dwelling);
        formData.append('main_type_of_meal', main_type_of_meal);
        formData.append('level_of_education', level_of_education);
        formData.append('major_illiness', major_illiness);
       

        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
    
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
            //    swal('Hurray', response.success, 'success');
               getSpecificUserData(pin);
               
             
            }
            else{
                swal('Sorry', response.error, 'error');
            }
          
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=save-povertystatus', true);
        xhttp.send(formData);
  
    
    
}

function updatePovertyStatus(id){
    if(id){
        var user_id = id;
        var openModalBtn = document.getElementById("save-btn");
        var nature_type_of_business = document.getElementById("nature_type_of_business").value.trim();
        var size_of_business = document.getElementById("size_of_business").value.trim();
        var location_of_business = document.getElementById("location_of_business").value.trim();
        var daily_income = document.getElementById("daily_income").value.trim();
        var family_marital_status = document.getElementById("family_marital_status").value.trim();
      
        var age_of_spouse = document.getElementById("age_of_spouse").value.trim();
        var number_of_children = document.getElementById("number_of_children").value.trim();
        var nature_of_occupation_spouse = document.getElementById("nature_of_occupation_spouse").value.trim();
        var own_home = document.getElementById("own_home").value.trim();
        var size_of_dwelling = document.getElementById("size_of_dwelling").value.trim();
        var main_type_of_meal = document.getElementById("main_type_of_meal").value.trim();
        var level_of_education = document.getElementById("level_of_education").value.trim();
        var major_illiness = document.getElementById("major_illiness").value.trim();
    
            var formData = new FormData();
    
            formData.append('user_id', user_id);
            formData.append('nature_type_of_business', nature_type_of_business);
            formData.append('size_of_business', size_of_business);
            formData.append('location_of_business', location_of_business);
            formData.append('daily_income', daily_income);
            formData.append('family_marital_status', family_marital_status);
          
            formData.append('number_of_children', number_of_children);
            formData.append('age_of_spouse', age_of_spouse);
            formData.append('nature_of_occupation_spouse', nature_of_occupation_spouse);
            formData.append('own_home', own_home);
            formData.append('size_of_dwelling', size_of_dwelling);
            formData.append('main_type_of_meal', main_type_of_meal);
            formData.append('level_of_education', level_of_education);
            formData.append('major_illiness', major_illiness);
           
    
            openModalBtn.disabled = true;
            openModalBtn.innerHTML = "Saving...";
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
        
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
       
                var response = JSON.parse(xhttp.response);
                if(response.success){
                   swal('Hurray', response.success, 'success');
                   getAllUserData();
                   updateGreenMark(id);
        
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
                // getContacts();
            }
            xhttp.onerror = function(error){
                // modal.style.display = 'none';
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open("POST", '../backend/request.php?function=update-poverty-status', true);
            xhttp.send(formData);
    }else{
        swal('Sorry', 'Please generate your Pin first', 'error');
    }

   
  
    
    
}


// id_name
// id_number
// issue_date_number
// expiry_date_number

function saveId(id, pin){
    var user_id = id;
    var user_pin = pin;

    let id_name = '';
    let id_number = '';
    let issue_date_number = '';
    let expiry_date_number = '';
    var openModalBtn = document.getElementById("save-btn");
  
 


        var formData = new FormData();
        formData.append('user_id', user_id);
        formData.append('user_pin', user_pin);
        formData.append('id_name', id_name);
        formData.append('id_number', id_number);
        formData.append('issue_date_number', issue_date_number);
        formData.append('expiry_date_number', expiry_date_number);
       
       

        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
    
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
            //    swal('Hurray', response.success, 'success');
               getSpecificUserData(pin);

            }
            else{
                swal('Sorry', response.error, 'error');
            }
            // getContacts();
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=save-id', true);
        xhttp.send(formData);
  
    
    
}

function updateId(id){
    if(id){
        var user_id = id;
        let new_id_number = ''
        var openModalBtn = document.getElementById("save-btn");
        const ninNumber = document.getElementById('nin').value;
        const driversLicenseNumber = document.getElementById('drivers_license').value;
        const issue_date_number = document.getElementById('issue_date').value;
        const expiry_date_number = document.getElementById('expiry_date').value;
        const votersCardNumber = document.getElementById('voters_card').value;
    
        if (id_name == 'nin') {
            id_number = ninNumber;
        } else if(id_name == 'drivers_license'){
            id_number = driversLicenseNumber;
        }else if(id_name == 'voters_card'){
            id_number = votersCardNumber;
        }
    
    
            var formData = new FormData();
    
            formData.append('user_id', user_id);
            formData.append('id_name', id_name);
            formData.append('id_number', id_number);
            formData.append('issue_date_number', issue_date_number);
            formData.append('expiry_date_number', expiry_date_number);
           
           
    
            openModalBtn.disabled = true;
            openModalBtn.innerHTML = "Saving...";
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
       
                var response = JSON.parse(xhttp.response);
                if(response.success){
                   swal('Hurray', response.success, 'success');
                   getAllUserData();
                   updateGreenMark(id)
    
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
                // getContacts();
            }
            xhttp.onerror = function(error){
                // modal.style.display = 'none';
                openModalBtn.disabled = false;
                openModalBtn.innerHTML = "Save";
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open("POST", '../backend/request.php?function=update-id', true);
            xhttp.send(formData);
      
    }else{
        swal('Sorry', 'Please generate your Pin first', 'error');
    }

   

   
    
    
}

function formatNumberWithCommas(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


function deleteUserData(i, pin){
    const user_pin = pin

    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);
            formData.append('user_pin', user_pin);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getAllUserData();
                    
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', '../backend/request.php?function=delete-userdata', true);
            xhttp.send(formData);
        }
      });
}









function addReceipt(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Receipt</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                    <div  id="user-data-content-container-location" class="margin-top">
                 
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="receipt">Receipt(CR)</label>
                                                 <select  class="modal-input" id="receipt">
                                                <option value=""></option>
                                                <option value="Cash">Cash</option>
                                                <option value="Bank Transfer">Bank Transfer</option>
                                                </select>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="donor_name">Donor Name(First and Last)</label>
                                                <input value='' class="modal-input" type="text" id="donor_name" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="amount">Amount</label>
                                                <input value='' class="modal-input" type="number" id="amount" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="date">Date</label>
                                                <input value='' class="modal-input" type="date" id="date" />
                                            </div>
                                        </div>
                                    <div class="modal-button-container margin-bottom">
                                        <button type="button" class="generate-button" onclick="saveReceipt()" id="save-btn">
                                            Save
                                        </button>  
                                    </div>
                                
                                </form>

                            </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveReceipt(id, pin){

    const receipt = document.getElementById('receipt').value.trim();
    const donor_name = document.getElementById('donor_name').value.trim();
    const amount = document.getElementById('amount').value.trim();
    const date = document.getElementById('date').value.trim();

    var openModalBtn = document.getElementById("save-btn");
  

        var formData = new FormData();
        formData.append('receipt', receipt);
        formData.append('donor_name', donor_name);
        formData.append('amount', amount);
        formData.append('date', date);

       

        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
    
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               getReceiptData();
               calculateTotalReceiptAmount();
            }
            else{
                swal('Sorry', response.error, 'error');
            }
    
        }
        xhttp.onerror = function(error){

            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=save-receipt', true);
        xhttp.send(formData);
    
}

let receiptData = []
function getReceiptData(pin){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        receiptData = response.receipt
        loopReceipt(receiptData);
        loopReceiptReport(receiptData);
        calculateTotalReceiptAmount();
    
        
    }
    xhttp.open('GET', '../backend/request.php?function=get-receipt');
    xhttp.send();
}

getReceiptData();

function formatDate(dateString) {
    const date = new Date(dateString); 
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); 
    const year = date.getFullYear(); 
    return `${day}/${month}/${year}`; 
}

function calculateTotalReceiptAmount(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        const totalReceiptContainer = document.getElementById('total-receipt')
        var response = JSON.parse(xhttp.response);
        receiptData = response.receipt ?? []
        
        let receiptAmount = 0;

        receiptData.forEach(receipt => {
            receiptAmount += parseInt(receipt.amount) ?? 0;
        });

        if(totalReceiptContainer){
            totalReceiptContainer.innerHTML = `₦${formatNumberWithCommas(receiptAmount)}` ?? ''

        }
    
        
    }
    xhttp.open('GET', '../backend/request.php?function=get-receipt');
    xhttp.send();
}




function loopReceipt(data){
    var container = document.getElementById('receipt-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){

        data.sort((a, b) => b.id - a.id);

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
            <td class="ehi-td">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td">${counter}</td>
                <td class="ehi-td">${data[i]?.donor_name ?? ''}</td>
                <td class="ehi-td">₦${formatNumberWithCommas(data[i]?.amount) ?? ''}</td>
                <td class="ehi-td">${data[i]?.receipt ?? ''}</td>
                <td class="ehi-td">
                    <div class="relative-position">
                        <button onclick="openOptions(${data[i].id + 200000})" class="three" style="cursor: pointer;">
                            <img src="../assets/images/three-options.png" alt="" class="three-options">
                        </button>
                        <div id="options-${data[i].id + 200000}" class="options-dropdown" style="right: 5px;">
                            <button onclick="viewReceipt(${data[i].id} )" class="openModalBtnEdit option-button" >
                                 <img src="/assets/images/view.png"/> View
                            </button>
                            <button onclick="editReceipt(${data[i].id} )" class="openModalBtnEdit option-button" >
                                <img src="/assets/images/edit.png"/> Edit
                            </button>
                            <button onclick="deleteReceipt(${data[i].id})" class="openModalBtnEdit option-button">
                                <img src="/assets/images/delete.png"/> Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}


function loopReceiptReport(data){
    var container = document.getElementById('receipt-report-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){

        data.sort((a, b) => b.id - a.id);

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
            <td class="ehi-td2">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td2">${counter}</td>
                <td class="ehi-td2">${data[i]?.donor_name ?? ''}</td>
                <td class="ehi-td2">₦${formatNumberWithCommas(data[i]?.amount) ?? ''}</td>
                <td class="ehi-td2">${data[i]?.receipt ?? ''}</td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

function viewReceipt(receiptId){
    let data = receiptData.find(f => f.id == receiptId) ?? [];
    console.log('data', data);
    
    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Receipt</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                    <div  id="user-data-content-container-location" class="margin-top">
                 
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="receipt">Receipt(CR)</label>
                                                <input value='${data?.receipt}' class="modal-input" type="text" id="receipt" readonly/>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="donor_name">Donor Name(First and Last)</label>
                                                <input value='${data?.donor_name}' class="modal-input" type="text" id="donor_name" readonly/>
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="amount">Amount</label>
                                                <input value='${parseInt(data?.amount)}' class="modal-input" type="number" id="amount" readonly/>
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="date">Date</label>
                                                <input value='${data?.date}' class="modal-input" type="date" id="date" readonly/>
                                            </div>
                                        </div>
                                  
                                
                                </form>

                            </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editReceipt(receiptId){
    let data = receiptData.find(f => f.id == receiptId) ?? [];
    console.log('data', data);
    
    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Receipt</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                    <div  id="user-data-content-container-location" class="margin-top">
                 
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="receipt">Receipt(CR)</label>
                                           
                                                <select value='${data?.receipt  ?? ''}' class="modal-input" id="receipt">
                                                <option value="${data?.receipt  ?? ''}">${data?.receipt  ?? ''}</option>
                                                <option value="Cash">Cash</option>
                                                <option value="Bank Transfer">Bank Transfer</option>
                                            </select>
                                                
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="donor_name">Donor Name(First and Last)</label>
                                                <input value='${data?.donor_name}' class="modal-input" type="text" id="donor_name" />
                                            </div>
                                            <div class="form_element">
                                                <label class="form-label" for="amount">Amount</label>
                                                <input value='${parseInt(data?.amount)}' class="modal-input" type="number" id="amount" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="date">Date</label>
                                                <input value='${data?.date}' class="modal-input" type="date" id="date" />
                                            </div>
                                        </div>
                                    <div class="modal-button-container margin-bottom">
                                        <button type="button" class="generate-button" onclick="updateReceipt(${data?.id})" id="save-btn">
                                            Save
                                        </button>  
                                    </div>
                                
                                </form>

                            </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateReceipt(id){

   
    var openModalBtn = document.getElementById("save-btn");
    const receipt = document.getElementById('receipt').value.trim();
    const donor_name = document.getElementById('donor_name').value.trim();
    const amount = document.getElementById('amount').value.trim();
    const date = document.getElementById('date').value.trim();

        var formData = new FormData();

        formData.append('id', id);

        formData.append('receipt', receipt);
        formData.append('donor_name', donor_name);
        formData.append('amount', amount);
        formData.append('date', date);


        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               closeModal();
               getReceiptData();
               calculateTotalReceiptAmount();

            }
            else{
                swal('Sorry', response.error, 'error');
            }
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=update-receipt', true);
        xhttp.send(formData);
    
}

function deleteReceipt(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getReceiptData();
                    calculateTotalReceiptAmount();

                    
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', '../backend/request.php?function=delete-receipt', true);
            xhttp.send(formData);
        }
      });
}


// Payment 

function addPayment(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Receipt</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                    <div  id="user-data-content-container-location" class="margin-top">
                 
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="receipt">Payment(DR)</label>
                                                <select class="modal-input" id="payment">
                                                <option value="">Choose</option>
                                                <option value="Cash">Cash</option>
                                                <option value="Bank Transfer">Bank Transfer</option>
                                                <option value="Card Payment">Card Payment</option>
                                                </select>
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="amount">Amount</label>
                                                <input value='' class="modal-input" type="number" id="amount" />
                                            </div>
                                             <div class="form_element">
                                                <label class="form-label" for="date">Date</label>
                                                <input value='' class="modal-input" type="date" id="date" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="payment_details">Payment Details</label>
                                                <input value='' class="modal-input" type="text" id="payment_details" />
                                            </div>
                                           
                                          
                                        </div>
                                        
                                    <div class="modal-button-container margin-bottom">
                                        <button type="button" class="generate-button" onclick="savePayment()" id="save-btn">
                                            Save
                                        </button>  
                                    </div>
                                
                                </form>

                            </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function savePayment(){

    const payment = document.getElementById('payment').value.trim();
    const payment_details = document.getElementById('payment_details').value.trim();
    const amount = document.getElementById('amount').value.trim();
    const date = document.getElementById('date').value.trim();

    var openModalBtn = document.getElementById("save-btn");
  

        var formData = new FormData();
        formData.append('payment', payment);
        formData.append('payment_details', payment_details);
        formData.append('amount', amount);
        formData.append('date', date);

       

        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
    
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               getPaymentData();
            }
            else{
                swal('Sorry', response.error, 'error');
            }
    
        }
        xhttp.onerror = function(error){

            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=save-payment', true);
        xhttp.send(formData);
    
}

let paymentData = []
function getPaymentData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        paymentData = response.payment
        loopPayment(paymentData);
        loopPaymentReport(paymentData);
        calculateTotalPaymentAmount()
    
        
    }
    xhttp.open('GET', '../backend/request.php?function=get-payment');
    xhttp.send();
}

getPaymentData();

function calculateTotalPaymentAmount(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        const totalPaymentContainer = document.getElementById('total-payment')
        var response = JSON.parse(xhttp.response);
        paymentData = response.payment ?? []
        
        let paymentAmount = 0;

        paymentData.forEach(payment => {
            paymentAmount += parseInt(payment.amount) ?? 0;
        });

        if(totalPaymentContainer){
            totalPaymentContainer.innerHTML = `₦${formatNumberWithCommas(paymentAmount)}` ?? ''

        }
    
        
    }
    xhttp.open('GET', '../backend/request.php?function=get-payment');
    xhttp.send();
}


function loopPayment(data){
    var container = document.getElementById('payment-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){

        data.sort((a, b) => b.id - a.id);

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
            <td class="ehi-td">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td">${counter}</td>
                <td class="ehi-td">${truncateText(data[i]?.payment_details) ?? ''}</td>
                
                <td class="ehi-td">₦${formatNumberWithCommas(data[i]?.amount) ?? ''}</td>
                <td class="ehi-td">${data[i]?.payment ?? ''}</td>
                <td class="ehi-td">
                    <div class="relative-position">
                        <button onclick="openOptions(${data[i].id + 200000})" class="three" style="cursor: pointer;">
                            <img src="../assets/images/three-options.png" alt="" class="three-options">
                        </button>
                        <div id="options-${data[i].id + 200000}" class="options-dropdown" style="right: 5px;">
                            <button onclick="viewPayment(${data[i].id} )" class="openModalBtnEdit option-button" >
                                 <img src="/assets/images/view.png"/> View
                            </button>
                            <button onclick="editPayment(${data[i].id} )" class="openModalBtnEdit option-button" >
                                <img src="/assets/images/edit.png"/> Edit
                            </button>
                            <button onclick="deletePayment(${data[i].id})" class="openModalBtnEdit option-button">
                                <img src="/assets/images/delete.png"/> Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

function submitReceiptDate() {

    const fromDate = document.getElementById('from-date').value;
    const toDate = document.getElementById('to-date').value;

    if (fromDate !== '' && toDate !== '') {
        const newFromDate = new Date(fromDate).toISOString().split('T')[0];
        const newToDate = new Date(toDate).toISOString().split('T')[0];

        var xhttp = new XMLHttpRequest();
        
        xhttp.onload = function () {
            var response = JSON.parse(xhttp.response);
            let receiptReportData = response.receipt;
            
            let filterReceiptReport = receiptReportData.filter(item => {
                const itemDate = new Date(item.date).toISOString().split('T')[0];
                return itemDate >= newFromDate && itemDate <= newToDate;
            });

            loopReceiptReport(filterReceiptReport);
        }

        xhttp.open('GET', '../backend/request.php?function=get-receipt');
        xhttp.send();
    } else {
        swal('Sorry', 'Please add dates', 'error');
    }
}

function downloadReceiptReport() {
    const element = document.querySelector('.ehi-table-container'); 
    console.log(element);
    
    if (!element) {
        console.error("Element not found!");
        return;
    }

    var originalContent = document.body.innerHTML;
    var printContent = element.innerHTML;

    document.body.innerHTML = printContent;
    window.print();
    document.body.innerHTML = originalContent;
}

function submitPaymentDate() {

    const fromDate = document.getElementById('from-date').value;
    const toDate = document.getElementById('to-date').value;

    if (fromDate !== '' && toDate !== '') {
        const newFromDate = new Date(fromDate).toISOString().split('T')[0];
        const newToDate = new Date(toDate).toISOString().split('T')[0];

        var xhttp = new XMLHttpRequest();
        
        xhttp.onload = function () {
            var response = JSON.parse(xhttp.response);
            let paymentReportData = response.payment;
            
            let filterPaymentReport = paymentReportData.filter(item => {
                const itemDate = new Date(item.date).toISOString().split('T')[0];
                return itemDate >= newFromDate && itemDate <= newToDate;
            });

            loopPaymentReport(filterPaymentReport);
        }

        xhttp.open('GET', '../backend/request.php?function=get-payment');
        xhttp.send();
    } else {
        swal('Sorry', 'Please add dates', 'error');
    }
}



function loopPaymentReport(data){
    var container = document.getElementById('payment-report-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){
        data.sort((a, b) => b.id - a.id);
        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                 <td class="ehi-td2">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td2">${counter}</td>
                <td class="ehi-td2">${truncateText(data[i]?.payment_details) ?? ''}</td>
                
                <td class="ehi-td2">₦${formatNumberWithCommas(data[i]?.amount) ?? ''}</td>
                <td class="ehi-td2">${data[i]?.payment ?? ''}</td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
}

function viewPayment(receiptId){
    let data = paymentData.find(f => f.id == receiptId) ?? [];
    console.log('data', data);
    
    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Receipt</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                    <div  id="user-data-content-container-location" class="margin-top">
                 
                            <div class="generate-pin-container">
                                     <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="receipt">Payment(DR)</label>
                                                <input value='${data.payment}' class="modal-input" type="text" id="payment" readonly/>
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="amount">Amount</label>
                                                <input value='${data.amount}' class="modal-input" type="number" id="amount" readonly/>
                                            </div>
                                             <div class="form_element">
                                                <label class="form-label" for="date">Date</label>
                                                <input value='${data.date}' class="modal-input" type="date" id="date" readonly/>
                                            </div>
                                        </div>
                                         <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="payment_details">Payment Details</label>
                                                <input value='${data.payment_details}' class="modal-input" type="text" id="payment_details" />
                                            </div>
                                        </div>
                                        
                                  
                                
                                </form>

                            </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editPayment(receiptId) {
    let data = paymentData.find(f => f.id == receiptId) ?? [];

    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            <div class="add-text-header">
                <h3></h3>
                <h3>Receipt</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
            <div id="user-data-content-container-location" class="margin-top">
                <div class="generate-pin-container">
                    <form id="form" class="biodata-form">
                        <div class="three-forms">
                            <div class="form_element">
                                <label class="form-label" for="receipt">Payment(DR)</label>
                                <select class="modal-input" id="payment">
                                    <option value="${data?.payment ?? ''}">${data?.payment ?? ''}</option>
                                    <option value="Cash">Cash</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                    <option value="Card Payment">Card Payment</option>
                                </select>
                            </div>
                            <div class="form_element">
                                <label class="form-label" for="amount">Amount</label>
                                <input value='${data.amount}' class="modal-input" type="number" id="amount" />
                            </div>
                            <div class="form_element">
                                <label class="form-label" for="date">Date</label>
                                <input value='${data.date}' class="modal-input" type="date" id="date" />
                            </div>
                        </div>
                        <div class="three-forms">
                            <div class="form_element">
                                <label class="form-label" for="payment_details">Payment Details</label>
                                <input value='${data.payment_details}' class="modal-input" type="text" id="payment_details" />
                            </div>
                        </div>
                        <div class="modal-button-container margin-bottom">
                            <button type="button" class="generate-button" onclick="updatePayment(${data.id})" id="save-btn">
                                Save
                            </button>  
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    `;
    
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}


function updatePayment(id){

    var openModalBtn = document.getElementById("save-btn");

    const payment = document.getElementById('payment').value.trim();
    const payment_details = document.getElementById('payment_details').value.trim();
    const amount = document.getElementById('amount').value.trim();
    const date = document.getElementById('date').value.trim();

        var formData = new FormData();

        formData.append('id', id);
        formData.append('payment', payment);
        formData.append('payment_details', payment_details);
        formData.append('amount', amount);
        formData.append('date', date);



        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
   
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               closeModal();
               getPaymentData();
            }
            else{
                swal('Sorry', response.error, 'error');
            }
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=update-payment', true);
        xhttp.send(formData);
    
}


function deletePayment(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getPaymentData();
                    
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', '../backend/request.php?function=delete-payment', true);
            xhttp.send(formData);
        }
      });
}



let analyticsChart;
let receiptAnalyticsData = [];
let paymentAnalyticsData = [];

async function fetchAllAnalyticsData() {
    try {
        const response1 = await fetch('../backend/request.php?function=get-receipt');
        const receiptData = await response1.json();
        receiptAnalyticsData = receiptData.receipt;

        const response2 = await fetch('../backend/request.php?function=get-payment');
        const paymentData = await response2.json();
        paymentAnalyticsData = paymentData.payment;

        createChart(new Date().getFullYear());
    } catch (error) {
        console.error('Error fetching data', error);
    }
}

function createChart(year) {
    const labels = [];
    const receiptAmounts = new Array(12).fill(0);
    const paymentAmounts = new Array(12).fill(0);

    for (let month = 0; month < 12; month++) {
        const date = new Date(year, month);
        labels.push(date.toLocaleString('default', { month: 'long' }));
    }
    
    receiptAnalyticsData.forEach(item => {
        const date = new Date(item.date);
        if (date.getFullYear() === year) {
            const monthIndex = date.getMonth();
            receiptAmounts[monthIndex] += parseFloat(item.amount);
        }
    });

    paymentAnalyticsData.forEach(item => {
        const date = new Date(item.date);
        if (date.getFullYear() === year) {
            const monthIndex = date.getMonth();
            paymentAmounts[monthIndex] += parseFloat(item.amount);
        }
    });

    const totalReceipts = receiptAmounts.reduce((acc, curr) => acc + curr, 0);
    const totalPayments = paymentAmounts.reduce((acc, curr) => acc + curr, 0);

    const totalReceiptText = document.getElementById('cr-text')
    const totalPaymentText = document.getElementById('dr-text')

    if(totalReceiptText && totalPaymentText){
        totalReceiptText.innerHTML = `₦${formatNumberWithCommas(totalReceipts)}.00`
        totalPaymentText.innerHTML = `₦${formatNumberWithCommas(totalPayments)}.00`
    }

    const chartData = {
        labels: labels,
        datasets: [
            {
                label: 'Receipts',
                data: receiptAmounts,
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                fill: true
            },
            {
                label: 'Payments',
                data: paymentAmounts,
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                fill: true
            }
        ]
    };

    const ctx = document.getElementById('analyticsChart').getContext('2d');
    if (!ctx) {
        console.error('Canvas element not found');
        return;
    }else{
        if (analyticsChart) analyticsChart.destroy();

        analyticsChart = new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: `Receipt and Payment Analytics (${year})`
                    }
                }
            }
        });
    }

}

function updateChart() {
    const year = parseInt(document.getElementById('yearInput').value);
    if (year) {
        createChart(year);
    } else {
        alert('Please enter a valid year.');
    }
}

fetchAllAnalyticsData();


function addDonor1(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Add</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                    <div  id="user-data-content-container-location" class="margin-top">
                 
                            <div class="generate-pin-container">
                                    <form id="form" class="biodata-form">
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="last_name">Last Name</label>
                                                <input  class="modal-input" type="text" id="last_name" />
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="first_name">First Name</label>
                                                <input  class="modal-input" type="text" id="first_name" />
                                            </div>
                                             <div class="form_element">
                                                <label class="form-label" for="email">Email</label>
                                                <input  class="modal-input" type="email" id="email" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="phone_no">Phone No</label>
                                                <input class="modal-input" type="text" id="phone_no" />
                                            </div>
                                            <div class="form_element">
                                               <label class="form-label" for="address">Address</label>
                                               <input class="modal-input" type="text" id="address" />
                                           </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="gender">Gender</label>
                                                <select class="modal-input" id="gender">
                                                    <option value="">Choose your gender</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="type_of_donor">Type Of Donor</label>
                                             <select class="modal-input" id="type_of_donor">
                                                    <option value="">Choose</option>
                                                    <option value="Ehi Center">Ehi Center</option>
                                                    <option value="External Donor">External Donor</option>
                                                </select>
                                            </div>
                                            <div class="form_element">
                                               <label class="form-label" for="address">Address</label>
                                               <input class="modal-input" type="text" id="address" />
                                           </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="gender">Gender</label>
                                                <select class="modal-input" id="gender">
                                                    <option value="">Choose your gender</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                    <div class="modal-button-container margin-bottom">
                                        <button type="button" class="generate-button" onclick="saveDonor()" id="save-btn">
                                            Save
                                        </button>  
                                    </div>
                                
                                </form>

                            </div>
                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

// last_name
// first_name
// email
// phone_no
// address
// gender

// function saveDonor1(){

//     const last_name = document.getElementById('last_name').value.trim();
//     const first_name = document.getElementById('first_name').value.trim();
//     const email = document.getElementById('email').value.trim();
//     const phone_no = document.getElementById('phone_no').value.trim();
//     const address = document.getElementById('address').value.trim();
//     const gender = document.getElementById('gender').value.trim();
//     let currentDate = new Date();
//     let day = ("0" + currentDate.getDate()).slice(-2);
//     let month = ("0" + (currentDate.getMonth() + 1)).slice(-2);
//     let year = currentDate.getFullYear();
    
//     let date = `${day}/${month}/${year}`;

//     var openModalBtn = document.getElementById("save-btn");
  

//         var formData = new FormData();
//         formData.append('last_name', last_name);
//         formData.append('first_name', first_name);
//         formData.append('email', email);
//         formData.append('phone_no', phone_no);
//         formData.append('address', address);
//         formData.append('gender', gender);
//         formData.append('date', date);

       

//         openModalBtn.disabled = true;
//         openModalBtn.innerHTML = "Saving...";
//         var xhttp = new XMLHttpRequest();
//         xhttp.onload = function(){
    
//             openModalBtn.disabled = false;
//             openModalBtn.innerHTML = "Save";
   
//             var response = JSON.parse(xhttp.response);
//             if(response.success){
//                swal('Hurray', response.success, 'success');
//                getDonor();
//             }
//             else{
//                 swal('Sorry', response.error, 'error');
//             }
    
//         }
//         xhttp.onerror = function(error){

//             openModalBtn.disabled = false;
//             openModalBtn.innerHTML = "Save";
//             swal('Sorry', "An error occured, try again!", 'error');
//         }
//         xhttp.open("POST", '../backend/request.php?function=save-donor', true);
//         xhttp.send(formData);
    
// }

// let donorData = []
// function getDonor1(){
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function(){
//         var response = JSON.parse(xhttp.response);
//         donorData = response.donor
//         loopDonor(donorData);
        
//     }
//     xhttp.open('GET', '../backend/request.php?function=get-donor');
//     xhttp.send();
// }



function truncateText(value) {
    if (value === null) {
        return '';
    }
    
    if (typeof value === 'string') {
        if (value.length > 10) {
            return value.substring(0, 10) + '...';
        }
        return value;
    } else if (typeof value === 'number') {
        const valueString = value.toString();
        if (valueString.length > 10) {
            return valueString.substring(0, 10) + '...';
        }
        return valueString;
    } else {
        return '';
    }
}


// function loopDonor1(data){
//     var container = document.getElementById('donor-thbody');
//     var tr = "";
//     var counter = 1000;
//     if(data && data.length > 0){



//         for(var i=0; i < data.length; i++){
//         counter++;
//         tr += `
//             <tr>
//             <td class="ehi-td">${data[i]?.date ?? ''}</td>
//                 <td class="ehi-td">${counter}</td>
//                 <td class="ehi-td">${data[i]?.last_name ?? ''}</td>
//                 <td class="ehi-td">${data[i]?.first_name ?? ''}</td>
//                 <td class="ehi-td">${truncateText(data[i]?.email) ?? ''}</td>
//                 <td class="ehi-td">${data[i]?.phone_no ?? ''}</td>
//                 <td class="ehi-td">${truncateText(data[i]?.address) ?? ''}</td>
//                 <td class="ehi-td">${data[i]?.gender ?? ''}</td>
         
      
//                 <td class="ehi-td">
//                     <div class="relative-position">
//                         <button onclick="openOptions(${data[i].id + 200000})" class="three" style="cursor: pointer;">
//                             <img src="../assets/images/three-options.png" alt="" class="three-options">
//                         </button>
//                         <div id="options-${data[i].id + 200000}" class="options-dropdown" style="right: 5px;">
//                             <button onclick="viewDonor(${data[i].id} )" class="openModalBtnEdit option-button" >
//                                  <img src="/assets/images/view.png"/> View
//                             </button>
//                             <button onclick="editDonor(${data[i].id} )" class="openModalBtnEdit option-button" >
//                                 <img src="/assets/images/edit.png"/> Edit
//                             </button>
//                             <button onclick="deleteDonor(${data[i].id})" class="openModalBtnEdit option-button">
//                                 <img src="/assets/images/delete.png"/> Delete
//                             </button>
//                         </div>
//                     </div>
//                 </td>
//             </tr>
//         `;
//         if(container){
//             container.innerHTML = tr;
//         }
//     }
//     }else{
//         if(container){
//             container.innerHTML = "No data yet!";
//         }
//     }
    
// }

// function viewDonor1(id){
//     let data = donorData.find(f => f.id == id) ?? [];
//     var modals = document.querySelector('.modals');
//     var modalContent = `
//     <div id="myModal" class="modal-container">
//         <div class="userdata-modal-content">
            
//             <div class="add-text-header">
//                 <h3></h3>
//                     <h3>View</h3>
//                     <span onclick="closeModal()" class="close">&times;</span>
//                 </div>
//                     <div  id="user-data-content-container-location" class="margin-top">
                 
//                             <div class="generate-pin-container">
//                                     <form id="form" class="biodata-form">
//                                         <div class="three-forms">
//                                             <div class="form_element">
//                                                 <label class="form-label" for="last_name">Lastname</label>
//                                                 <input readonly value="${data?.last_name ?? ''}" class="modal-input" type="text" id="last_name" />
//                                             </div>
                                           
//                                             <div class="form_element">
//                                                 <label class="form-label" for="first_name">First Name</label>
//                                                 <input readonly value="${data?.first_name ?? ''}" class="modal-input" type="text" id="first_name" />
//                                             </div>
//                                              <div class="form_element">
//                                                 <label class="form-label" for="email">Email</label>
//                                                 <input readonly value="${data?.email ?? ''}" class="modal-input" type="email" id="email" />
//                                             </div>
//                                         </div>
//                                         <div class="three-forms">
//                                             <div class="form_element">
//                                                 <label class="form-label" for="phone_no">Phone No</label>
//                                                 <input readonly value="${data?.phone_no ?? ''}" class="modal-input" type="text" id="phone_no" />
//                                             </div>
//                                             <div class="form_element">
//                                                <label class="form-label" for="address">Address</label>
//                                                <input readonly value="${data?.address ?? ''}" class="modal-input" type="text" id="address" />
//                                            </div>
                                           
//                                             <div class="form_element">
//                                                 <label class="form-label" for="gender">Gender</label>
//                                                 <select class="modal-input" readonly value="${data?.gender ?? ''}" id="gender">
//                                                     <option  value="${data?.gender ?? ''}">${data?.gender ?? ''}</option>
                        
//                                                 </select>
//                                             </div>
//                                         </div>
                                        
                                   
                                
//                                 </form>

//                             </div>
//                     </div>
//                 </div>
      

//         </div>
//     </div>
//     `;
//     if(modals){
//         modals.innerHTML = modalContent;
//         openModal();
//     }
// }
// function editDonor1(id){
//     let data = donorData.find(f => f.id == id) ?? [];
//     var modals = document.querySelector('.modals');
//     var modalContent = `
//     <div id="myModal" class="modal-container">
//         <div class="userdata-modal-content">
            
//             <div class="add-text-header">
//                 <h3></h3>
//                     <h3>Edit</h3>
//                     <span onclick="closeModal()" class="close">&times;</span>
//                 </div>
//                     <div  id="user-data-content-container-location" class="margin-top">
                 
//                             <div class="generate-pin-container">
//                                     <form id="form" class="biodata-form">
//                                         <div class="three-forms">
//                                             <div class="form_element">
//                                                 <label class="form-label" for="last_name">Lastname</label>
//                                                 <input value="${data?.last_name ?? ''}" class="modal-input" type="text" id="last_name" />
//                                             </div>
                                           
//                                             <div class="form_element">
//                                                 <label class="form-label" for="first_name">First Name</label>
//                                                 <input value="${data?.first_name ?? ''}" class="modal-input" type="text" id="first_name" />
//                                             </div>
//                                              <div class="form_element">
//                                                 <label class="form-label" for="email">Email</label>
//                                                 <input value="${data?.email ?? ''}" class="modal-input" type="email" id="email" />
//                                             </div>
//                                         </div>
//                                         <div class="three-forms">
//                                             <div class="form_element">
//                                                 <label class="form-label" for="phone_no">Phone No</label>
//                                                 <input value="${data?.phone_no ?? ''}" class="modal-input" type="text" id="phone_no" />
//                                             </div>
//                                             <div class="form_element">
//                                                <label class="form-label" for="address">Address</label>
//                                                <input value="${data?.address ?? ''}" class="modal-input" type="text" id="address" />
//                                            </div>
                                           
//                                             <div class="form_element">
//                                                 <label class="form-label" for="gender">Gender</label>
//                                                 <select class="modal-input" value="${data?.gender ?? ''}" id="gender">
//                                                     <option value="${data?.gender ?? ''}">${data?.gender ?? ''}</option>
//                                                     <option value="Male">Male</option>
//                                                     <option value="Female">Female</option>
//                                                 </select>
//                                             </div>
//                                         </div>
                                        
//                                     <div class="modal-button-container margin-bottom">
//                                         <button type="button" class="generate-button" onclick="updateDonor(${data?.id ?? ''})" id="save-btn">
//                                             Update
//                                         </button>  
//                                     </div>
                                
//                                 </form>

//                             </div>
//                     </div>
//                 </div>
      

//         </div>
//     </div>
//     `;
//     if(modals){
//         modals.innerHTML = modalContent;
//         openModal();
//     }
// }

// function updateDonor1(id){

//     var openModalBtn = document.getElementById("save-btn");

//     const last_name = document.getElementById('last_name').value.trim();
//     const first_name = document.getElementById('first_name').value.trim();
//     const email = document.getElementById('email').value.trim();
//     const phone_no = document.getElementById('phone_no').value.trim();
//     const address = document.getElementById('address').value.trim();
//     const gender = document.getElementById('gender').value.trim();

//         var formData = new FormData();

//         formData.append('last_name', last_name);
//         formData.append('first_name', first_name);
//         formData.append('email', email);
//         formData.append('phone_no', phone_no);
//         formData.append('address', address);
//         formData.append('gender', gender);
//         formData.append('id', id);



//         openModalBtn.disabled = true;
//         openModalBtn.innerHTML = "Saving...";
//         var xhttp = new XMLHttpRequest();
//         xhttp.onload = function(){
//             openModalBtn.disabled = false;
//             openModalBtn.innerHTML = "Save";
   
//             var response = JSON.parse(xhttp.response);
//             if(response.success){
//                swal('Hurray', response.success, 'success');
//                closeModal();
//                getDonor();
//             }
//             else{
//                 swal('Sorry', response.error, 'error');
//             }
//         }
//         xhttp.onerror = function(error){
//             // modal.style.display = 'none';
//             openModalBtn.disabled = false;
//             openModalBtn.innerHTML = "Save";
//             swal('Sorry', "An error occured, try again!", 'error');
//         }
//         xhttp.open("POST", '../backend/request.php?function=update-donor', true);
//         xhttp.send(formData);
    
// }

// function deleteDonor1(i){
//     const id = i;
//     swal({
//         title: "Are you sure?",
//         text: "This will be deleted permanently.",
//         type: "warning",
//         showCancelButton: true,
//         showConfirmButton: true,
//         confirmButtonColor: "#DD6B55",
//         confirmButtonText: "Delete",
//         cancelButtonText: "Cancel",
//         closeOnConfirm: true,
//         closeOnCancel: true
//       },
//       function(isConfirm){
//         if (isConfirm) {
//             var formData = new FormData();

//             formData.append('id', id);

//             var xhttp = new XMLHttpRequest();
//             xhttp.onload = function(){
//                 var response = JSON.parse(xhttp.response);
//                 if(response.success){
//                     getDonor();
                    
//                     swal('Hurray', response.success, 'success');
//                 }
//                 else{
//                     swal('Sorry', response.error, 'error');
                    
//                 }
//             }
//             xhttp.onerror = function(error){
//                 swal('Sorry', "An error occured, try again!", 'error');
//             }
//             xhttp.open('POST', '../backend/request.php?function=delete-donor', true);
//             xhttp.send(formData);
//         }
//       });
// }





const searchBar = document.getElementById('search-bar')

if (searchBar) {
    searchBar.addEventListener('input', () => {
        let searchTerm = searchBar.value.toLowerCase();

        let filteredUsers = allUserData.filter(user => user.first_name?.toLowerCase().includes(searchTerm) || user.last_name?.toLowerCase().includes(searchTerm) || user.user_pin?.toLowerCase().includes(searchTerm) || user.area_community?.toLowerCase().includes(searchTerm) || user.gender?.toLowerCase().includes(searchTerm) || user.occupation?.toLowerCase().includes(searchTerm));
        loopAllUserData(filteredUsers);

        let filteredDonors = donorData.filter(user => user.first_name?.toLowerCase().includes(searchTerm) || user.last_name?.toLowerCase().includes(searchTerm) || user.email?.toLowerCase().includes(searchTerm) || user.address?.toLowerCase().includes(searchTerm) || user.gender?.toLowerCase().includes(searchTerm) || user.occupation?.toLowerCase().includes(searchTerm));
        loopDonor(filteredDonors);


        let filteredReceipt = receiptData.filter(user => user.receipt.toLowerCase().includes(searchTerm) || user.donor_name.toLowerCase().includes(searchTerm) || user.amount.includes(searchTerm));
        loopReceipt(filteredReceipt);
      

        let filteredReportReceipt = receiptData.filter(user => user.receipt.toLowerCase().includes(searchTerm) || user.donor_name.toLowerCase().includes(searchTerm) || user.amount.includes(searchTerm));
        loopReceiptReport(filteredReportReceipt);




        let filteredPayment = paymentData.filter(user => user.payment.toLowerCase().includes(searchTerm) || user.amount.includes(searchTerm));
        loopPayment(filteredPayment);

        let filteredReportPayment = paymentData.filter(user => user.payment.toLowerCase().includes(searchTerm) || user.amount.includes(searchTerm));
        loopPaymentReport(filteredReportPayment);

     
       
    })

}


// REPORT

function addDonor(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input,select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 900px;
             overflow-y: scroll;
 
           
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
        .preview-image{
            width: auto;
            height: 90px
        }

    /* Hide spinner controls in Chrome, Safari, Edge, and Opera */
input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Hide spinner controls in Firefox */
input[type="number"] {
    -moz-appearance: textfield;
}
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Add </h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">

                     <div class="three-forms">
                        <div class="form_element">
                            <label class="form-label" for="last_name">Last Name</label>
                            <input  class="modal-input" type="text" id="last_name" />
                        </div>
                        
                        <div class="form_element">
                            <label class="form-label" for="first_name">First Name</label>
                            <input  class="modal-input" type="text" id="first_name" />
                        </div>
                            <div class="form_element">
                            <label class="form-label" for="email">Email</label>
                            <input  class="modal-input" type="email" id="email" />
                        </div>
                    </div>
                    <div class="three-forms">
                        <div class="form_element">
                            <label class="form-label" for="phone_no">Phone No</label>
                            <input class="modal-input" type="text" id="phone_no" />
                        </div>
                        <div class="form_element">
                            <label class="form-label" for="address">Address</label>
                            <input class="modal-input" type="text" id="address" />
                        </div>
                        
                        <div class="form_element">
                            <label class="form-label" for="gender">Gender</label>
                            <select class="modal-input" id="gender">
                                <option value="">Choose your gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                  
                       
                  <div class="three-forms">
                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required  value="Ehi"/>
                        </div>


                          <div class="form_element">
                                <label for="Item">Category Items</label>
                                <select id="category" onchange
                                ="toggleQuantityField()">
                                    <option  value=""></option>
                                    <option  value="Cash">Cash</option>
                                    <option  value="Medication">Medication</option>
                                    <option  value="Rice">Rice</option>
                                    <option  value="Beans">Beans</option>
                                    <option  value="Clothes">Clothes</option>
                                    
                                </select>
                        </div>

                       <div class="form_element" id="quantityField">
                                <label for="Item">Quantity <em style="font-size:10px;">( in Kg,Pcs,Pack)</em></label>
                                <input type="number" id="quantity" required  placeholder="for cash, enter the amount")"/>
                        </div>

                      
                </div>

                <div class="three-forms">

                        <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required />
                        </div>

                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required />
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required />
                        </div>
                    
                       
                 </div>
                   <div class="three-forms">
                        <div class="form_element">
                            <label class="form-label" for="type_of_donor">Type Of Donor</label>
                            <select class="modal-input" id="type_of_donor">
                                <option value="">Choose</option>
                                <option value="Ehi Center">Ehi Center</option>
                                <option value="External Donor">External Donor</option>
                            </select>
                        </div>
                    </div>

                 <div class="three-forms">

                 <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect(event)">
                        
                        <div style="display:flex;  " id="mother_preview">
                            <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Add Attachment</button> 

                            <span class = "preview-image" id="preview"></span>
                        </div>
                </div>

                    <button type="button" class="save-button" onclick="saveDonor()" id="save-btn" style="margin-left:46% !important">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }

   

}


function saveDonor(){
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var modals = document.querySelector('.modals');
    var form = document.getElementById('form');
    const last_name = document.getElementById('last_name').value.trim();
    const first_name = document.getElementById('first_name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone_no = document.getElementById('phone_no').value.trim();
    const address = document.getElementById('address').value.trim();
    const gender = document.getElementById('gender').value.trim();

    const donor = document.getElementById('Donor').value.trim();
    const type_of_donor = document.getElementById('type_of_donor').value.trim();
    const quantity = document.getElementById('quantity').value.trim();
    const amount = document.getElementById('Amount').value.trim();
    const date = document.getElementById('Date').value.trim();
    const receiptNo = document.getElementById('ReceiptNo').value.trim();
    const category = document.getElementById('category').value.trim();

    // Validate required fields
    if (!donor || !amount || !date || !receiptNo || !category) {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Error', 'All fields are required. Please fill in all fields before saving.', 'error');
        return;
    }

    var formData = new FormData();
    formData.append('last_name', last_name);
    formData.append('first_name', first_name);
    formData.append('email', email);
    formData.append('phone_no', phone_no);
    formData.append('address', address);
    formData.append('gender', gender);

    formData.append('donor', donor);
    formData.append('type_of_donor', type_of_donor);
    formData.append('quantity', quantity);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('receiptNo', receiptNo);
    formData.append('category', category);
    formData.append('image', chosen_file);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);

      
        form.reset();
 
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        
        swal('Success', "Record saved!", 'success');
    
        getDonor(); 
    }

    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=save-donor', true);
   
    console.log("formData", formData);
    xhttp.send(formData);
}

let donorData = []
function getDonor(){

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        programData = response.donor;
        donorData = response.donor;
        loopDonor(programData);
    }

    xhttp.open("GET", '../backend/request.php?function=get-donor', true);
    xhttp.send();
}
getDonor();

function loopDonor(data){
    var container = document.getElementById('donor-tbody');
    var tr = "";
    var counter = 1000;
    if(data && data.length > 0){



        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
            <td class="ehi-td">${formatDate(data[i]?.date) ?? ''}</td>
                <td class="ehi-td">${counter}</td>
                <td class="ehi-td">${data[i]?.last_name ?? ''}</td>
                <td class="ehi-td">${data[i]?.first_name ?? ''}</td>
                <td class="ehi-td">${truncateText(data[i]?.email) ?? ''}</td>
                <td class="ehi-td">${data[i]?.phone_no ?? ''}</td>
                <td class="ehi-td">${truncateText(data[i]?.address) ?? ''}</td>
                <td class="ehi-td">${data[i]?.gender ?? ''}</td>
                <td class="ehi-td">${data[i]?.item ?? ''}</td>
         
      
                <td class="ehi-td">
                    <div class="relative-position">
                        <button onclick="openOptions(${data[i].id + 200000})" class="three" style="cursor: pointer;">
                            <img src="../assets/images/three-options.png" alt="" class="three-options">
                        </button>
                        <div id="options-${data[i].id + 200000}" class="options-dropdown" style="right: 5px;">
                            <button onclick="viewDonor(${data[i].id} )" class="openModalBtnEdit option-button" >
                                 <img src="/assets/images/view.png"/> View
                            </button>
                            <button onclick="editDonor(${data[i].id} )" class="openModalBtnEdit option-button" >
                                <img src="/assets/images/edit.png"/> Edit
                            </button>
                            <button onclick="deleteDonor(${data[i].id})" class="openModalBtnEdit option-button">
                                <img src="/assets/images/delete.png"/> Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}


function editDonor(programDataId){

    var data = programData.find((programDatum)=>{
        console.log("programDatum.id",programDatum.id)
        return programDatum.id == programDataId
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input,select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 900px;
             overflow-y: scroll;
        
           
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Edit</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="last_name">Last Name</label>
                                                <input value="${data?.last_name ?? ''}" class="modal-input" type="text" id="last_name" />
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="first_name">First Name</label>
                                                <input value="${data?.first_name ?? ''}" class="modal-input" type="text" id="first_name" />
                                            </div>
                                             <div class="form_element">
                                                <label class="form-label" for="email">Email</label>
                                                <input value="${data?.email ?? ''}" class="modal-input" type="email" id="email" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="phone_no">Phone No</label>
                                                <input value="${data?.phone_no ?? ''}" class="modal-input" type="text" id="phone_no" />
                                            </div>
                                            <div class="form_element">
                                               <label class="form-label" for="address">Address</label>
                                               <input value="${data?.address ?? ''}" class="modal-input" type="text" id="address" />
                                           </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="gender">Gender</label>
                                                <select class="modal-input" value="${data?.gender ?? ''}" id="gender">
                                                    <option value="${data?.gender ?? ''}">${data?.gender ?? ''}</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </div>
                                        </div>
                       
                  <div class="three-forms">
                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required  value="${data.donor}" />
                        </div>


                <div class="form_element">
                    <label for="Item">Category Items</label>
                    <select id="category" onchange="toggleQuantityField()">
                        <option value=""></option>
                        <option value="Cash" ${data.item === 'Cash' ? 'selected' : ''}>Cash</option>
                        <option value="Medication" ${data.item === 'Medication' ? 'selected' : ''}>Medication</option>
                        <option value="Rice" ${data.item === 'Rice' ? 'selected' : ''}>Rice</option>
                        <option value="Beans" ${data.item === 'Beans' ? 'selected' : ''}>Beans</option>
                        <option value="Clothes" ${data.item === 'Clothes' ? 'selected' : ''}>Clothes</option>
                    </select>
            </div>


                       <div class="form_element" id="quantityField">
                                <label for="Item">Quantity <em style="font-size:10px;">( in Kg,Pcs,Pack)</em></label>
                                <input type="number" id="quantity" required  placeholder="" value="${data.quantity}" />
                        </div>

                      
                </div>

                <div class="three-forms">

                        <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required  value="${data.amount}"/>
                        </div>

                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required  value="${data.date}"/>
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required  value="${data.receiptNo}"/>
                        </div>
                    
                       
                 </div>
                   <div class="three-forms">
                        <div class="form_element">
                            <label class="form-label" for="type_of_donor">Type Of Donor</label>
                            <select value="${data.type_of_donor}"  class="modal-input" id="type_of_donor">
                                <option  value="${data.type_of_donor}">${data?.type_of_donor ? data.type_of_donor : ''}</option>
                                <option value="Ehi Center">Ehi Center</option>
                                <option value="External Donor">External Donor</option>
                            </select>
                        </div>
                    </div>

                 <div class="three-forms">
                  <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect(event)">
                        
                        <div style="display:flex; flex-direction:column; justify-content:flex-start;align-items:flex-start; " id="mother_preview">

                         <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Change Attachment</button> 

                            

                            <span  id="preview" style="display:flex; flex-direction:column; ">
                           
                                    <img class = "preview-image" src="${homepageUrl}/uploads/${data.receipt_Image}" alt="Receipts" >
                            </span>

                        </div>
                </div>

                    <button type="button" class="save-button" onclick="updateDonor(${data.id})" id="save-btn" style="margin-left:46% !important">Update</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

 async function calculateItemInStock(){
    try {
        const response = await fetch('../backend/request.php?function=get-donor');
        const donorResponse = await response.json();
        const donorData = donorResponse.donor


        let itemsInStock = {
            riceQuantity: 0,
            riceAmount: 0,
            beansQuantity: 0,
            beansAmount: 0,
            clothesQuantity: 0,
            clothesAmount: 0,
            medicineQuantity: 0,
            medicineAmount: 0,
            cashQuantity: 0,
            cashAmount: 0
        }

        donorData.forEach(item => {
            const quantity = parseInt(item.quantity) || 0;
            const amount = parseInt(item.amount) || 0;
            switch (item.item) {
                case 'Rice':
                    itemsInStock.riceQuantity += quantity;
                    itemsInStock.riceAmount += amount;
                    break;
                case 'Beans':
                    itemsInStock.beansQuantity += quantity;
                    itemsInStock.beansAmount += amount;
                    break;
                case 'Clothes':
                    itemsInStock.clothesQuantity += quantity;
                    itemsInStock.clothesAmount += amount;
                    break;
                case 'Medication':
                    itemsInStock.medicineQuantity += quantity;
                    itemsInStock.medicineAmount += amount;
                    break;
                case 'Cash':
                    itemsInStock.cashQuantity += quantity;
                    itemsInStock.cashAmount += amount;
                    break;
            
                default:
                    break;
            }

          
            
        })
            console.log('check the data', itemsInStock);

            updateStock(itemsInStock)

        


    } catch (error) {
        console.error('Error fetching data', error);
    }
}

calculateItemInStock();

function updateStock(item){

    var formData = new FormData();
    formData.append('riceQuantity', item.riceQuantity);
    formData.append('riceAmount', item.riceAmount);
    formData.append('beansQuantity', item.beansQuantity);
    formData.append('beansAmount', item.beansAmount);
    formData.append('clothesQuantity', item.clothesQuantity);
    formData.append('clothesAmount', item.clothesAmount);
    formData.append('medicineQuantity', item.medicineQuantity);
    formData.append('medicineAmount', item.medicineAmount);
    formData.append('cashQuantity', item.cashQuantity);
    formData.append('cashAmount', item.cashAmount);

    

    console.log("formData", formData);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        


    }

    xhttp.onerror = function(){
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=update-stock', true);
   
   
    xhttp.send(formData);
}





function viewDonor(programDataId){

    var data = programData.find((programDatum)=>{
        console.log("programDatum.id",programDatum.id)
        return programDatum.id == programDataId
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input,select{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 900px;
      
  
             overflow-y: scroll;

           
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>View</h3>
                 <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">

        <div class="three-forms">
        <div></div>
        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/printLogo.png" alt="" style="height:60px; width:80px;margin-left:90px; margin-bottom:40px" />
         <div></div>
        </div>
         <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="last_name">Last Name</label>
                                                <input readonly value="${data?.last_name ?? ''}" class="modal-input" type="text" id="last_name" />
                                            </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="first_name">First Name</label>
                                                <input readonly value="${data?.first_name ?? ''}" class="modal-input" type="text" id="first_name" />
                                            </div>
                                             <div class="form_element">
                                                <label class="form-label" for="email">Email</label>
                                                <input readonly value="${data?.email ?? ''}" class="modal-input" type="email" id="email" />
                                            </div>
                                        </div>
                                        <div class="three-forms">
                                            <div class="form_element">
                                                <label class="form-label" for="phone_no">Phone No</label>
                                                <input readonly value="${data?.phone_no ?? ''}" class="modal-input" type="text" id="phone_no" />
                                            </div>
                                            <div class="form_element">
                                               <label class="form-label" for="address">Address</label>
                                               <input readonly value="${data?.address ?? ''}" class="modal-input" type="text" id="address" />
                                           </div>
                                           
                                            <div class="form_element">
                                                <label class="form-label" for="gender">Gender</label>
                                                <select class="modal-input" readonly value="${data?.gender ?? ''}" id="gender">
                                                    <option  value="${data?.gender ?? ''}">${data?.gender ?? ''}</option>
                        
                                                </select>
                                            </div>
                                        </div>
                    <div class="three-forms">
                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required  value="${data.donor}"  readonly disabled/>
                        </div>


                <div class="form_element">
                    <label for="Item">Category Items</label>
                    <select id="category" onchange="toggleQuantityField()"  disabled>
                        <option value=""></option>
                        <option value="Cash" ${data.item === 'Cash' ? 'selected' : ''}>Cash</option>
                        <option value="Medication" ${data.item === 'Medication' ? 'selected' : ''}>Medication</option>
                        <option value="Rice" ${data.item === 'Rice' ? 'selected' : ''}>Rice</option>
                        <option value="Beans" ${data.item === 'Beans' ? 'selected' : ''}>Beans</option>
                        <option value="Clothes" ${data.item === 'Clothes' ? 'selected' : ''}>Clothes</option>
                    </select>
            </div>


                       <div class="form_element" id="quantityField">
                                <label for="Item">Quantity <em style="font-size:10px;">( in Kg,Pcs,Pack)</em></label>
                                <input type="text" id="quantity" required  placeholder="" value="${data.quantity}" readonly disabled/>
                        </div>

                      
                </div>

                <div class="three-forms">

                        <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="number" id="Amount" required  value="${data.amount}" readonly disabled/>
                        </div>

                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required  value="${data.date}" readonly disabled/>
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required  value="${data.receiptNo}" readonly disabled/>
                        </div>
                    
                       
                 </div>
                  <div class="three-forms">
                        <div class="form_element">
                            <label class="form-label" for="type_of_donor">Type Of Donor</label>
                            <select value="${data.type_of_donor}"  class="modal-input" id="type_of_donor">
                                <option  value="${data.type_of_donor}">${data?.type_of_donor ? data.type_of_donor : ''}</option>
                               
                            </select>
                        </div>
                    </div>


                 <div class="three-forms">
                    <div></div>
                  <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex; flex-direction:column; justify-content:flex-start; " id="mother_preview">

         

                            <span id="preview">
                                    <img class="receipt-imag" src="../uploads/${data.receipt_Image}" alt="Receipts" style="width:370px;height:190px;" margin-bottom: 40px;">
                            </span>
                        </div>
                        <div>
                        </div>
                </div>

    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateDonor(programDataId){
    console.log("programDataId",programDataId)
    var savebtn = document.getElementById('save-btn');
  
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var modals = document.querySelector('.modals');
    var form = document.getElementById('form');
    const last_name = document.getElementById('last_name').value.trim();
    const first_name = document.getElementById('first_name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone_no = document.getElementById('phone_no').value.trim();
    const address = document.getElementById('address').value.trim();
    const gender = document.getElementById('gender').value.trim();

    const donor = document.getElementById('Donor').value.trim();
    const type_of_donor = document.getElementById('type_of_donor').value.trim();
    const quantity = document.getElementById('quantity').value.trim();
    const amount = document.getElementById('Amount').value.trim();
    const date = document.getElementById('Date').value.trim();
    const receiptNo = document.getElementById('ReceiptNo').value.trim();
    const category = document.getElementById('category').value.trim();



    var formData = new FormData();
    formData.append('last_name', last_name);
    formData.append('first_name', first_name);
    formData.append('email', email);
    formData.append('phone_no', phone_no);
    formData.append('address', address);
    formData.append('gender', gender);

    formData.append('donor', donor);
    formData.append('type_of_donor', type_of_donor);
    formData.append('quantity', quantity);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('receiptNo', receiptNo);
    formData.append('category', category);
    formData.append('image', chosen_file);
    formData.append('programDataId', programDataId);
    

    console.log("formData", formData);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);

        closeModal()
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        
        swal('Success', "Record saved!", 'success');


        getDonor(); // Refresh data after saving
    }

    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=update-donor', true);
   
   
    xhttp.send(formData);
}

function deleteDonor(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getDonor();
                    
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', '../backend/request.php?function=delete-donor', true);
            xhttp.send(formData);
        }
      });
}

async function getItemsInStock() {
    try {
        const response = await fetch('../backend/request.php?function=get-items-in-stock');
        const data = await response.json();
        
        if (data.items) {
            loopItemsInStock(data.items)
        } else {
            console.error("Error fetching items:", data.error || "Unknown error");
        }
    } catch (error) {
        console.error("Network error:", error);
    }
}



// function loopItemsInStock(data){

//     var data = programData.find((programDatum)=>{
//         console.log("programDatum.id",programDatum.id)
//         return programDatum.id == programDataId
//     });

//     var modals = document.querySelector('.modals');
//     var modalContent = `
    
//     <style>
//         input,select{
//             padding: 12px 17px;
//             border-radius: 8px;
//             border: 1px solid var(--Foundation-Primary-P400, #097B48);
//             background: var(--Foundation-White-W300, #F6F6F6);
        
//         }
            

//         .modal-container{
//             display: none; 
//             position: fixed; /* Fixed position */
//             z-index: 12000; /* Make sure it appears on top of everything */
//             left: 0;
//             top: 0;
//             width: 100%;
//             height: 100%;
//             background-color: rgba(0,0,0,0.4); /* Black background with opacity */
//         }

//         .modal-content {
//             background-color: #fefefe; 
//             position: fixed; 
//             top: 50%; 
//             left: 50%; 
//             transform: translate(-50%, -50%); 
//             /* padding: 20px; */
//             border: 1px solid #888;
//             width: 80%;
//             max-height: 100vh; 
//             max-width: 500px;
//             max-width: 900px;
//              overflow-y: scroll;
        
           
//         }

//         .close {
//             color: white;
//             font-size: 28px;
//             font-weight: bold;
//         }
        
//         .close:hover,
//         .close:focus {
//             color: black;
//             text-decoration: none;
//             cursor: pointer;
//         }

//         .add-text-header {
//         background: #097B48;
//             display: flex;
//             justify-content: space-between;
//             align-items: center;
//             padding: 10px;
//             margin-bottom: 4px;
//             height: 35px;
//             color: white;
//         }

//         .add-text > h3 {
//             color: #FFF;
//             font-family: Archivo;
//             font-size: 24px;
//             font-style: normal;
//             font-weight: 600;
//             line-height: 120%; /* 28.8px */
//             text-align: center;
//         }

//         .nav-btn {
//         display: flex;
//         width: 110px;
//         height: 40px;
//         justify-content: center;
//         align-items: center;
//         border-radius: 10px;
//         background: #097B48;
//         border: 0;
//         color: #FFF;
//         font-family: Roboto;
//         font-size: 17px;
//         font-style: normal;
//         font-weight: 400;
//         cursor: pointer;
//         }

//         .save-button{
//             display: flex;
//             width: 118px;
//             height: 37px;
//             padding: 10px;
//             justify-content: center;
//             align-items: center;
//             gap: 10px;
//             flex-shrink: 0;
//             border-radius: 10px;
//             background: #097B48;
//             color: #FFF;
//             text-align: center;
//             font-family: Archivo;
//             font-size: 18px;
//             font-style: normal;
//             font-weight: 600;
//             line-height: 120%; /* 19.2px */
//             border: 0;
//             margin-left: 110px;
//             margin-top: 20px;
//         }

//         .add-recept{
//         /* padding:10px; */
//         border-color: transparent;
//         background-color: transparent;
//         color: #097B48;
//         font-family: Inter;
//         cursor: pointer;
//         }

//     .form_element{
//         display: flex;
//         flex-direction: column;
//         justify-content: flex-start;
//         margin-bottom: 1.5rem;
//         width: 100%;
//     }

//     form{
//         padding: 20px;
//         font-family: Inter;
//     }
// </style>
//     <div id="myModal" class="modal-container">
//         <div class="modal-content">
            
//             <div class="add-text-header">
//             <h3></h3>
//                 <h3>Items In Stock</h3>
//                 <span onclick="closeModal()" class="close">&times;</span>
//             </div>
//             <div class="ehi-table-container padding-side">
//                 <table class="ehi-table">
//                     <thead class="ehi-thead">
//                         <tr class="ehi-thead-tr">
//                             <th class="ehi-th">Category</th>
//                             <th class="ehi-th">Quantity</th>
//                             <th class="ehi-th">Amount</th>
//                         </tr>
//                     </thead>
//                     <tbody class="ehi-tbody" id="donor-tbody">
//                     <tr>
//                         <td class="ehi-td2">Rice</td>
//                         <td class="ehi-td2">345</td>
//                         <td class="ehi-td2">43534</td>
//                     </tr>
//                     <tr>
//                         <td class="ehi-td2">Beans</td>
//                         <td class="ehi-td2">345</td>
//                         <td class="ehi-td2">43534</td>
//                     </tr>
//                     <tr>
//                         <td class="ehi-td2">Medication</td>
//                         <td class="ehi-td2">345</td>
//                         <td class="ehi-td2">43534</td>
//                     </tr>
//                     <tr>
//                         <td class="ehi-td2">Clothes</td>
//                         <td class="ehi-td2">345</td>
//                         <td class="ehi-td2">43534</td>
//                     </tr>
//                     <tr>
//                         <td class="ehi-td2">Cash</td>
//                         <td class="ehi-td2">345</td>
//                         <td class="ehi-td2">43534</td>
//                     </tr>
//                     </tbody>
//                 </table>
//             </div>
       

//         </div>
//     </div>
//     `;
//     if(modals){
//         modals.innerHTML = modalContent;
//         openModal();
//     }
// }

function loopItemsInStock(data) {
    var modals = document.querySelector('.modals');
    if (!modals) {
        console.error("Modal container not found.");
        return;
    }

    let tableRows = data.map(item => `
        <tr>
            <td class="ehi-td2">${item.item}</td>
            <td class="ehi-td2">${item.item == 'Cash' && `₦${formatNumberWithCommas(item.quantity)}.00` || item.item == 'Rice' && `${formatNumberWithCommas(item.quantity)}kg` || item.item == 'Beans' && `${formatNumberWithCommas(item.quantity)}kg` || item.item == 'Medication' && `${formatNumberWithCommas(item.quantity)}packs` || item.item == 'Clothes' && `${formatNumberWithCommas(item.quantity)}pcs`}</td>
            <td class="ehi-td2">₦${formatNumberWithCommas(item.amount)}.00</td>
        </tr>
    `).join('');

    var modalContent = `
    <style>
        input,select { padding: 12px 17px; border-radius: 8px; border: 1px solid #097B48; background: #F6F6F6; }
        .modal-container { display: none; position: fixed; z-index: 12000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.4); }
        .modal-content { background-color: #fefefe; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 80%; max-height: 100vh; max-width: 900px; overflow-y: scroll; }
        .close { color: white; font-size: 28px; font-weight: bold; }
        .close:hover, .close:focus { color: black; text-decoration: none; cursor: pointer; }
        .add-text-header { background: #097B48; display: flex; justify-content: space-between; align-items: center; padding: 10px; height: 35px; color: white; }
        .save-button { display: flex; width: 118px; height: 37px; padding: 10px; justify-content: center; align-items: center; border-radius: 10px; background: #097B48; color: #FFF; font-size: 18px; margin-left: 110px; margin-top: 20px; }
        .ehi-table-container { padding: 20px; }
        .ehi-table { width: 100%; border-collapse: collapse; }
        .ehi-th, .ehi-td2 { padding: 8px; text-align: left; }
        .ehi-th { background-color: #097B48; color: white; }
        .measurement-container { display: flex; justify-content: space-between; padding: 0 20px}
        .measurement-text { font-size: 12px; margin-top: 10px}
        
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <div class="add-text-header">
                <h3></h3>
                <h3>Total Items</h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
            <div class="measurement-container">
                <p class="measurement-text" >Rice:<span>Kilograms(kg)<span></p>
                <p class="measurement-text" >Beans:<span>Kilograms(kg)<span></p>
                <p class="measurement-text" >Medication:<span>Packs(packs)<span></p>
                <p class="measurement-text" >Clothes:<span>Pieces(pcs)<span></p>
                <p class="measurement-text" >Cash:<span>Naira(₦)<span></p>
                
            </div>
            <div class="ehi-table-container">
                <table class="ehi-table">
                    <thead>
                        <tr>
                            <th class="ehi-th">Category</th>
                            <th class="ehi-th">Quantity</th>
                            <th class="ehi-th">Amount</th>
                        </tr>
                    </thead>
                    <tbody id="donor-tbody">
                        ${tableRows}
                    </tbody>
                </table>
            </div>
        </div>
    </div>`;

    modals.innerHTML = modalContent;
    openModal();
}
