const password = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');
if(togglePassword){
    togglePassword.addEventListener('click', () => {
        const password = document.getElementById('password');
        const togglePassword = document.getElementById('togglePassword');

        const passwordType = password.getAttribute('type') === 'password' ? 'text' : 'password'
        password.setAttribute('type', passwordType);
        togglePassword.src = passwordType === 'password' ? './assets/images/eye-hide.png' : './assets/images/eye-view.png'
    })
}



const loginForm = document.getElementById('login-form')

function validateLogin(e){
    e.preventDefault();

    const email = document.getElementById('email').value
    const password = document.getElementById('password').value
    var loginBtn = document.getElementById('login-btn');
    const loginForm = document.getElementById('login-form')

    if (email !== '' && password !== '') {
        var formData = new FormData();
        formData.append('email', email);
        formData.append('password', password);
        loginBtn.disabled = true;
        loginBtn.innerHTML = "Logging in...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            loginForm.reset();
            loginBtn.disabled = false;
            loginBtn.innerHTML = "Login";
            var response = JSON.parse(xhttp.response);
            if(response.user){
                swal('Hurray', response.success, 'success');
          
                window.sessionStorage.setItem('admin', JSON.stringify(response.user));
                window.location.href = '../dashboard/dashboard.html';
            }
            else{
                loginForm.reset();
  
                swal('Error', 'Invalid Email or Password, Try Again', 'error');
                
            }
        }

        xhttp.onerror = function(error){
            loginForm.reset();
            loginBtn.disabled = false;
            loginBtn.innerHTML = "Login";
            swal('Oops', error, 'error');
        }
        xhttp.open("POST", '../backend/request.php?function=admin-login', true);
        xhttp.send(formData);
    } else{

    }
}

if(loginForm){
    loginForm.addEventListener('submit', validateLogin)
}




